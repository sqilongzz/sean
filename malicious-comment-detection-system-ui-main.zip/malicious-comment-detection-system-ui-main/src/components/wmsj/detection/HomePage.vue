<template>
  <div class="home-container">
    <h4>后门攻击安全性测评系统</h4>
    <p class="description">
      1. 集成常用神经网络模型与入侵检测数据集，模拟真实入侵检测环境。
    </p>
    <p class="description">
      2. 提供后门攻击和防御方法的集成评估，通过基础性能、后门攻击、后门防御三个维度对模型进行安全性评估，并得出综合安全评分。
    </p>
    <p class="description">
      3. 统计分析历史后门攻击事件，通过数据直观展示攻击趋势与特征。
    </p>
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  data() {
    return {};
  },
  methods: {
    // 可在此处添加方法
  },
};
</script>

<style scoped>
.home-container {
  padding: 20px;
  font-family: Arial, sans-serif;
  text-align: left; /* 确保容器内文本左对齐 */
}

h2 {
  color: #666; /* 设置标题为灰色 */
  font-size: 24px;
  margin-bottom: 10px;
  text-align: left; /* 标题左对齐 */
}

.description {
  color: #666;
  font-size: 16px;
  margin: 10px 0;
  line-height: 1.6;
}
</style>
