<template>
  <div id="app">
    <el-container style="padding: 10px;">
      <el-main>
        <el-form label-position="top" label-width="150px">
          <el-form-item label="触发器">
            <el-input v-model="trigger" placeholder="请输入触发器" autocomplete="off" @wheel.prevent></el-input>
          </el-form-item>
          <el-form-item label="受害者数据集">
            <el-input v-model="victimDataset" placeholder="请输入受害者数据集" autocomplete="off" @wheel.prevent></el-input>
          </el-form-item>
          <el-form-item label="中毒数据集">
            <el-input v-model="poisonedDataset" placeholder="请输入中毒数据集" autocomplete="off" @wheel.prevent></el-input>
          </el-form-item>
          <el-form-item label="请输入测试数据">
            <el-input v-model="testData" placeholder="请输入测试数据" autocomplete="off" @wheel.prevent></el-input>
          </el-form-item>
          <el-form-item label="中毒数据为">
            <el-input v-model="poisonedData" placeholder="请输入中毒数据为" autocomplete="off" @wheel.prevent></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submit">提交</el-button>
          </el-form-item>
        </el-form>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      trigger: '',
      victimDataset: '',
      poisonedDataset: '',
      testData: '',
      poisonedData: '',
    };
  },
  methods: {
    submit() {
      console.log('提交的数据:', {
        trigger: this.trigger,
        victimDataset: this.victimDataset,
        poisonedDataset: this.poisonedDataset,
        testData: this.testData,
        poisonedData: this.poisonedData,
      });
      // 在此处可以处理提交逻辑
    },
  },
};
</script>

<style>
#app {
  text-align: center;
  color: #2c3e50;
}
</style>
