<template>
  <el-card class="form-card">
    <el-form :model="form" ref="form" label-width="150px">
      <el-form-item label="训练数据" prop="trainingData" :rules="[{ required: true, message: '请输入训练数据', trigger: 'blur' }]">
        <el-input v-model="form.trainingData" placeholder="请输入训练数据" size="large"></el-input>
        <el-button type="primary" size="medium" @click="startTraining('trainingData')">开始训练</el-button>
      </el-form-item>
      <el-form-item label="训练模型" prop="trainingModel" :rules="[{ required: true, message: '请输入训练模型', trigger: 'blur' }]">
        <el-input v-model="form.trainingModel" placeholder="请输入训练模型" size="large"></el-input>
        <el-button type="primary" size="medium" @click="startTraining('trainingModel')">开始训练</el-button>
      </el-form-item>
      <el-form-item label="目标标签" prop="targetLabel" :rules="[{ required: true, message: '请输入目标标签', trigger: 'blur' }]">
        <el-input v-model="form.targetLabel" placeholder="请输入目标标签" size="large"></el-input>
        <el-button type="primary" size="medium" @click="startTraining('targetLabel')">开始训练</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script>
export default {
  data() {
    return {
      form: {
        trainingData: '',
        trainingModel: '',
        targetLabel: ''
      }
    };
  },
  methods: {
    startTraining(field) {
      this.$refs.form.validateField(field, (valid) => {
        if (valid) {
          // 开始训练的逻辑
          console.log(`开始训练: ${field}`, this.form);
        } else {
          console.log('请检查输入');
        }
      });
    }
  }
};
</script>

<style>
.form-card {
  width: 80%; /* 让卡片宽度填满 */
  height: 100%; /* 填充整个高度 */
  padding: 20px; /* 增加内边距 */
  box-sizing: border-box; /* 包括padding在内的高度计算 */
  display: flex;
  flex-direction: column; /* 垂直排列内容 */
  justify-content: flex-start; /* 从顶部开始排列 */
}

.el-form-item {
  margin-bottom: 20px; /* 增加表单项之间的间距 */
  display: flex; /* 使用flex布局 */
  align-items: center; /* 垂直居中 */
}

.el-input {
  flex: 1; /* 输入框占据剩余空间 */
  margin-right: 10px; /* 输入框与按钮之间的间距 */
}

.el-button {
  flex-shrink: 0; /* 按钮不缩小 */
}
</style>
