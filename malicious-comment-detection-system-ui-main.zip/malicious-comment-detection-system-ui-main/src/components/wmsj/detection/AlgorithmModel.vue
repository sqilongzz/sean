<template>
  <el-container class="content">
    <!-- 顶部搜索与操作栏 -->
    <el-header class="header">
      <el-input
          v-model="searchQuery"
          placeholder="请输入关键词"
          clearable
          prefix-icon="el-icon-search"
          class="search-input-short"
          @keyup.enter="fetchTableData"
      />
      <!--      <el-button size="large" :icon="Search" @click="fetchTableData" round>搜索</el-button>-->
      <el-button type="primary" @click="fetchTableData">搜索</el-button>
      <el-button type="primary" @click="showDialog = true" class="action-button">新增</el-button>
      <el-button type="danger" @click="deleteSelected" class="action-button">删除</el-button>
      <!--      <el-button type="success" class="action-button">导出</el-button>-->
    </el-header>

    <!-- 数据表格与分页区域 -->
    <el-main class="main">
      <el-card shadow="hover" class="data-card">
        <el-table
            :data="tableData"
            v-loading="loading"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange"
        >
          <el-table-column type="selection" width="50"></el-table-column>
<!--          <el-table-column prop="id" label="序号" width="60" align="center"></el-table-column>-->
          <!-- 序号列 -->
          <el-table-column
              type="index"
              label="序号"
              width="60"
              align="center"
              :index="(index) => (currentPage - 1) * pageSize + index + 1"
          ></el-table-column>
          <el-table-column prop="algName" label="名称" width="180"></el-table-column>
          <el-table-column prop="algType" label="类别" width="150"></el-table-column>
          <!--          <el-table-column prop="applicableModel" label="适用模型" width="200"></el-table-column>-->
          <el-table-column prop="description" label="详细描述" width="300"></el-table-column>
          <el-table-column prop="path" label="存储路径"></el-table-column>
          <!--          <el-table-column prop="detail" label="详细信息" width="200"></el-table-column>-->
          <el-table-column label="操作" width="150">
            <template #default="scope">
              <el-button type="text" size="small" @click="editRecord(scope.row)">编辑</el-button>
              <el-button type="text" size="small" @click="deleteRecord(scope.row.id)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <el-pagination
            background
            layout="total, sizes, prev, pager, next"
            :page-sizes="[10, 20, 50]"
            :page-size="pageSize"
            :total="total"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
        />
      </el-card>
    </el-main>

    <!-- 新增对话框 -->
    <el-dialog
        title="新增样本数据库管理"
        v-model="showDialog"
        width="600px"
        custom-class="dialog-style"
        @close="resetForm"
    >
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="名称" prop="algName">
          <el-input v-model="form.algName"/>
        </el-form-item>
        <el-form-item label="类型" prop="type">
          <el-input v-model="form.algType"/>
        </el-form-item>
        <!--        <el-form-item label="适用模型" prop="model">-->
        <!--          <el-input v-model="form.applicableModel" />-->
        <!--        </el-form-item>-->
        <el-form-item label="详细描述" prop="description">
          <el-input type="textarea" v-model="form.description"/>
        </el-form-item>
        <el-form-item label="存储路径" prop="path">
          <el-input v-model="form.path"/>
        </el-form-item>
        <!--        <el-form-item label="详细信息" prop="details">-->
        <!--          <el-input type="textarea" v-model="form.detail" />-->
        <!--        </el-form-item>-->
      </el-form>
      <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </el-container>
</template>

<script>
import {ref, onMounted} from 'vue';
import axios from 'axios';
import {ElMessage} from 'element-plus';

export default {


  name: 'SampleDatabaseManager',
  setup() {
    const searchQuery = ref('');
    const loading = ref(false);
    const showDialog = ref(false);
    const tableData = ref([]);
    const total = ref();
    const pageSize = ref(10);
    const currentPage = ref(1);
    const selectedRows = ref([]);

    const form = ref({
      id: '',
      algName: '',
      algType: '',
      // applicableModel: '',
      path: '',
      description: '',
      // detail: '',
    });

    const rules = {
      algName: [{required: true, message: '请输入数据库名称', trigger: 'blur'}],
      algType: [{required: true, message: '请输入数据库类型', trigger: 'blur'}],
      // applicableModel: [{ required: true, message: '请输入适用模型', trigger: 'blur' }],
      path: [{required: true, message: '请输入存储路径', trigger: 'blur'}],
      description: [{required: true, message: '请输入数据集描述', trigger: 'blur'}],
      // detail: [{ required: true, message: '请输入详细信息', trigger: 'blur' }],
    };

    const formRef = ref(null);

    const handleSelectionChange = (selection) => {
      selectedRows.value = selection;
    };

    const fetchTableData = async () => {
      loading.value = true;
      try {
        const response = await axios.get('http://localhost:8080/alg/queryAlg', {
          params: {query: searchQuery.value, page: currentPage.value, size: pageSize.value},
        });
        const res = response.data;  // 后端返回的分页对象!
        console.log("分页结果", res);
        if (res.code === 200) {
          tableData.value = res.data.records;   // 表格数据
          total.value = res.data.total;         // 总记录数
          totalPages.value = res.data.pages;    // 总页数
        } else {
          ElMessage.error('状态码异常');
        }
      } catch (error) {
        // ElMessage.error('获取数据失败');
      } finally {
        loading.value = false;
      }
    };

    // 新增或编辑数据
    const submitForm = async () => {
      formRef.value.validate(async (valid) => {
        if (valid) {
          try {
            if (form.value.id) {
              // 编辑操作，使用 PUT 请求
              await axios.post('http://localhost:8080/alg/update', form.value);
              ElMessage.success('编辑成功');
            } else {
              // 新增操作，使用 POST 请求
              await axios.post('http://localhost:8080/alg/add', form.value);
              ElMessage.success('新增成功');
            }
            fetchTableData();
            showDialog.value = false;
          } catch (error) {
            ElMessage.error('操作失败');
          }
        } else {
          ElMessage.error('请完整填写表单');
        }
      });
    };

    // 删除选中的记录
    const deleteSelected = async () => {
      if (!selectedRows.value.length) {
        ElMessage.warning('请选择要删除的数据');
        return;
      }
      try {
        const ids = selectedRows.value.map((row) => row.id);
        await axios.delete('http://localhost:8080/alg/deleteBatch', {
          headers: {'Content-Type': 'application/json'},
          data: ids,
        });
        ElMessage.success('删除成功');
        fetchTableData();
      } catch (error) {
        ElMessage.error('删除失败');
      }
    };

    // 删除单个记录
    const deleteRecord = async (id) => {
      try {
        const response = await axios.delete('http://localhost:8080/alg/delete', {
          params: {id},
        });
        if (response.data.code === 200) {
          ElMessage.success('删除成功');
          fetchTableData();
        } else {
          ElMessage.error(response.data.message || '删除失败');
        }
      } catch (error) {
        ElMessage.error('删除失败，请稍后重试');
      }
    };

    // 编辑记录
    const editRecord = (row) => {
      form.value = {...row}; // 将当前行数据填充到表单中
      showDialog.value = true; // 打开编辑弹窗
    };

    const handleSizeChange = (newSize) => {
      pageSize.value = newSize;
      fetchTableData();
    };

    const handleCurrentChange = (newPage) => {
      currentPage.value = newPage;
      fetchTableData();
    };

    const resetForm = () => {
      form.value = {
        id: '',
        algName: '',
        algType: '',
        // applicableModel: '',
        path: '',
        description: '',
        // detail: '',
      };
    };

    onMounted(fetchTableData);

    return {
      searchQuery,
      tableData,
      loading,
      showDialog,
      form,
      rules,
      formRef,
      resetForm,
      submitForm,
      deleteSelected,
      total,
      pageSize,
      currentPage,
      handleSizeChange,
      handleCurrentChange,
      fetchTableData,
      handleSelectionChange,
      deleteRecord,
      editRecord
    };
  },
};
</script>

<style scoped>
.content {
  display: flex;
  flex-direction: column;
  background-color: #f5f7fa;
  height: 100%;
  padding: 20px;
  box-sizing: border-box;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding: 10px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.search-input {
  flex: 1;
  margin-right: 15px;
}

.action-button {
  margin-left: 10px;
}

.main {
  flex: 1;
}

.data-card {
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.dialog-style {
  border-radius: 10px;
}
</style>
