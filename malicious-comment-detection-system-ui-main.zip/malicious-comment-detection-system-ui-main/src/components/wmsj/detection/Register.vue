<template>
  <div class="register-container">
    <el-card class="register-card">
      <h2>注册</h2>
      <el-form :model="form" ref="form" class="register-form" label-width="100px">
        <el-form-item label="用户名" prop="userName"
                      :rules="[{ required: true, message: '请输入用户名', trigger: 'blur' }]">
          <el-input v-model="form.userName" placeholder="请输入用户名"></el-input>
        </el-form-item>
        <el-form-item label="昵称" prop="nickname"
                      :rules="[{ required: true, message: '请输入昵称', trigger: 'blur' }]">
          <el-input v-model="form.nickname" placeholder="请输入昵称"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" prop="email"
                      :rules="[{ required: true, message: '请输入邮箱', trigger: 'blur' }, { type: 'email', message: '邮箱格式不正确', trigger: ['blur', 'change'] }]">
          <el-input v-model="form.email" placeholder="请输入邮箱"></el-input>
        </el-form-item>
        <el-form-item label="手机号" prop="phone"
                      :rules="[{ required: true, message: '请输入手机号', trigger: 'blur' }, { validator: validatePhone, trigger: ['blur', 'change'] }]">
          <el-input v-model="form.phone" placeholder="请输入手机号"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password"
                      :rules="[{ required: true, message: '请输入密码', trigger: 'blur' }]">
          <el-input v-model="form.password" type="password" placeholder="请输入密码"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="confirmPassword"
                      :rules="[{ required: true, message: '请确认密码', trigger: 'blur' }, { validator: validateConfirmPassword, trigger: 'blur' }]">
          <el-input v-model="form.confirmPassword" type="password" placeholder="请确认密码"></el-input>
        </el-form-item>
<!--        <el-radio-group v-model="form.userType">-->
<!--          <el-radio value="0" size="large">管理员</el-radio>-->
<!--          <el-radio value="1" size="large">普通用户</el-radio>-->
<!--        </el-radio-group>-->
        <el-form-item>
          <el-button type="primary" @click="register">注册</el-button>
          <el-button @click="goToLogin">返回登录</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      form: {
        userName: '',
        nickname: '',
        userType: '1', // 默认选择的选项
        email: '',
        phone: '',
        password: '',
        confirmPassword: '',
      }
    };
  },
  methods: {
    register() {
      axios.post('http://localhost:8080/user/add', {
        userName: this.form.userName,
        nickname: this.form.nickname,
        password: this.form.password,
        email: this.form.email,
        phone: this.form.phone,
        userType: this.form.userType // 发送选中的用户类型
      })
          .then(response => {
            console.log('注册结果:', response.data);
            if (response.data.code === 200) {
              this.$router.push('/');
            } else {
              this.$message.error(response.data.msg);
            }
          })
          .catch(error => {
            console.error('注册失败:', error);
            this.$message.error("注册请求失败");
          });
    },
    validateConfirmPassword(rule, value, callback) {
      if (value !== this.form.password) {
        callback(new Error('两次输入的密码不一致'));
      } else {
        callback();
      }
    },
    goToLogin() {
      this.$router.push('/'); // 跳转到登录页面
    },
    validatePhone(rule, value, callback) {
      const phoneRegex = /^[1][3-9][0-9]{9}$/; // 中国大陆手机号正则
      if (!value) {
        callback(new Error('请输入手机号'));
      } else if (!phoneRegex.test(value)) {
        callback(new Error('请输入正确的手机号'));
      } else {
        callback();
      }
    }
  }
};
</script>

<style>
.register-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-image: url('@/assets/background_01.jpeg');
  background-size: cover;
}

.register-card {
  width: 400px;
  padding: 20px;
  background-color: rgba(255, 255, 255, 0.9);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

h2 {
  text-align: center;
  margin-bottom: 20px;
}

.register-form {
  margin-top: 20px;
}
</style>
