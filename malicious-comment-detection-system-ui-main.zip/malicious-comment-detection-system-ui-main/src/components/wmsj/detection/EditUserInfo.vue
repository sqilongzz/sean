<template>
  <div class="edit-user-info">
    <div class="header">
      <h3>个人信息</h3>
      <el-button plain @click="goBack" class="back-button">返回</el-button>
    </div>
    <el-form ref="userForm" class="form-container">
      <el-form-item label="昵称">
        <span>{{ userInfo.nickname }}</span>
      </el-form-item>

      <el-form-item label="电话">
        <span>{{ userInfo.phone }}</span>
      </el-form-item>

      <el-form-item label="邮箱">
        <span>{{ userInfo.email }}</span>
      </el-form-item>

      <div class="button-container">
        <el-button type="primary" @click="openEditDialog">
          修改个人信息
        </el-button>
        <el-button type="primary" @click="changePasswordDialogVisible = true">
          修改密码
        </el-button>
      </div>
    </el-form>

    <!-- 修改个人信息的弹窗 -->
    <el-dialog v-model="editInfoDialogVisible" title="修改个人信息" width="500">
      <el-form :model="tempUserInfo">
        <el-form-item label="昵称" :label-width="formLabelWidth" prop="nickname">
          <el-input v-model="tempUserInfo.nickname" placeholder="请输入昵称" type="tel"></el-input>
        </el-form-item>

        <el-form-item label="电话" :label-width="formLabelWidth" prop="phone">
          <el-input v-model="tempUserInfo.phone" placeholder="请输入电话" type="tel"></el-input>
        </el-form-item>

        <el-form-item label="邮箱" :label-width="formLabelWidth" prop="email">
          <el-input v-model="tempUserInfo.email" placeholder="请输入邮箱" type="email"></el-input>
        </el-form-item>
      </el-form>

      <template #footer>
        <div class="dialog-footer">
          <el-button @click="cancelEdit">取消</el-button>
          <el-button type="primary" @click="updateUserInfo">保存</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 修改密码的弹窗 -->
    <el-dialog v-model="changePasswordDialogVisible" title="修改密码" width="500">
      <el-form :model="form" :rules="rules" ref="changePasswordForm">
        <el-form-item label="旧密码" :label-width="formLabelWidth" prop="oldPassword">
          <el-input v-model="form.oldPassword" type="password" placeholder="请输入旧密码"></el-input>
        </el-form-item>

        <el-form-item label="新密码" :label-width="formLabelWidth" prop="newPassword">
          <el-input v-model="form.newPassword" type="password" placeholder="请输入新密码"></el-input>
        </el-form-item>

        <el-form-item label="确认新密码" :label-width="formLabelWidth" prop="confirmPassword">
          <el-input v-model="form.confirmPassword" type="password" placeholder="请确认新密码"></el-input>
        </el-form-item>
      </el-form>

      <template #footer>
        <div class="dialog-footer">
          <el-button @click="cancelChangePassword">取消</el-button>
          <el-button type="primary" @click="savePasswordChanges">保存</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      userInfo: {
        userName: '',
        nickname:'',
        phone: '',
        email: '',
      },
      tempUserInfo: {},
      editInfoDialogVisible: false,
      changePasswordDialogVisible: false,
      form: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: '',
      },
      rules: {
        oldPassword: [
          { required: true, message: '旧密码不能为空', trigger: 'blur' }
        ],
        newPassword: [
          { required: true, message: '新密码不能为空', trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '确认密码不能为空', trigger: 'blur' },
          { validator: this.validateConfirmPassword, trigger: 'blur' }
        ],
      },
      formLabelWidth: '140px',
    };
  },
  mounted() {
    this.fetchUserInfo();
  },
  methods: {
    validateConfirmPassword(rule, value, callback) {
      if (value !== this.form.newPassword) {
        callback(new Error('新密码和确认密码不匹配'));
      } else {
        callback();
      }
    },
    goBack() {
      this.$router.go(-1);
    },
    async fetchUserInfo() {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:8080/user/getUserInfo', {
          headers: {
            token: token
          }
        });
        this.userInfo = response.data.data;
      } catch (error) {
        console.error('获取用户信息失败:', error);
      }
    },
    openEditDialog() {
      this.tempUserInfo = { ...this.userInfo };
      this.editInfoDialogVisible = true;
    },
    cancelEdit() {
      this.editInfoDialogVisible = false;
      this.tempUserInfo = {};
    },
    async updateUserInfo() {
      try {
        const token = localStorage.getItem('token');
        await axios.post('http://localhost:8080/user/updateUserInfo', this.tempUserInfo, {
          headers: {
            token: token
          }
        });
        this.userInfo = { ...this.tempUserInfo };
        this.$message.success('用户信息更新成功');
        this.editInfoDialogVisible = false;
      } catch (error) {
        this.$message.error('更新失败，请重试');
      }
    },
    savePasswordChanges() {
      this.$refs.changePasswordForm.validate((valid) => {
        if (valid) {
          this.changePassword();
        } else {
          this.$message.error('请检查输入的信息');
        }
      });
    },
    async changePassword() {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:8080/user/updatePassword', {
        oldPassword: this.form.oldPassword,
        newPassword: this.form.newPassword,
      }, {
        headers: {
          token: token
        }
      })
          .then(response => {
            console.log('修改密码结果:', response.data);
            if (response.data.data.code === 200) {
              this.$message.success('修改密码成功,请重新登录');
              localStorage.removeItem('token');
              this.$router.push('/');
            } else {
              // 显示错误信息
              this.$message.error(response.data.data.msg);
            }
          })
          .catch(error => {
            console.error('修改密码失败:', error);
            this.$message.error("修改密码请求失败");
          });
      this.changePasswordDialogVisible = false;
    },
    cancelChangePassword() {
      this.changePasswordDialogVisible = false;
      this.form.oldPassword = ''; // 清空旧密码
      this.form.newPassword = ''; // 清空新密码
      this.form.confirmPassword = ''; // 清空确认密码
    }
  },
};
</script>

<style scoped>
.edit-user-info {
  max-width: 400px;
  margin: 0 auto;
  padding: 30px;
  border-radius: 8px;
  background-color: #ffffff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.back-button {
  font-size: 14px;
}
.button-container {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}
.el-form-item {
  margin-bottom: 15px;
}
</style>
