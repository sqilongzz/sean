<template>
  <div class="login-container">
    <div class="overlay"></div>
    <el-card class="login-card" :body-style="{ padding: '20px' }">
      <h2>登录</h2>
      <el-form :model="form" class="login-form">
        <el-form-item>
          <el-input v-model="form.userName" placeholder="username" class="input-field"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.password" type="password" placeholder="password" class="input-field"></el-input>
        </el-form-item>
        <el-form-item class="button-group">
          <div class="button-container">
            <el-button type="primary" @click="login">登录</el-button>
            <el-button @click="register">注册</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      form: {
        userName: '',
        password: ''
      }
    };
  },
  methods: {
    login() {
      axios.get('http://localhost:8080/user/login', {
        params: {
          userName: this.form.userName,
          password: this.form.password
        }
      })
          .then(response => {
            console.log('登录结果:', response.data);
            if (response.data.code === 200) {
              localStorage.setItem('token', response.data.data.token);
              // localStorage.setItem('nickname', response.data.data.nickname);
              this.$router.push('/index');
            } else {
              // 显示错误信息
              this.$message.error(response.data.msg);
            }
          })
          .catch(error => {
            console.error('登录失败:', error);
            this.$message.error("登录请求失败");
          });
    },
    register() {
      // 注册逻辑
      this.$router.push('/register')
    }
  }
};
</script>

<style>

h2 {
  text-align: center; /* 居中对齐 */
}

.login-container {
  position: relative;
  background-image: url('@/assets/background_02.jpeg');
  background-size: cover;
  background-position: center;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('~@/assets/background_02.jpeg');
  opacity: 0.5; /* 设置透明度 */
  background-size: cover;
  background-position: center;
  z-index: 1; /* 确保覆盖在背景之上 */
  color: silver;
}

.login-card {
  position: relative;
  z-index: 2; /* 确保登录卡片在overlay之上 */
  opacity: 1; /* 调整透明度，0.8为80%不透明 */
  width: 400px; /* 设置宽度为400px，可以根据需要调整 */
}

.input-field {
  width: 300px; /* 调整宽度 */
}

.input-field .el-input__inner {
  text-align: center; /* 确保输入内容居中 */
}

.login-form {
  margin-top: 20px; /* 可根据需要调整距离 */
  margin-left: 30px;
}

.button-group {
  display: flex; /* 使用flex布局 */
  justify-content: center; /* 居中按钮 */
  margin-top: 20px; /* 可根据需要调整距离 */
  gap: 10px; /* 按钮之间的间距 */
}

.button-container {
  display: flex; /* 按钮容器使用flex布局 */
  justify-content: center; /* 居中按钮 */
  width: 100%; /* 让按钮容器宽度填满 */
}
</style>
