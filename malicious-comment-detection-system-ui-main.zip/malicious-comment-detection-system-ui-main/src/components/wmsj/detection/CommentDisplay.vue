<template>
  <div>
    <el-table :data="paginatedComments" border>
      <el-table-column prop="user" label="用户" width="180"></el-table-column>
      <el-table-column prop="text" label="评论内容"></el-table-column>
      <el-table-column label="操作" width="180">
        <template #default="scope">
          <el-button type="danger" @click="deleteComment(scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
        :current-page="currentPage"
        :page-size="commentsPerPage"
        :total="comments.length"
        @current-change="handleCurrentChange"
        layout="prev, pager, next">
    </el-pagination>
  </div>
</template>

<script>
export default {
  data () {
    return {
      comments: [
        { user: '用户1', text: '这真是个好项目！' },
        { user: '用户2', text: '我觉得有点不太好。' },
        {user: '用户4', text: '这是什么鬼东西？'},
        {user: '用户5', text: '非常有趣的想法！'},
        {user: '用户6', text: '这真的很糟糕。'},
        {user: '用户7', text: '这个系统真是太棒了！'},
        {user: '用户8', text: '我喜欢这个界面，简洁明了。'},
        {user: '用户9', text: '希望能增加更多功能。'},
        {user: '用户10', text: '我对这个项目的前景很乐观。'},
        {user: '用户11', text: '使用体验不错，但可以改进。'},
        {user: '用户12', text: '这项技术真的很有前途！'},
        {user: '用户13', text: '我在使用过程中遇到了一些bug。'},
        {user: '用户14', text: '非常期待未来的更新。'},
        {user: '用户15', text: '这个项目有点像以前的一个，我不太喜欢。'},
        {user: '用户16', text: '感谢开发团队的努力，赞一个！'},
        {user: '用户17', text: '这是我见过的最糟糕的应用。'},
        {user: '用户18', text: '我觉得功能不够全面。'},
        {user: '用户19', text: '这个项目的理念很不错，值得支持。'},
        {user: '用户20', text: '感觉这个系统不够智能，差评。'},
        {user: '用户21', text: '我会推荐给我的朋友们的。'},
        {user: '用户22', text: '希望能看到更多的更新和改进。'},
        {user: '用户23', text: '恶意评论的检测效果还需提升。'},
        {user: '用户24', text: '这个项目对我很有帮助，感谢开发者！'},
        {user: '用户25', text: '实在是太差劲了，根本无法使用。'},
        {user: '用户26', text: '这个功能很实用，希望可以继续优化。'},
        {user: '用户27', text: '觉得这款软件是个失败的项目。'},
        {user: '用户28', text: '界面设计得很美观，使用流畅。'},
        {user: '用户29', text: '这个项目让我失望了。'},
        {user: '用户30', text: '非常感谢开发者，继续加油！'},
        {user: '用户31', text: '我会推荐给我的朋友们的。'},
        {user: '用户32', text: '希望能看到更多的更新和改进。'},
      ],
      currentPage: 1,
      commentsPerPage: 10
    }
  },
  computed: {
    paginatedComments () {
      const start = (this.currentPage - 1) * this.commentsPerPage
      return this.comments.slice(start, start + this.commentsPerPage)
    }
  },
  methods: {
    deleteComment (index) {
      this.comments.splice((this.currentPage - 1) * this.commentsPerPage + index, 1)
    },
    handleCurrentChange (page) {
      this.currentPage = page
    }
  }
}
</script>

<style scoped>
h2 {
  margin-bottom: 20px;
}
</style>