<!-- src/components/CounterComponent.vue -->
<template>
  <div>
    <h1>{{ title }}</h1>
    <p>当前计数：{{ count }}</p>
    <button @click="increment">增加计数</button>
  </div>
</template>

<script>
export default {
  name: 'CounterComponent',
  data () {
    return {
      title: '计数器',
      count: 0
    }
  },
  methods: {
    increment () {
      this.count += 1
    }
  }
}
</script>

<style scoped>
h1 {
  color: #42b983;
}

button {
  margin-top: 10px;
}
</style>
