<template>
  <div class="home-container">
    系统管理
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  data() {
    return {};
  },
  methods: {
    // 可在此处添加方法
  },
};
</script>

<style scoped>
.home-container {
  padding: 20px;
  font-family: Arial, sans-serif;
  text-align: left; /* 确保容器内文本左对齐 */
}

h2 {
  color: #666; /* 设置标题为灰色 */
  font-size: 24px;
  margin-bottom: 10px;
  text-align: left; /* 标题左对齐 */
}

.description {
  color: #666;
  font-size: 16px;
  margin: 10px 0;
  line-height: 1.6;
}
</style>
