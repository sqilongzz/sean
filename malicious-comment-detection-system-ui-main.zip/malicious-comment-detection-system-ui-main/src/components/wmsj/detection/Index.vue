<template>
  <el-container id="app">
    <!-- 侧边栏 -->
    <el-aside class="sidebar" width="220px" :style="{ display: sidebarVisible ? 'block' : 'none' }">

      <!-- 菜单 -->
      <el-menu :default-active="activeTab" class="tab-menu" @select="handleTabSelect">
        <el-menu-item index="homePage">首页</el-menu-item>
        <el-menu-item index="CommentDbManager/tab1">样本数据库管理</el-menu-item>
        <el-menu-item index="backdoorAttack">后门攻击测评</el-menu-item>
        <el-menu-item index="backdoorDefense">后门防御测评</el-menu-item>
        <el-menu-item index="CommentStatisticalAnalysis/tab1">测评结果统计分析</el-menu-item>
      </el-menu>
    </el-aside>

    <!-- 内容区域 -->
    <el-container class="content">
      <!-- 头部区域 -->
      <el-header>
        <div class="header-content">
          <!-- 侧边栏切换按钮 -->
          <el-button @click="toggleSidebar" class="sidebar-toggle-btn" type="text">
            <el-icon :size="20">
              <!-- 图标切换 -->
              <i :class="sidebarVisible ? 'el-icon-s-fold' : 'el-icon-s-unfold'"></i>
            </el-icon>
          </el-button>

          <!-- 用户信息 -->
          <div>
            <!-- 用户头像 -->
            <img src="@/assets/profile_02.jpg" alt="avatar" style="width: 30px; height: 30px; border-radius: 50%; margin-right: 8px;" />
            <el-dropdown placement="top-start">
              <el-button> {{ userInfo.nickname }} </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <!-- 登出操作 -->
                  <el-dropdown-item @click="logout">登出账号</el-dropdown-item>
                  <!-- 编辑用户信息操作 -->
                  <el-dropdown-item @click="editUserInfo">个人信息</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </div>
      </el-header>

      <!-- Tab 页签 -->
      <el-tabs v-model="activeTab" type="card" closable @tab-remove="removeTab">
        <!-- 隐藏按钮 -->
        <el-button
            class="hide-sidebar-btn"
            @click="toggleSidebar"
            :class="{ 'button-active': !sidebarVisible }"
            :title="sidebarVisible ? '隐藏侧边栏' : '显示侧边栏'"
        >
        </el-button>
        <el-tab-pane v-for="(tab, index) in tabs" :key="index" :label="tab.label" :name="tab.name">
          <!-- 动态加载组件 -->
          <component :is="tab.component" />
        </el-tab-pane>
      </el-tabs>
    </el-container>
  </el-container>
</template>

<script>
import CommentHomePage from './HomePage.vue';
import CommentBackdoorAttack from './BackdoorAttrack.vue';
import CommentBackdoorDefense from './BackdoorDefense.vue';
import CommentStatisticalAnalysisTab1 from './StatisticalAnalysisTab1.vue';
import CommentStatisticalAnalysisTab2 from './StatisticalAnalysisTab2.vue';
import CommentTab1Content from "./DbManagerTab1.vue";
import CommentTab2Content from "./DbManagerTab2.vue";
import axios from "axios";

export default {
  data() {
    return {
      buttonActive: false, // 控制按钮点击状态
      activeTab: 'homePage', // 当前激活的 tab
      tabs: [
        {
          name: 'homePage', // 首页 tab
          label: '首页',
          component: CommentHomePage
        }
      ],
      userInfo: {
        nickname: '', // 用户昵称
      },
      pageTitles: {
        'homePage': '首页',
        'CommentDbManager/tab1': '样本数据库管理',
        'backdoorAttack': '后门攻击测评',
        'backdoorDefense': '后门防御测评',
        'CommentStatisticalAnalysis/tab1': '测评结果统计分析',
      },
      sidebarVisible: true, // 控制侧边栏显示或隐藏
    };
  },
  components: {
    CommentHomePage,
    CommentBackdoorAttack,
    CommentBackdoorDefense,
    CommentStatisticalAnalysisTab1,
    CommentStatisticalAnalysisTab2,
    CommentTab1Content,
    CommentTab2Content,
  },
  methods: {
    // 登出方法
    logout() {
      localStorage.removeItem('token'); // 清除 token
      this.$router.push('/'); // 跳转到登录页
      this.$message.success('登出成功'); // 弹出成功消息
    },
    // 编辑用户信息方法
    editUserInfo() {
      this.$router.push('/editUserInfo'); // 跳转到编辑页面
    },
    // 选择 tab 页签
    handleTabSelect(tabName) {
      // 如果该 tab 已经存在，直接激活该 tab
      if (this.tabs.find(tab => tab.name === tabName)) {
        this.activeTab = tabName;
        return;
      }
      // 否则新增 tab
      const newTab = {
        name: tabName,
        label: this.pageTitles[tabName] || '未知页面', // 设置 tab 的标题
        component: this.getComponentForTab(tabName) // 获取对应的组件
      };
      this.tabs.push(newTab); // 新增 tab
      this.activeTab = tabName; // 设置为当前激活的 tab
    },
    // 根据 tab 名获取对应的组件
    getComponentForTab(tabName) {
      switch (tabName) {
        case 'homePage':
          return CommentHomePage;
        case 'CommentDbManager/tab1':
          return CommentTab1Content;
        case 'backdoorAttack':
          return CommentBackdoorAttack;
        case 'backdoorDefense':
          return CommentBackdoorDefense;
        case 'CommentStatisticalAnalysis/tab1':
          return CommentStatisticalAnalysisTab1;
        case 'CommentStatisticalAnalysis/tab2':
          return CommentStatisticalAnalysisTab2;
        default:
          return null;
      }
    },
    // 移除 tab 页签
    removeTab(targetName) {
      const index = this.tabs.findIndex(tab => tab.name === targetName);
      if (index !== -1) {
        this.tabs.splice(index, 1); // 删除 tab
      }
    },
    // 获取用户信息
    async fetchUserInfo() {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:8080/user/getUserInfo', {
          headers: {token} // 带上 token
        });
        this.userInfo = response.data.data; // 设置用户信息
      } catch (error) {
        console.error('获取用户信息失败:', error); // 捕获并打印错误
      }
    },
    // 切换侧边栏显示与隐藏
    toggleSidebar() {
      this.sidebarVisible = !this.sidebarVisible; // 切换侧边栏状态
      this.buttonActive = !this.buttonActive; // 切换按钮状态
    },
  },
  mounted() {
    this.fetchUserInfo(); // 页面加载时获取用户信息
  }
};
</script>

<style>
html, body {
  height: 100%; /* 设置页面高度为100% */
  margin: 0; /* 移除默认外边距 */
}

#app {
  height: 100vh; /* 设置根元素高度为视口高度 */
}

.sidebar {
  background-color: #f8f9fa; /* 侧边栏背景色 */
  padding: 20px; /* 侧边栏内边距 */
  position: relative; /* 使隐藏按钮可以定位 */
}

.tab-menu {
  margin-top: 20px; /* 设置菜单的上边距 */
}

.hide-sidebar-btn {
  position: absolute; /* 定位隐藏按钮 */
  top: 10px;
  right: -15px;
  z-index: 1000; /* 确保按钮在最上层 */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 按钮阴影 */
  background-color: grey; /* 默认背景色 */
  color: darkslategrey; /* 默认文字颜色 */
  transition: background-color 0.3s ease, color 0.3s ease; /* 按钮颜色变化过渡 */
}

.hide-sidebar-btn:hover {
  filter: brightness(1.1); /* 鼠标悬停时亮度增加 */
}

.button-active {
  background-color: #ff5722; /* 隐藏后的按钮颜色 */
  color: red; /* 隐藏后的文字颜色 */
}

.content {
  padding: 20px; /* 内容区域内边距 */
  background-color: #ffffff; /* 背景颜色 */
  overflow-y: auto; /* 内容溢出时出现滚动条 */
}

.header-content {
  display: flex; /* 使用 flex 布局 */
  justify-content: space-between; /* 两侧对齐 */
  align-items: center; /* 垂直居中 */
}

.sidebar-toggle-btn {
  padding: 0; /* 去除按钮的内边距 */
  border: none; /* 去除按钮的边框 */
}
</style>
