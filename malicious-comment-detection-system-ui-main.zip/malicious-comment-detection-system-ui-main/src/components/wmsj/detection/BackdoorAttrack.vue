<template>
  <div class="container">
    <!-- 左侧列 -->
    <div class="left-column">
      <!-- 攻击类型 -->
      <el-form-item label="攻击类型">
        <el-radio-group v-model="form.attackType">
          <el-radio label="词级别">词级别</el-radio>
          <el-radio label="句级别">句级别</el-radio>
        </el-radio-group>
      </el-form-item>

      <!-- 后门攻击算法 -->
      <el-form-item label="攻击算法">
        <el-checkbox-group v-model="form.alg">
          <el-checkbox :value="'Trojaning Attack'">Trojaning Attack</el-checkbox>
          <el-checkbox :value="'RareWord'">RareWord</el-checkbox>
          <el-checkbox :value="'RIPPLe'">RIPPLe</el-checkbox>
          <el-checkbox :value="'InsertSent'">InsertSent</el-checkbox>
          <el-checkbox :value="'HiddenKiller'">HiddenKiller</el-checkbox>
          <el-checkbox :value="'StyleBkd'">StyleBkd</el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <!-- 数据集 -->
      <el-form-item label="数据集">
        <el-checkbox-group v-model="form.dataSet">
          <el-checkbox :value="'IMDB'">IMDB</el-checkbox>
          <el-checkbox :value="'AG NEWS'">AG NEWS</el-checkbox>
          <el-checkbox :value="'SST'">SST</el-checkbox>
          <el-checkbox :value="'OLID'">OLID</el-checkbox>
          <el-checkbox :value="'Amazon'">Amazon</el-checkbox>
          <el-checkbox :value="'Jigsaw 2018'">Jigsaw 2018</el-checkbox>
          <el-checkbox :value="'Hatespeech-Twitter'">Hatespeech-Twitter</el-checkbox>
          <el-checkbox :value="'Lingspam'">Lingspam</el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <!-- 受害目标模型 -->
      <el-form-item label="受害目标模型">
        <el-checkbox-group v-model="form.targetModel">
          <el-checkbox :value="'Transformer'">Transformer</el-checkbox>
          <el-checkbox :value="'BERT'">BERT</el-checkbox>
          <el-checkbox :value="'Bi-LSTM'">Bi-LSTM</el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <!-- 投毒率 -->
      <el-form-item label="投毒率">
        <el-input v-model="form.poisoningRate" placeholder="请输入内容"></el-input>
      </el-form-item>

      <!-- 开始评测和取消任务按钮 -->
      <el-form-item>
        <el-button type="primary" @click="startEvaluation" :disabled="loading">开始评测</el-button>
        <!--        <el-button type="danger" @click="cancelTask" v-if="showProgress">取消任务</el-button>-->
        <el-button type="danger" @click="cancelTask" v-if="showCancelButton">取消任务</el-button>

      </el-form-item>
    </div>

    <!-- 右侧列 -->
    <div class="right-column">
      <el-form :model="trainingParams" label-width="120px">
        <el-row :gutter="20">
          <el-col :span="17">
            <el-form-item label="训练集">
              <el-input v-model="trainingParams.trainingSet" placeholder="请输入内容"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="17">
            <el-form-item label="学习率">
              <el-input v-model="trainingParams.learningRate" placeholder="请输入内容"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="17">
            <el-form-item label="批次大小">
              <el-input v-model="trainingParams.batchSize" placeholder="请输入内容"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="17">
            <el-form-item label="迭代次数">
              <el-input v-model="trainingParams.epochs" placeholder="请输入内容"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <!-- 加载弹框 -->
    <el-dialog v-model="loadingDialogVisible" title="后台执行任务中" width="30%">
      <div class="loading-container">
        <el-icon class="loading-icon">
          <Loading/>
        </el-icon>
        <span>正在执行后台任务，请稍后...</span>
      </div>
    </el-dialog>

    <!-- 进度条 -->
    <div v-if="showProgress" class="progress-container">
      <el-progress :percentage="progress" :status="progressStatus" :stroke-width="20"></el-progress>
    </div>
  </div>
</template>
<script>
import axios from "axios";
import {ElMessage} from "element-plus";
import {Loading} from "@element-plus/icons-vue";

export default {
  data() {
    return {
      form: {
        type: "1",
        attackType: "",
        alg: [],
        dataSet: [],
        targetModel: [],
        poisoningRate: "",
      },
      trainingParams: {
        trainingSet: "",
        learningRate: "",
        batchSize: "",
        epochs: "",
      },
      // 状态控制变量
      loading: false,
      loadingDialogVisible: false,
      showProgress: false,
      showCancelButton: false, // 控制取消按钮的显示
      progress: 0,
      progressStatus: "",
      progressInterval: null,
      currentTaskId: "",
    };
  },
  methods: {
    // 验证表单
    validateForm() {
      if (!this.form.type) {
        ElMessage.error("请选择攻击类型");
        return false;
      }
      if (!this.form.alg.length) {
        ElMessage.error("请选择至少一个攻击算法");
        return false;
      }
      if (!this.form.dataSet.length) {
        ElMessage.error("请选择至少一个数据集");
        return false;
      }
      return true;
    },

    // 开始评测任务
    async startEvaluation() {
      if (!this.validateForm()) return;

      this.loading = true;
      this.loadingDialogVisible = true;
      this.progress = 0;
      this.showCancelButton = true; // 显示取消按钮

      try {
        const {data} = await axios.post("http://localhost:8080/task/attack/start", {
          form: this.form,
          trainingParams: this.trainingParams,
        });
        console.log("taskId：", data.taskId);
        if (data.success && data.taskId) {
          this.currentTaskId = data.taskId;
          ElMessage.success("后台任务已启动！");
          this.showProgress = true;
          this.fetchProgress();
        } else {
          throw new Error("任务启动失败");
        }
      } catch (error) {
        ElMessage.error("任务启动失败，请重试");
      } finally {
        this.loading = false;
        this.loadingDialogVisible = false;
      }
    },

    // 获取任务进度
    async fetchProgress() {
      this.progressInterval = setInterval(async () => {// 开始定时执行
        try {
          const {data} = await axios.get("http://localhost:8080/task/attack/progress");
          // 假设我们只关心一个任务的进度
          const taskProgress = data[this.currentTaskId]; // 获取当前任务的进度

          if (taskProgress !== undefined) {
            this.progress = taskProgress; // 更新进度
          } else {
            // 如果任务进度数据为空
            this.progressStatus = "exception";
            ElMessage.error("任务进度未找到");
            clearInterval(this.progressInterval);
          }

          if (this.progress >= 100) {
            clearInterval(this.progressInterval);
            this.showProgress = false;      // 隐藏进度条
            this.showCancelButton = false;  // 隐藏取消按钮
            this.progressStatus = "success";
            ElMessage.success("任务执行完成！");

          }
        } catch (error) {
          clearInterval(this.progressInterval);
          this.progressStatus = "exception";
          ElMessage.error("获取进度失败");
        }
      }, 1000);// 每 1000ms (1秒) 执行一次
    },


    // 取消任务并隐藏进度条
    async cancelTask() {
      try {
        // 如果使用这种方式需要后端改成请求体的方式@RequestBody
        await axios.post("http://localhost:8080/task/attack/cancel", {
          taskId: this.currentTaskId,
        });
        // @RequestParam("taskId") String taskId
        // await axios.post(`http://localhost:8080/task/attack/cancel?taskId=${this.currentTaskId}`);
        ElMessage.success("任务已取消");
        ElMessage.success("任务已取消");
        this.resetProgress(); // 重置进度条
        this.showCancelButton = false; // 显示取消按钮
      } catch (error) {
        ElMessage.error("取消任务失败，请重试");
      }
    },

    // 重置进度条
    resetProgress() {
      this.showProgress = false;
      this.progress = 0;
      this.progressStatus = "";
      clearInterval(this.progressInterval);
    },
  },
  beforeUnmount() {
    clearInterval(this.progressInterval);
  },
};
</script>

<style scoped>
.container {
  display: flex;
  justify-content: space-between;
  margin: 20px;
  padding: 20px;
  background-color: #f4f7fc;
  border-radius: 10px;
}

.left-column {
  flex: 3;
}

.right-column {
  flex: 2;
  padding-left: 20px;
}

.loading-container {
  display: flex;
  align-items: center;
  gap: 10px;
  justify-content: center;
}

.progress-container {
  margin-top: 20px;
}
</style>
