<template>
  <el-container class="content">
    <!-- 顶部搜索与操作栏 -->
    <el-header class="header">
      <el-input
          v-model="searchQuery"
          placeholder="请输入关键词"
          clearable
          prefix-icon="el-icon-search"
          class="search-input-short"
          @keyup.enter="fetchTableData"
      />
      <el-button type="primary" @click="fetchTableData">搜索</el-button>
      <!--      <el-button type="primary" icon="el-icon-search" @click="fetchTableData">搜索</el-button>-->
      <!--      <el-button type="primary" @click="showDialog = true" class="action-button">新增</el-button>-->
      <el-button type="danger" @click="deleteSelected" class="action-button">删除</el-button>
      <!--      <el-button type="success" class="action-button">导出</el-button>-->
    </el-header>

    <!-- 数据表格与分页区域 -->
    <el-main class="main">
      <el-card shadow="hover" class="data-card">
        <el-table
            :data="tableData"
            v-loading="loading"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange"
        >
          <el-table-column type="selection" width="50"></el-table-column>
          <!--          <el-table-column prop="id" label="序号" width="60" align="center"></el-table-column>-->
          <!-- 序号列 -->
          <el-table-column
              type="index"
              label="序号"
              width="60"
              align="center"
              :index="(index) => (currentPage - 1) * pageSize + index + 1"
          ></el-table-column>
          <el-table-column prop="evaluationName" label="测评名称" width="180"></el-table-column>
          <el-table-column prop="evaluationTimeFormatted" label="测评时间" width="200"></el-table-column>
          <el-table-column prop="attackType" label="攻击方式" width="130"></el-table-column>
          <el-table-column prop="defenseType" label="防御方式" width="130"></el-table-column>
          <el-table-column prop="targetModel" label="目标模型" width="110"></el-table-column>
          <el-table-column prop="alg" label="算法" width="140"></el-table-column>
          <el-table-column prop="dataSet" label="数据集" width="130"></el-table-column>
          <el-table-column prop="poisonedSample" label="中毒样本数" width="130"></el-table-column>
          <el-table-column prop="cleanAccuracy" label="干净准确度" width="100"></el-table-column>
          <el-table-column prop="attackSuccessRate" label="攻击成功率" width="100"></el-table-column>
          <el-table-column prop="evaluationSuccessRate" label="检测成功率" width="100"></el-table-column>
          <el-table-column prop="score" label="评分" width="200"></el-table-column>

          <el-table-column prop="poisoningRate" label="投毒率" width="130"></el-table-column>
          <el-table-column prop="trainingSet" label="训练集" width="100"></el-table-column>
          <el-table-column prop="learningRate" label="学习率" width="100"></el-table-column>
          <el-table-column prop="batchSize" label="批次大小" width="100"></el-table-column>
          <el-table-column prop="epochs" label="迭代次数" width="200"></el-table-column>
        </el-table>

        <el-pagination
            background
            layout="total, sizes, prev, pager, next"
            :page-sizes="[10, 20, 50]"
            :page-size="pageSize"
            :total="total"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
        />
      </el-card>
    </el-main>

  </el-container>
</template>

<script>
import {ref, onMounted} from 'vue';
import axios from 'axios';
import {ElMessage} from 'element-plus';

export default {


  name: 'SampleDatabaseManager',
  setup() {
    const searchQuery = ref('');
    const loading = ref(false);
    const showDialog = ref(false);
    const tableData = ref([]);
    const total = ref(3);
    const pageSize = ref(10);
    const currentPage = ref(1);
    const formRef = ref(null);
    const selectedRows = ref([]);

    const handleSelectionChange = (selection) => {
      selectedRows.value = selection;
    };

    const fetchTableData = async () => {
      loading.value = true;
      try {
        const response = await axios.get('http://localhost:8080/evaluation/queryEvaluation', {
          params: {query: searchQuery.value, page: currentPage.value, size: pageSize.value},
        });
        const res = response.data;  // 后端返回的分页对象!
        console.log("分页结果", res);
        if (res.code === 200) {
          tableData.value = res.data.records;   // 表格数据
          total.value = res.data.total;         // 总记录数
          totalPages.value = res.data.pages;    // 总页数
        } else {
          ElMessage.error('状态码异常');
        }
      } catch (error) {
        // ElMessage.error('获取数据失败');
      } finally {
        loading.value = false;
      }
    };

    // 删除选中的记录
    const deleteSelected = async () => {
      if (!selectedRows.value.length) {
        ElMessage.warning('请选择要删除的数据');
        return;
      }
      try {
        const ids = selectedRows.value.map((row) => row.id);
        await axios.delete('http://localhost:8080/evaluation/deleteBatch', {
          headers: {'Content-Type': 'application/json'},
          data: ids,
        });
        ElMessage.success('删除成功');
        fetchTableData();
      } catch (error) {
        ElMessage.error('删除失败');
      }
    };

    const handleSizeChange = (newSize) => {
      pageSize.value = newSize;
      fetchTableData();
    };

    const handleCurrentChange = (newPage) => {
      currentPage.value = newPage;
      fetchTableData();
    };

    onMounted(fetchTableData);

    return {
      searchQuery,
      tableData,
      loading,
      showDialog,
      formRef,
      deleteSelected,
      total,
      pageSize,
      currentPage,
      handleSizeChange,
      handleCurrentChange,
      fetchTableData,
      handleSelectionChange
    };
  },
};
</script>

<style scoped>
.content {
  display: flex;
  flex-direction: column;
  background-color: #f5f7fa;
  height: 100%;
  padding: 20px;
  box-sizing: border-box;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding: 10px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.search-input {
  flex: 1;
  margin-right: 15px;
}

.action-button {
  margin-left: 10px;
}

.main {
  flex: 1;
}

.data-card {
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.dialog-style {
  border-radius: 10px;
}
</style>
