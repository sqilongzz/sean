<template>
  <div class="comment-container">
    <el-card class="comment-card" :body-style="{ padding: '20px' }">
      <h2>发布评论</h2>
      <el-form :model="form" class="comment-form">
        <el-form-item>
          <el-input
              v-model="form.comment"
              placeholder="请输入您的评论"
              type="textarea"
              rows="4"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitComment">发布评论</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-dialog
        title="提示"
        :visible.sync="dialogVisible"
        @close="dialogVisible = false"
    >
      <p>您的评论涉及恶意，请进行修改。</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        comment: '',
      },
      dialogVisible: false,
    };
  },
  methods: {
    submitComment() {
      if (this.isMalicious(this.form.comment)) {
        this.dialogVisible = true; // 弹出提示框
      } else {
        // 处理正常评论的逻辑
        console.log('评论发布成功:', this.form.comment);
        // 可以在这里发送评论到后端
      }
    },
    isMalicious(comment) {
      // 简单的恶意评论检查示例（可以根据需要自定义）
      const maliciousKeywords = ['恶意', '侮辱', '攻击'];
      return maliciousKeywords.some(keyword => comment.includes(keyword));
    },
  },
};
</script>

<style>
.comment-container {
  display: flex;
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中（可选） */
  flex-direction: column; /* 垂直排列 */
  height: 100vh; /* 如果需要填满整个视口 */
}
.comment-card {
  margin-top: 20px;
  width: 1000px; /* 设置宽度为600px，可以根据需要调整 */
  height: 300px;
  padding: 30px; /* 增加内边距 */
}
</style>
