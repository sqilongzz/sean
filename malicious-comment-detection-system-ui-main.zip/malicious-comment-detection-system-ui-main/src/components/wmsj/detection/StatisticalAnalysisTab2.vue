<template>
  <div>
    <!-- 顶部功能区域 -->
    <el-row :gutter="20" class="header-section">
      <el-col :span="24">
        <el-card>
          <el-row>
            <el-col :span="6">
              <div class="info-item">测试记录ID: 20240303</div>
            </el-col>
            <el-col :span="6">
              <div class="info-item">测试名称: DNN模型后门攻击安全测评</div>
            </el-col>
            <el-col :span="6">
              <div class="info-item">测试时间: 2024/03/03</div>
            </el-col>
            <el-col :span="6">
              <div class="info-item">攻击方式: 渗透网络</div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <div class="info-item">目标模型: DNN</div>
            </el-col>
            <el-col :span="6">
              <div class="info-item">后门攻击算法: BNNA</div>
            </el-col>
            <el-col :span="6">
              <div class="info-item">数据集: CICIDS2017</div>
            </el-col>
            <el-col :span="6">
              <div class="info-item">后门防御算法: Pruning</div>
            </el-col>
          </el-row>
        </el-card>
      </el-col>
    </el-row>

    <!-- 攻击与防御结果 -->
    <el-row :gutter="20" class="result-section">
      <!-- 左侧：攻击结果 -->
      <el-col :span="12">
        <el-collapse v-model="activeNamesAttack">
          <el-collapse-item title="攻击结果" name="1">
            <p>预测模型干净准确率: 93.78%</p>
            <p>检测样本检测率: 78%</p>
            <p>攻击成功率: 90.91%</p>
          </el-collapse-item>
          <el-collapse-item title="攻击样本信息" name="2">
            <p>类型: DOS</p>
          </el-collapse-item>
          <el-collapse-item title="测试性能" name="3">
            <p>测试时间: 514秒</p>
          </el-collapse-item>
          <el-collapse-item title="安全性综合评分" name="4">
            <p>后门攻击防护评分: 22分</p>
          </el-collapse-item>
        </el-collapse>
      </el-col>

      <!-- 右侧：防御结果 -->
      <el-col :span="12">
        <el-collapse v-model="activeNamesDefense">
          <el-collapse-item title="防御结果" name="1">
            <p>预测模型干净准确率: 93.78%</p>
            <p>检测样本检测率: 74%</p>
            <p>攻击成功率: 92.48%</p>
          </el-collapse-item>
          <el-collapse-item title="攻击样本信息" name="2">
            <p>类型: DOS</p>
          </el-collapse-item>
          <el-collapse-item title="测试性能" name="3">
            <p>测试时间: 514秒</p>
          </el-collapse-item>
          <el-collapse-item title="安全性综合评分" name="4">
            <p>后门攻击防护评分: 5分</p>
          </el-collapse-item>
        </el-collapse>
      </el-col>
    </el-row>

    <!-- 底部操作按钮 -->
    <el-row class="footer-section">
      <el-col :span="24">
        <div class="button-group">
          <el-button type="primary">后门攻击成功样例</el-button>
          <el-button type="primary">后门攻击失败样例</el-button>
          <el-button type="danger">结果导出</el-button>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 攻击结果展开的面板
      activeNamesAttack: ["1", "2", "3", "4"],
      // 防御结果展开的面板
      activeNamesDefense: ["1", "2", "3", "4"],
    };
  },
  methods: {
    // 导出结果的逻辑
    exportResults() {
      console.log("结果导出");
    },
    // 查看攻击成功样例
    viewSuccessSamples() {
      console.log("查看攻击成功样例");
    },
    // 查看攻击失败样例
    viewFailureSamples() {
      console.log("查看攻击失败样例");
    },
  },
};
</script>

<style scoped>
.header-section {
  margin-bottom: 20px;
}

.info-item {
  font-size: 14px;
  margin-bottom: 5px;
}

.result-section .el-collapse-item {
  margin-bottom: 10px;
}

.result-section .el-col:nth-child(1) .el-collapse-item {
  background-color: #fef4f4; /* 攻击结果：浅红背景 */
}

.result-section .el-col:nth-child(2) .el-collapse-item {
  background-color: #f4f8ff; /* 防御结果：浅蓝背景 */
}

.footer-section {
  margin-top: 20px;
  text-align: center;
}

.button-group .el-button {
  margin: 0 10px;
}
</style>
