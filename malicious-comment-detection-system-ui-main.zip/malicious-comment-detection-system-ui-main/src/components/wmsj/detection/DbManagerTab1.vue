<template>
  <el-container class="content">
    <!-- 顶部搜索与操作栏 -->
    <el-header class="header">
      <!--      v-model="searchQuery": 双向绑定变量 searchQuery，用于存储输入框的值。
            placeholder="请输入关键词": 设置输入框的占位符文字，提示用户输入内容。
            clearable: 启用清空按钮，允许用户快速清除输入内容。
            prefix-icon="el-icon-search": 输入框左侧的前置图标，使用 el-icon-search 搜索图标。
            class="search-input-short": 添加自定义样式类名，用于定义输入框的外观。
            @keyup.enter="fetchTableData": 监听回车键事件，触发 fetchTableData 方法以执行搜索操作。-->
      <el-input
          v-model="searchQuery"
          placeholder="请输入关键词"
          clearable
          prefix-icon="el-icon-search"
          class="search-input-short"
          @keyup.enter="fetchTableData"
      />
      <el-button type="primary" @click="fetchTableData">搜索</el-button>
      <!--      @click="showDialog = true": 点击按钮时将变量 showDialog 设置为 true，通常用于显示一个弹窗。-->
      <!--      class="action-button": 应用一个自定义样式类，用于控制按钮外观。-->
      <el-button type="primary" @click="showDialog = true" class="action-button">新增</el-button>
      <el-button type="danger" @click="deleteSelected" class="action-button">删除</el-button>
      <!--      <el-button type="success" class="action-button">导出</el-button>-->
    </el-header>

    <!-- 数据表格与分页区域 -->
    <el-main class="main">
      <!-- "always"：卡片始终显示阴影。"hover"：仅在鼠标悬停时显示阴影。"never"：禁用阴影效果。-->
      <el-card shadow="hover" class="data-card">
        <!--        :data="tableData"：
                绑定 tableData 数据源到表格，这个数据会显示在表格中。
                tableData 是一个数组，包含所有行的数据。
                v-loading="loading"：
                v-loading 指令用于在数据加载时显示加载动画，loading 是一个布尔值，表示是否正在加载数据。
                当 loading 为 true 时，会显示加载指示器。
                border：
                添加表格的边框，使表格的单元格之间有可见的边界线。
                style="width: 100%"：
                表格的宽度设置为 100%，使其占满父容器的宽度。
                @selection-change="handleSelectionChange"：
                监听表格选择项的变化，触发 handleSelectionChange 方法。此方法可以处理选中的行数据-->
        <el-table
            :data="tableData"
            v-loading="loading"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange"
        >
          <!--type="selection"：表示这是一个选择列，用户可以通过该列选择或取消选择表格行。-->
          <el-table-column type="selection" width="50"></el-table-column>
<!--          <el-table-column prop="id" label="序号" width="60" align="center"></el-table-column>-->
          <!-- 序号列 -->
          <el-table-column
              type="index"
              label="序号"
              width="60"
              align="center"
              :index="(index) => (currentPage - 1) * pageSize + index + 1"
          ></el-table-column>
          <el-table-column prop="dbName" label="数据库名称" width="180"></el-table-column>
          <el-table-column prop="dbType" label="数据库类型" width="150"></el-table-column>
          <el-table-column prop="applicableModel" label="适用模型" width="200"></el-table-column>
          <el-table-column prop="description" label="数据集描述" width="300"></el-table-column>
          <el-table-column prop="path" label="存储路径"></el-table-column>
          <el-table-column label="操作" width="150">
            <!--在操作列中，使用了插槽 #default 来渲染每一行的“编辑”和“删除”按钮。
            scope 是一个包含当前行数据的对象，scope.row 表示当前行的数据。
            在按钮的 @click 事件中，调用了 editRecord(scope.row) 和 deleteRecord(scope.row.id) 方法，分别处理编辑和删除操作。-->
            <template #default="scope">
              <el-button type="text" size="small" @click="editRecord(scope.row)">编辑</el-button>
              <el-button type="text" size="small" @click="deleteRecord(scope.row.id)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <!--    background：
                添加背景色，使分页组件的背景与内容区分开，提升视觉效果。
                layout="total, sizes, prev, pager, next"：
                该属性指定分页组件的显示布局。它包括以下部分：
                total：显示总条目数。
                sizes：显示每页条数选择器。
                prev：显示上一页按钮。
                pager：显示页码按钮。
                next：显示下一页按钮。
                :page-sizes="[10, 20, 50]"：
                绑定每页可选择的条目数列表，用户可以选择每页显示 10、20 或 50 条数据。
                :page-size="pageSize"：
                绑定当前每页显示的条目数，pageSize 是一个变量，决定了每页显示的数据条数。
                :total="total"：
                绑定数据的总条目数，total 是一个变量，表示数据的总数，分页组件根据此值自动计算总页数。
                @size-change="handleSizeChange"：
                监听每页条数变化的事件，当用户选择不同的每页条数时，会触发 handleSizeChange 方法。
                该方法接收新的每页条数作为参数。
                @current-change="handleCurrentChange"：
                监听当前页码变化的事件，当用户切换页码时，会触发 handleCurrentChange 方法。
                该方法接收新的页码作为参数。-->
        <el-pagination
            background
            layout="total, sizes, prev, pager, next"
            :page-sizes="[10, 20, 50]"
            :page-size="pageSize"
            :total="total"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
        />
      </el-card>
    </el-main>

    <!--    通过 v-model 双向绑定 showDialog，控制对话框的显示与隐藏。-->
    <!--    custom-class="dialog-style"：为对话框自定义类名 dialog-style，用于样式定制。-->

    <!-- 新增/编辑对话框 -->
    <el-dialog
        title="新增/编辑样本数据库管理"
        v-model="showDialog"
        width="600px"
        custom-class="dialog-style"
        @close="resetForm"
    >
      <!--      <el-form>：用于表单输入项的封装。
              :model="form"：绑定 form 数据模型，表单项的值会与 form 对象中的属性进行双向绑定。
              :rules="rules"：绑定表单验证规则，rules 是一个对象，定义每个表单项的验证规则。
              ref="formRef"：使用 ref 属性来引用表单实例，可以在组件中直接访问该表单。
              label-width="100px"：设置表单标签的宽度为 100px。-->
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="数据库名称" prop="dbName">
          <el-input v-model="form.dbName"/>
        </el-form-item>
        <el-form-item label="数据库类型" prop="dbType">
          <el-input v-model="form.dbType"/>
        </el-form-item>
        <el-form-item label="适用模型" prop="applicableModel">
          <el-input v-model="form.applicableModel"/>
        </el-form-item>
        <el-form-item label="数据集描述" prop="description">
          <el-input type="textarea" v-model="form.description"/>
        </el-form-item>
        <el-form-item label="存储路径" prop="path">
          <el-input v-model="form.path"/>
        </el-form-item>
      </el-form>
      <!--      <template #footer>：

              自定义对话框底部的内容。
              包含两个按钮：
              取消按钮：点击时将 showDialog 设置为 false，关闭对话框。
              确定按钮：触发 submitForm 方法，提交表单数据。-->
      <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </el-container>
</template>

<script>
import {ref, onMounted} from 'vue';
import axios from 'axios';
import {ElMessage} from 'element-plus';

export default {
  name: 'SampleDatabaseManager',
  setup() {
    /*
    const count = ref(0); // 定义响应式常量 count，初始值为 0
    const increment = () => {
      count.value++; // 定义一个方法来修改 count 的值
    };
    */
    const searchQuery = ref('');
    const loading = ref(false);
    const showDialog = ref(false);
    const tableData = ref([]);
    const total = ref();
    const pageSize = ref(10);
    const currentPage = ref(1);
    const selectedRows = ref([]);
    const form = ref({
      id: '',
      dbName: '',
      dbType: '',
      applicableModel: '',
      path: '',
      description: '',
    });

    const rules = {
      dbName: [{required: true, message: '请输入数据库名称', trigger: 'blur'}],
      dbType: [{required: true, message: '请输入数据库类型', trigger: 'blur'}],
      applicableModel: [{required: true, message: '请输入适用模型', trigger: 'blur'}],
      path: [{required: true, message: '请输入存储路径', trigger: 'blur'}],
      description: [{required: true, message: '请输入数据集描述', trigger: 'blur'}],
    };

    const formRef = ref(null);

    const handleSelectionChange = (selection) => {
      selectedRows.value = selection;
    };

    // 查询列表
    const fetchTableData = async () => {
      loading.value = true;
      try {
        const response = await axios.get('http://localhost:8080/db/queryDb', {
          params: {query: searchQuery.value, page: currentPage.value, size: pageSize.value},
        });
        const res = response.data;  // 后端返回的分页对象!
        console.log("分页结果", res);
        if (res.code === 200) {
          tableData.value = res.data.records;   // 表格数据
          total.value = res.data.total;         // 总记录数
          totalPages.value = res.data.pages;    // 总页数
        } else {
          ElMessage.error('状态码异常');
        }
      } catch (error) {
        // ElMessage.error('获取数据失败');
      } finally {
        loading.value = false;
      }
    };

    // 新增或编辑数据
    // 当一个函数被标记为 async 时，它会返回一个 Promise，并且可以使用 await 关键字来处理异步操作
    // async 与 await 一起使用： async 函数可以与 await 一起使用，await 用来暂停函数的执行，直到 Promise 对象完成并返回结果。
    // await 只能在 async 函数中使用，它会让异步代码的写法变得像同步代码一样。
    // 异步错误处理： 异常会被 try...catch 捕获。因为 async 函数会返回一个 Promise，所以你可以通过 catch 来捕获错误。
    const submitForm = async () => {
      // 通过 formRef 引用访问表单实例，调用 validate 方法进行表单验证
      formRef.value.validate(async (valid) => {
        // 判断表单是否验证通过
        if (valid) {
          try {
            // 如果 form.value.id 存在，则执行编辑操作
            if (form.value.id) {
              // 使用 POST 请求编辑数据
              await axios.post('http://localhost:8080/db/update', form.value);
              ElMessage.success('编辑成功');
            } else {
              // 如果 form.value.id 不存在，执行新增操作
              await axios.post('http://localhost:8080/db/add', form.value);
              ElMessage.success('新增成功');
            }

            // 成功后重新加载数据并关闭对话框
            fetchTableData();
            showDialog.value = false;
          } catch (error) {
            // 请求失败时显示错误信息
            ElMessage.error('操作失败');
          }
        } else {
          // 如果表单验证未通过，提示用户填写完整
          ElMessage.error('请完整填写表单');
        }
      });
    };


    // 删除选中的记录
    const deleteSelected = async () => {
      if (!selectedRows.value.length) {
        ElMessage.warning('请选择要删除的数据');
        return;
      }
      try {
        const ids = selectedRows.value.map((row) => row.id);
        await axios.delete('http://localhost:8080/db/deleteBatch', {
          headers: {'Content-Type': 'application/json'},
          data: ids,
        });
        ElMessage.success('删除成功');
        fetchTableData();
      } catch (error) {
        ElMessage.error('删除失败');
      }
    };

    // 删除单个记录
    const deleteRecord = async (id) => {
      try {
        const response = await axios.delete('http://localhost:8080/db/delete', {
          params: {id},
        });
        if (response.data.code === 200) {
          ElMessage.success('删除成功');
          fetchTableData();
        } else {
          ElMessage.error(response.data.message || '删除失败');
        }
      } catch (error) {
        ElMessage.error('删除失败，请稍后重试');
      }
    };

    // 分页
    const handleSizeChange = (newSize) => {
      pageSize.value = newSize;
      fetchTableData();
    };

    const handleCurrentChange = (newPage) => {
      currentPage.value = newPage;
      fetchTableData();
    };

    // 编辑记录
    const editRecord = (row) => {
      form.value = {...row}; // 将当前行数据填充到表单中
      showDialog.value = true; // 打开编辑弹窗
    };

    // 重置表单
    const resetForm = () => {
      form.value = {
        id: '',
        dbName: '',
        dbType: '',
        applicableModel: '',
        path: '',
        description: '',
      };
    };

    // onMounted 是 Vue 3 中的一个生命周期钩子，用于在组件挂载到 DOM 后执行某些操作。
    // 它是 Composition API 的一部分，属于 Vue 3 的 vue 模块，用来代替 Vue 2 中的 mounted 钩子
    onMounted(fetchTableData);

    return {
      searchQuery,
      tableData,
      loading,
      showDialog,
      form,
      rules,
      formRef,
      resetForm,
      submitForm,
      deleteSelected,
      total,
      pageSize,
      currentPage,
      handleSizeChange,
      handleCurrentChange,
      fetchTableData,
      deleteRecord,
      editRecord,
      handleSelectionChange,
    };
  },
};
</script>

<style scoped>
.content {
  display: flex; /* 设置为弹性布局，用于布局子元素 */
  flex-direction: column; /* 子元素排列方向为纵向（从上到下） */
  background-color: #f5f7fa; /* 背景颜色，浅灰色，提升页面层次感 */
  height: 100%; /* 高度占满父元素 */
  padding: 20px; /* 内边距为 20px，用于内容与边框之间的距离 */
  box-sizing: border-box; /* 包含内边距和边框在内的总宽高计算 */
}

.header {
  display: flex; /* 设置为弹性布局，便于子元素的排列和分布 */
  justify-content: space-between; /* 子元素在水平方向两端对齐，之间保持最大间距 */
  align-items: center; /* 子元素在垂直方向居中对齐 */
  margin-bottom: 20px; /* 底部外边距，分隔与下面内容的距离 */
  padding: 10px; /* 内边距，为内容与容器边缘提供间隔 */
  background-color: #fff; /* 背景颜色设置为白色 */
  border-radius: 10px; /* 圆角边框，增加视觉柔和感 */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* 添加阴影效果，提升层次感和立体感 */
}


/*.search-input-short {
  width: 20px; !* 设置输入框的宽度为 20px *!
  height: 40px; !* 保持输入框的高度适中 *!
  font-size: 14px; !* 输入文字大小 *!
  border-radius: 4px; !* 设置轻微的圆角 *!
  border: 1px solid #dcdfe6; !* 边框颜色 *!
  padding-left: 5px; !* 设置内边距，避免文字贴边 *!
  transition: all 0.3s ease; !* 添加过渡效果 *!
  overflow: hidden; !* 如果内容超出范围，则隐藏 *!
}

.search-input-short:focus {
  width: 120px; !* 聚焦时自动展开宽度 *!
  border-color: #409eff; !* 聚焦时边框颜色变为主题色 *!
  box-shadow: 0 0 5px rgba(64, 158, 255, 0.5); !* 添加聚焦效果的光晕 *!
}*/


.search-input {
  flex: 1;
  margin-right: 15px;
}

.action-button {
  margin-left: 10px;
}

.main {
  flex: 1; /* 弹性布局中占据剩余空间，等比例拉伸 */
}

.data-card {
  padding: 20px; /* 内边距，保证内容不贴边 */
  background-color: #fff; /* 背景颜色为白色，通常用于卡片样式 */
  border-radius: 10px; /* 圆角边框，增加视觉柔和感 */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* 添加阴影效果，提升立体感 */
}


.dialog-style {
  border-radius: 10px;
}
</style>
