import { createRouter, createWebHistory } from 'vue-router'; // 使用 ES Module 导入
import CommentClassification from '@/components/wmsj/detection/CommentClassification.vue';
import CommentDisplay from '@/components/wmsj/detection/CommentDisplay.vue';
import Login from '@/components/wmsj/detection/Login.vue';
import Index from '@/components/wmsj/detection/Index.vue';
import EditUserInfo from '@/components/wmsj/detection/EditUserInfo.vue';
import Register from '@/components/wmsj/detection/Register.vue'
import CommentHomePage from '@/components/wmsj/detection/HomePage.vue';
import CommentAlgorithmModel from '@/components/wmsj/detection/AlgorithmModel.vue';
import CommentBenchmarkPerformance from '@/components/wmsj/detection/BenchmarkPerformance.vue';
import CommentBackdoorAttack from '@/components/wmsj/detection/BackdoorAttrack.vue';
import CommentBackdoorDefense from '@/components/wmsj/detection/BackdoorDefense.vue';
import CommentStatisticalAnalysisTab1 from '@/components/wmsj/detection/StatisticalAnalysisTab1.vue';
import CommentStatisticalAnalysisTab2 from '@/components/wmsj/detection/StatisticalAnalysisTab2.vue';
import CommentSystemManager from '@/components/wmsj/detection/SystemManager.vue';
import CommentTab1Content from "@/components/wmsj/detection/DbManagerTab1.vue";
import CommentTab2Content from "@/components/wmsj/detection/DbManagerTab2.vue";

// 定义路由
const routes = [
  {
    path: '/classification',
    name: 'Classification',
    component: CommentClassification
  },
  {
    path: '/display',
    name: 'Display',
    component: CommentDisplay
  },
  {
    path: '/',
    name: 'Login',
    component: Login
  },
  {
    path: '/index',
    name: 'Index',
    component: Index
  },
  {
    path: '/editUserInfo',
    name: 'EditUserInfo',
    component: EditUserInfo
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/commentHomePage',
    name: 'CommentHomePage',
    component: CommentHomePage
  },
  {
    path: '/commentAlgorithmModel',
    name: 'CommentAlgorithmModel',
    component: CommentAlgorithmModel
  },
  {
    path: '/commentBenchmarkPerformance',
    name: 'CommentBenchmarkPerformance',
    component: CommentBenchmarkPerformance
  },
  {
    path: '/commentBackdoorAttack',
    name: 'CommentBackdoorAttack',
    component: CommentBackdoorAttack
  },
  {
    path: '/commentBackdoorDefense',
    name: 'CommentBackdoorDefense',
    component: CommentBackdoorDefense
  },
  {
    path: '/CommentStatisticalAnalysis/tab1',
    name: 'CommentStatisticalAnalysisTab1',
    component: CommentStatisticalAnalysisTab1
  },
  {
    path: '/CommentStatisticalAnalysis/tab2',
    name: 'CommentStatisticalAnalysisTab2',
    component: CommentStatisticalAnalysisTab2
  },
  {
    path: '/commentSystemManager',
    name: 'CommentSystemManager',
    component: CommentSystemManager
  },
  {
    path: '/CommentDbManager/tab1',
    name: 'CommentTab1Content',
    component: CommentTab1Content
  },
  {
    path: '/CommentDbManager/tab2',
    name: 'CommentTab2Content',
    component: CommentTab2Content
  },
];

// 创建路由实例
const router = createRouter({
  history: createWebHistory(), // 使用 HTML5 History 模式
  routes
});

export default router; // 导出 router 实例

//
// import {createRouter, createWebHistory} from 'vue-router';
//
// // 动态导入组件（懒加载）
// const CommentClassification = () => import('@/components/wmsj/detection/CommentClassification.vue');
// const CommentDisplay = () => import('@/components/wmsj/detection/CommentDisplay.vue');
// const Login = () => import('@/components/wmsj/detection/Login.vue');
// const Index = () => import('@/components/wmsj/detection/Index.vue');
// const EditUserInfo = () => import('@/components/wmsj/detection/EditUserInfo.vue');
// const Register = () => import('@/components/wmsj/detection/Register.vue');
// const CommentHomePage = () => import('@/components/wmsj/detection/HomePage.vue');
// const CommentAlgorithmModel = () => import('@/components/wmsj/detection/AlgorithmModel.vue');
// const CommentBenchmarkPerformance = () => import('@/components/wmsj/detection/BenchmarkPerformance.vue');
// const CommentBackdoorAttack = () => import('@/components/wmsj/detection/BackdoorAttrack.vue');
// const CommentBackdoorDefense = () => import('@/components/wmsj/detection/BackdoorDefense.vue');
// const CommentStatisticalAnalysisTab1 = () => import('@/components/wmsj/detection/StatisticalAnalysisTab1.vue');
// const CommentStatisticalAnalysisTab2 = () => import('@/components/wmsj/detection/StatisticalAnalysisTab2.vue');
// const CommentSystemManager = () => import('@/components/wmsj/detection/SystemManager.vue');
// const CommentTab1Content = () => import('@/components/wmsj/detection/DbManagerTab1.vue');
// const CommentTab2Content = () => import('@/components/wmsj/detection/DbManagerTab2.vue');
//
// // 定义路由
// const routes = [
//     {path: '/classification', name: 'Classification', component: CommentClassification},
//     {path: '/display', name: 'Display', component: CommentDisplay},
//     {path: '/', name: 'Login', component: Login},
//     {path: '/index', name: 'Index', component: Index},
//     {path: '/editUserInfo', name: 'EditUserInfo', component: EditUserInfo},
//     {path: '/register', name: 'Register', component: Register},
//     {path: '/commentHomePage', name: 'CommentHomePage', component: CommentHomePage},
//     {path: '/commentAlgorithmModel', name: 'CommentAlgorithmModel', component: CommentAlgorithmModel},
//     {path: '/commentBenchmarkPerformance', name: 'CommentBenchmarkPerformance', component: CommentBenchmarkPerformance},
//     {path: '/commentBackdoorAttack', name: 'CommentBackdoorAttack', component: CommentBackdoorAttack},
//     {path: '/commentBackdoorDefense', name: 'CommentBackdoorDefense', component: CommentBackdoorDefense},
//     {
//         path: '/CommentStatisticalAnalysis/tab1',
//         name: 'CommentStatisticalAnalysisTab1',
//         component: CommentStatisticalAnalysisTab1
//     },
//     {
//         path: '/CommentStatisticalAnalysis/tab2',
//         name: 'CommentStatisticalAnalysisTab2',
//         component: CommentStatisticalAnalysisTab2
//     },
//     {path: '/commentSystemManager', name: 'CommentSystemManager', component: CommentSystemManager},
//     {path: '/CommentDbManager/tab1', name: 'CommentTab1Content', component: CommentTab1Content},
//     {path: '/CommentDbManager/tab2', name: 'CommentTab2Content', component: CommentTab2Content},
// ];
//
// // 创建路由实例
// const router = createRouter({
//     history: createWebHistory(),
//     routes,
// });
//
// export default router;
