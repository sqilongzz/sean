<!-- src/App.vue -->
<template>
  <div class="app-container">
    <!--是 Vue Router 提供的一个内置组件，用于显示当前路由匹配的组件视图。 它的作用是占位符，当用户访问不同的路由时，会在此处渲染相应的组件内容。-->
    <router-view />
  </div>
</template>

<script>

export default {
  name: 'App'
}
</script>

<style>
.app-container {
  height: 100vh; /* 使容器高度为视口高度 */
  width: 100vw; /* 使容器宽度为视口宽度 */
  display: flex; /* 可选：如果需要使子元素在容器内对齐 */
  flex-direction: column; /* 可选：设置子元素的排列方式 */
}
</style>
