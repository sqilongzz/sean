import { createRouter, createWebHistory } from 'vue-router'; // 使用 ES Module 导入
import Login from '@/components/wmsj/opgg/common/Login.vue';
import Index from '@/components/wmsj/opgg/Index.vue';
import EditUserInfo from '@/components/wmsj/opgg/common/EditUserInfo.vue';
import Register from "@/components/wmsj/opgg/common/Register.vue";
import OPGGHomePage from "@/components/wmsj/opgg/lol/HomePage.vue";
import OPGGHeroData from "@/components/wmsj/opgg/lol/HeroData.vue";

// 定义路由
const routes = [
  {
    path: '/',
    name: 'Login',
    component: Login
  },
  {
    path: '/index',
    name: 'Index',
    component: Index
  },
  {
    path: '/editUserInfo',
    name: 'EditUserInfo',
    component: EditUserInfo
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/homePage',
    name: 'OPGGHomePage',
    component: OPGGHomePage
  },
  {
    path: '/heroData',
    name: 'OPGGHeroData',
    component: OPGGHeroData
  },
  {
    path: '/hero-detail/:heroId',
    name: 'HeroDetail',
    component: () => import('@/components/wmsj/opgg/lol/HeroDetail.vue')
  }
];

// 创建路由实例
const router = createRouter({
  history: createWebHistory(), // 使用 HTML5 History 模式
  routes
});

export default router; // 导出 router 实例
