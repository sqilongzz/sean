import request from '@/utils/request'

// 获取英雄符文配置
export function getHeroRunes(heroId) {
  return request({
    url: `/hero/${heroId}/runes`,
    method: 'get'
  })
}

// 获取英雄召唤师技能配置
export function getHeroSummonerSpells(heroId) {
  return request({
    url: `/hero/${heroId}/summoner-spells`,
    method: 'get'
  })
} 