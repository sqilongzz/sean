<template>
  <div class="register-container">
    <el-card class="register-card">
      <div class="register-header">
        <h2>创建账号</h2>
        <p class="subtitle">加入 OP.GG 社区</p>
      </div>

      <el-form 
        :model="form" 
        :rules="rules" 
        ref="registerForm" 
        class="register-form" 
        label-position="top">
        
        <el-form-item label="用户名" prop="userName">
          <el-input 
            v-model="form.userName" 
            placeholder="请输入用户名"
            prefix-icon="el-icon-user">
          </el-input>
        </el-form-item>

        <el-form-item label="昵称" prop="nickname">
          <el-input 
            v-model="form.nickname" 
            placeholder="请输入昵称"
            prefix-icon="el-icon-user">
          </el-input>
        </el-form-item>

        <el-form-item label="邮箱" prop="email">
          <el-input 
            v-model="form.email" 
            placeholder="请输入邮箱"
            prefix-icon="el-icon-message">
          </el-input>
        </el-form-item>

        <el-form-item label="手机号" prop="phone">
          <el-input 
            v-model="form.phone" 
            placeholder="请输入手机号"
            prefix-icon="el-icon-mobile-phone">
          </el-input>
        </el-form-item>

        <el-form-item label="密码" prop="password">
          <el-input 
            v-model="form.password" 
            type="password" 
            placeholder="请输入密码"
            prefix-icon="el-icon-lock"
            show-password>
          </el-input>
        </el-form-item>

        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input 
            v-model="form.confirmPassword" 
            type="password" 
            placeholder="请确认密码"
            prefix-icon="el-icon-lock"
            show-password>
          </el-input>
        </el-form-item>

        <el-form-item label="账号类型">
          <el-radio-group v-model="form.userType" class="user-type-group">
            <el-radio label="1">普通用户</el-radio>
            <el-radio label="0">管理员</el-radio>
          </el-radio-group>
        </el-form-item>

        <div class="form-footer">
          <el-button 
            type="primary" 
            class="submit-btn" 
            @click="register" 
            :loading="loading">
            注册
          </el-button>
          <div class="login-link">
            已有账号？<a @click="goToLogin">返回登录</a>
          </div>
        </div>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      loading: false,
      form: {
        userName: '',
        nickname: '',
        userType: '1',
        email: '',
        phone: '',
        password: '',
        confirmPassword: ''
      },
      rules: {
        userName: [
          { required: true, message: '请输入用户名', trigger: 'blur' }
        ],
        nickname: [
          { required: true, message: '请输入昵称', trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: this.validatePhone, trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, message: '密码长度不能小于6位', trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '请确认密码', trigger: 'blur' },
          { validator: this.validateConfirmPassword, trigger: 'blur' }
        ]
      }
    };
  },
  methods: {
    register() {
      axios.post('http://localhost:10001/user/add', {
        userName: this.form.userName,
        nickname: this.form.nickname,
        password: this.form.password,
        email: this.form.email,
        phone: this.form.phone,
        userType: this.form.userType // 发送选中的用户类型
      })
          .then(response => {
            console.log('注册结果:', response.data);
            if (response.data.code === 200) {
              this.$router.push('/');
            } else {
              this.$message.error(response.data.msg);
            }
          })
          .catch(error => {
            console.error('注册失败:', error);
            this.$message.error("注册请求失败");
          });
    },
    validateConfirmPassword(rule, value, callback) {
      if (value !== this.form.password) {
        callback(new Error('两次输入的密码不一致'));
      } else {
        callback();
      }
    },
    goToLogin() {
      this.$router.push('/'); // 跳转到登录页面
    },
    validatePhone(rule, value, callback) {
      const phoneRegex = /^[1][3-9][0-9]{9}$/; // 中国大陆手机号正则
      if (!value) {
        callback(new Error('请输入手机号'));
      } else if (!phoneRegex.test(value)) {
        callback(new Error('请输入正确的手机号'));
      } else {
        callback();
      }
    }
  }
};
</script>

<style scoped>
.register-container {
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f7f8fa;
  padding: 20px;
}

.register-card {
  width: 460px;
  padding: 40px;
  border-radius: 12px;
  background: #ffffff;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.04);
}

.register-header {
  text-align: center;
  margin-bottom: 32px;
}

h2 {
  font-size: 24px;
  color: #2c3e50;
  margin-bottom: 8px;
  font-weight: 500;
}

.subtitle {
  color: #94a3b8;
  font-size: 14px;
}

.register-form {
  :deep(.el-form-item__label) {
    padding-bottom: 8px;
    color: #64748b;
    font-size: 14px;
  }

  :deep(.el-input__inner) {
    height: 42px;
    border-radius: 6px;
    border-color: #e2e8f0;
    transition: all 0.3s ease;
  }

  :deep(.el-input__inner:hover) {
    border-color: #cbd5e1;
  }

  :deep(.el-input__inner:focus) {
    border-color: #64b5f6;
    box-shadow: 0 0 0 2px rgba(100, 181, 246, 0.1);
  }

  :deep(.el-input__prefix) {
    left: 12px;
    color: #94a3b8;
  }
}

.user-type-group {
  display: flex;
  gap: 24px;
  
  :deep(.el-radio__label) {
    color: #64748b;
  }
  
  :deep(.el-radio__input.is-checked + .el-radio__label) {
    color: #64b5f6;
  }
  
  :deep(.el-radio__input.is-checked .el-radio__inner) {
    background-color: #64b5f6;
    border-color: #64b5f6;
  }
}

.form-footer {
  margin-top: 32px;
  text-align: center;
}

.submit-btn {
  width: 100%;
  height: 42px;
  border-radius: 6px;
  font-size: 16px;
  background: #64b5f6;
  border-color: #64b5f6;
  margin-bottom: 16px;
  transition: all 0.3s ease;
}

.submit-btn:hover {
  background: #42a5f5;
  border-color: #42a5f5;
  transform: translateY(-1px);
}

.submit-btn:active {
  transform: translateY(0);
}

.login-link {
  font-size: 14px;
  color: #64748b;
}

.login-link a {
  color: #64b5f6;
  cursor: pointer;
  text-decoration: none;
  margin-left: 4px;
  transition: color 0.3s ease;
}

.login-link a:hover {
  color: #42a5f5;
  text-decoration: underline;
}

/* 错误状态样式 */
:deep(.el-form-item.is-error .el-input__inner) {
  border-color: #ef4444;
}

:deep(.el-form-item.is-error .el-input__inner:focus) {
  box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.1);
}

:deep(.el-form-item__error) {
  color: #ef4444;
  font-size: 12px;
  padding-top: 4px;
}
</style>
