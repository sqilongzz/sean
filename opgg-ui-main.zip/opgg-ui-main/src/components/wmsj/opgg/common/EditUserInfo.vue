<template>
  <div class="edit-user-info">
    <el-card class="info-card">
      <div class="header">
        <div class="title">
          <h2>个人信息</h2>
          <p class="subtitle">查看和管理您的个人信息</p>
        </div>
        <el-button plain @click="goBack" class="back-button">
          <i class="el-icon-arrow-left"></i> 返回
        </el-button>
      </div>

      <div class="info-section">
        <div class="info-item">
          <label>昵称</label>
          <span>{{ userInfo.nickname }}</span>
        </div>

        <div class="info-item">
          <label>电话</label>
          <span>{{ userInfo.phone }}</span>
        </div>

        <div class="info-item">
          <label>邮箱</label>
          <span>{{ userInfo.email }}</span>
        </div>

        <div class="button-container">
          <el-button type="primary" @click="openEditDialog" class="action-button">
            <i class="el-icon-edit"></i> 修改个人信息
          </el-button>
          <el-button @click="changePasswordDialogVisible = true" class="action-button">
            <i class="el-icon-key"></i> 修改密码
          </el-button>
        </div>
      </div>
    </el-card>

    <!-- 修改个人信息的弹窗 -->
    <el-dialog 
      v-model="editInfoDialogVisible" 
      title="修改个人信息" 
      width="500px"
      custom-class="custom-dialog">
      <el-form :model="tempUserInfo" :rules="editRules" ref="editForm" label-position="top">
        <el-form-item label="昵称" prop="nickname">
          <el-input v-model="tempUserInfo.nickname" placeholder="请输入昵称"></el-input>
        </el-form-item>

        <el-form-item label="电话" prop="phone">
          <el-input v-model="tempUserInfo.phone" placeholder="请输入电话"></el-input>
        </el-form-item>

        <el-form-item label="邮箱" prop="email">
          <el-input v-model="tempUserInfo.email" placeholder="请输入邮箱"></el-input>
        </el-form-item>

        <div class="dialog-footer">
          <el-button @click="cancelEdit">取消</el-button>
          <el-button type="primary" @click="updateUserInfo" :loading="updating">
            保存
          </el-button>
        </div>
      </el-form>
    </el-dialog>

    <!-- 修改密码的弹窗 -->
    <el-dialog 
      v-model="changePasswordDialogVisible" 
      title="修改密码" 
      width="500px"
      custom-class="custom-dialog">
      <el-form :model="form" :rules="passwordRules" ref="changePasswordForm" label-position="top">
        <el-form-item label="旧密码" prop="oldPassword">
          <el-input 
            v-model="form.oldPassword" 
            type="password" 
            placeholder="请输入旧密码"
            show-password>
          </el-input>
        </el-form-item>

        <el-form-item label="新密码" prop="newPassword">
          <el-input 
            v-model="form.newPassword" 
            type="password" 
            placeholder="请输入新密码"
            show-password>
          </el-input>
        </el-form-item>

        <el-form-item label="确认新密码" prop="confirmPassword">
          <el-input 
            v-model="form.confirmPassword" 
            type="password" 
            placeholder="请确认新密码"
            show-password>
          </el-input>
        </el-form-item>

        <div class="dialog-footer">
          <el-button @click="cancelChangePassword">取消</el-button>
          <el-button type="primary" @click="savePasswordChanges" :loading="changingPassword">
            保存
          </el-button>
        </div>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      userInfo: {
        userName: '',
        nickname:'',
        phone: '',
        email: '',
      },
      tempUserInfo: {},
      editInfoDialogVisible: false,
      changePasswordDialogVisible: false,
      form: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: '',
      },
      rules: {
        oldPassword: [
          { required: true, message: '旧密码不能为空', trigger: 'blur' }
        ],
        newPassword: [
          { required: true, message: '新密码不能为空', trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '确认密码不能为空', trigger: 'blur' },
          { validator: this.validateConfirmPassword, trigger: 'blur' }
        ],
      },
      formLabelWidth: '140px',
    };
  },
  mounted() {
    this.fetchUserInfo();
  },
  methods: {
    validateConfirmPassword(rule, value, callback) {
      if (value !== this.form.newPassword) {
        callback(new Error('新密码和确认密码不匹配'));
      } else {
        callback();
      }
    },
    goBack() {
      this.$router.go(-1);
    },
    async fetchUserInfo() {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:10001/user/getUserInfo', {
          headers: {
            token: token
          }
        });
        this.userInfo = response.data.data;
      } catch (error) {
        console.error('获取用户信息失败:', error);
      }
    },
    openEditDialog() {
      this.tempUserInfo = { ...this.userInfo };
      this.editInfoDialogVisible = true;
    },
    cancelEdit() {
      this.editInfoDialogVisible = false;
      this.tempUserInfo = {};
    },
    async updateUserInfo() {
      try {
        const token = localStorage.getItem('token');
        await axios.post('http://localhost:10001/user/updateUserInfo', this.tempUserInfo, {
          headers: {
            token: token
          }
        });
        this.userInfo = { ...this.tempUserInfo };
        this.$message.success('用户信息更新成功');
        this.editInfoDialogVisible = false;
      } catch (error) {
        this.$message.error('更新失败，请重试');
      }
    },
    savePasswordChanges() {
      this.$refs.changePasswordForm.validate((valid) => {
        if (valid) {
          this.changePassword();
        } else {
          this.$message.error('请检查输入的信息');
        }
      });
    },
    async changePassword() {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:10001/user/updatePassword', {
        oldPassword: this.form.oldPassword,
        newPassword: this.form.newPassword,
      }, {
        headers: {
          token: token
        }
      })
          .then(response => {
            console.log('修改密码结果:', response.data);
            if (response.data.data.code === 200) {
              this.$message.success('修改密码成功,请重新登录');
              localStorage.removeItem('token');
              this.$router.push('/');
            } else {
              // 显示错误信息
              this.$message.error(response.data.data.msg);
            }
          })
          .catch(error => {
            console.error('修改密码失败:', error);
            this.$message.error("修改密码请求失败");
          });
      this.changePasswordDialogVisible = false;
    },
    cancelChangePassword() {
      this.changePasswordDialogVisible = false;
      this.form.oldPassword = ''; // 清空旧密码
      this.form.newPassword = ''; // 清空新密码
      this.form.confirmPassword = ''; // 清空确认密码
    }
  },
};
</script>

<style scoped>
.edit-user-info {
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding: 40px 20px;
  background-color: #f7f8fa;
}

.info-card {
  width: 800px;
  border-radius: 12px;
  background: #ffffff;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.04);
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  border-bottom: 1px solid #f0f0f0;
}

.title h2 {
  font-size: 24px;
  color: #2c3e50;
  margin: 0 0 8px 0;
  font-weight: 500;
}

.subtitle {
  color: #94a3b8;
  font-size: 14px;
  margin: 0;
}

.back-button {
  color: #64748b;
  border-color: #e2e8f0;
}

.back-button:hover {
  color: #64b5f6;
  border-color: #64b5f6;
  background: rgba(100, 181, 246, 0.1);
}

.info-section {
  padding: 24px;
}

.info-item {
  display: flex;
  padding: 16px;
  background: #f8fafc;
  border-radius: 8px;
  margin-bottom: 16px;
}

.info-item label {
  width: 80px;
  color: #64748b;
  font-size: 14px;
}

.info-item span {
  flex: 1;
  color: #2c3e50;
}

.button-container {
  display: flex;
  gap: 16px;
  margin-top: 24px;
}

.action-button {
  flex: 1;
  height: 42px;
  border-radius: 6px;
  font-size: 15px;
}

.action-button:first-child {
  background: #64b5f6;
  border-color: #64b5f6;
}

.action-button:first-child:hover {
  background: #42a5f5;
  border-color: #42a5f5;
}

/* 弹窗样式 */
.custom-dialog {
  border-radius: 12px;
  
  :deep(.el-dialog__header) {
    padding: 20px 24px;
    margin: 0;
    border-bottom: 1px solid #f0f0f0;
  }
  
  :deep(.el-dialog__body) {
    padding: 24px;
  }

  :deep(.el-form-item__label) {
    padding-bottom: 8px;
    color: #64748b;
    font-size: 14px;
  }

  :deep(.el-input__inner) {
    height: 42px;
    border-radius: 6px;
    border-color: #e2e8f0;
  }

  :deep(.el-input__inner:focus) {
    border-color: #64b5f6;
    box-shadow: 0 0 0 2px rgba(100, 181, 246, 0.1);
  }
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 24px;
  
  .el-button {
    height: 40px;
    padding: 0 24px;
    border-radius: 6px;
  }
  
  .el-button--primary {
    background: #64b5f6;
    border-color: #64b5f6;
  }
  
  .el-button--primary:hover {
    background: #42a5f5;
    border-color: #42a5f5;
  }
}

/* 错误状态样式 */
:deep(.el-form-item.is-error .el-input__inner) {
  border-color: #ef4444;
}

:deep(.el-form-item.is-error .el-input__inner:focus) {
  box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.1);
}
</style>
