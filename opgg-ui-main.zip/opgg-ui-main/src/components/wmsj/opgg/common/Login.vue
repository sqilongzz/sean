<template>
  <div class="login-container">
    <el-card class="login-card">
      <div class="login-header">
        <h2>欢迎回来</h2>
        <p class="subtitle">登录您的 OP.GG 账号</p>
      </div>
      
      <el-form :model="form" class="login-form" :rules="rules" ref="loginForm">
        <el-form-item prop="userName">
          <el-input 
            v-model="form.userName" 
            placeholder="用户名"
            prefix-icon="el-icon-user"
            class="custom-input">
          </el-input>
        </el-form-item>
        
        <el-form-item prop="password">
          <el-input 
            v-model="form.password" 
            type="password" 
            placeholder="密码"
            prefix-icon="el-icon-lock"
            class="custom-input"
            @keyup.enter="login">
          </el-input>
        </el-form-item>

        <div class="form-footer">
          <el-button type="primary" class="submit-btn" @click="login" :loading="loading">
            登录
          </el-button>
          <div class="register-link">
            还没有账号？<a @click="register">立即注册</a>
          </div>
        </div>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      loading: false,
      form: {
        userName: '',
        password: ''
      },
      rules: {
        userName: [
          { required: true, message: '请输入用户名', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 4, message: '密码长度不能小于4位', trigger: 'blur' }
        ]
      }
    };
  },
  methods: {
    login() {
      this.$refs.loginForm.validate(async (valid) => {
        if (!valid) return;
        
        this.loading = true;
        try {
          const response = await axios.get('http://localhost:10001/user/login', {
            params: this.form
          });
          
          if (response.data.code === 200) {
            localStorage.setItem('token', response.data.data.token);
            this.$message.success('登录成功');
            this.$router.push('/index');
          } else {
            this.$message.error(response.data.msg);
          }
        } catch (error) {
          this.$message.error('登录失败，请稍后重试');
        } finally {
          this.loading = false;
        }
      });
    },
    register() {
      this.$router.push('/register');
    }
  }
};
</script>

<style scoped>
.login-container {
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f5f5f5;
}

.login-card {
  width: 380px;
  padding: 40px;
  border-radius: 8px;
  background: #ffffff;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.login-header {
  text-align: center;
  margin-bottom: 36px;
}

h2 {
  font-size: 28px;
  color: #333;
  margin-bottom: 8px;
  font-weight: 500;
}

.subtitle {
  color: #999;
  font-size: 14px;
}

.login-form {
  margin-top: 20px;
}

.custom-input :deep(.el-input__inner) {
  height: 45px;
  border-radius: 4px;
  border-color: #dcdfe6;
}

.custom-input :deep(.el-input__prefix) {
  left: 12px;
}

.custom-input :deep(.el-input__inner:focus) {
  border-color: #00c8c8;
}

.form-footer {
  margin-top: 32px;
  text-align: center;
}

.submit-btn {
  width: 100%;
  height: 45px;
  border-radius: 4px;
  font-size: 16px;
  background: #00c8c8;
  border-color: #00c8c8;
  margin-bottom: 16px;
  transition: all 0.3s ease;
}

.submit-btn:hover {
  background: #00b3b3;
  border-color: #00b3b3;
  transform: translateY(-1px);
}

.submit-btn:active {
  transform: translateY(0);
}

.register-link {
  font-size: 14px;
  color: #666;
}

.register-link a {
  color: #00c8c8;
  cursor: pointer;
  text-decoration: none;
  margin-left: 4px;
}

.register-link a:hover {
  color: #00b3b3;
  text-decoration: underline;
}

/* 输入框focus状态的阴影效果 */
:deep(.el-input__inner:focus) {
  box-shadow: 0 0 0 2px rgba(0, 200, 200, 0.1);
}

/* 错误状态样式 */
:deep(.el-form-item.is-error .el-input__inner) {
  border-color: #f56c6c;
}

:deep(.el-form-item.is-error .el-input__inner:focus) {
  box-shadow: 0 0 0 2px rgba(245, 108, 108, 0.1);
}
</style>
