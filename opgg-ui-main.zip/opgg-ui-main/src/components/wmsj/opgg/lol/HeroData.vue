<template>
  <div class="hero-data-container">
    <!-- 英雄列表视图 -->
    <template v-if="!selectedHeroId">
      <div class="top-filter">
        <div class="filter-content">
          <!-- 版本筛选 -->
          <el-select 
            v-model="selectedVersion" 
            placeholder="选择版本" 
            @change="handleVersionChange" 
            class="filter-select"
          >
            <el-option 
              v-for="ver in ['14.17', '14.18', '15.01']" 
              :key="ver" 
              :label="`版本 ${ver}`" 
              :value="ver"
            ></el-option>
          </el-select>

          <!-- 段位筛选 -->
          <el-select 
            v-model="selectedRankLevel" 
            placeholder="选择段位" 
            @change="filterHeroes" 
            class="filter-select"
          >
            <el-option 
              v-for="rank in rankLevel" 
              :key="rank" 
              :label="rank" 
              :value="rank"
            >
              <template v-if="rank !== '全部'">
                <img 
                  :src="getRankIcon(rank)" 
                  class="rank-icon"
                >
              </template>
              <span>{{ rank }}</span>
            </el-option>
          </el-select>
        </div>
      </div>

      <div class="main-content">
        <div class="left-section">
          <!-- 搜索框 -->
          <el-input
            v-model="searchHero"
            placeholder="搜索英雄"
            prefix-icon="el-icon-search"
            clearable
            class="hero-search"
          />

          <!-- 左侧位置筛选按钮组 -->
          <div class="position-buttons">
            <button
              v-for="position in ['全部', '上单', '打野', '中单', 'ADC', '辅助']"
              :key="position"
              class="position-btn"
              :class="{ active: selectedGridPosition === position }"
              @click="selectGridPosition(position)"
            >
              {{ position }}
            </button>
          </div>

          <!-- 英雄网格 -->
          <div class="hero-grid">
            <div 
              v-for="hero in filteredGridHeroes" 
              :key="hero.heroId"
              class="hero-grid-item"
              @click="showHeroDetail(hero)"
            >
              <img :src="hero.picUrl" :alt="hero.heroName"/>
            </div>
          </div>
        </div>

        <div class="right-section">
          <el-card class="hero-data-card">
            <!-- 右侧位置筛选 -->
            <div class="position-filter">
              <div class="position-tabs">
                <div 
                  v-for="(value, name) in positionMap" 
                  :key="name"
                  :class="['position-tab', { active: selectedTablePosition === name }]"
                  @click="selectTablePosition(name)"
                >
                  {{ name }}
                </div>
              </div>
            </div>

            <!-- 英雄数据表格 -->
            <el-table 
              :data="filteredVersionHeroes" 
              v-loading="loading"
              stripe 
              :header-cell-style="headerStyle"
              class="hero-table"
            >
              <el-table-column type="index" label="排名" width="80" align="center">
                <template #default="scope">
                  <span class="rank-number" :class="{'top-rank': scope.$index + 1 <= 3}">
                    {{ scope.$index + 1 }}
                  </span>
                </template>
              </el-table-column>
              
              <el-table-column label="英雄" width="200">
                <template #default="{ row }">
                  <div class="hero-info" @click="showHeroDetail(row)">
                    <div class="hero-avatar">
                      <img :src="getHeroImageUrl(row.picUrl)" :alt="row.heroName" class="hero-image"/>
                    </div>
                    <span class="hero-name">{{ row.heroName }}</span>
                  </div>
                </template>
              </el-table-column>

              <el-table-column prop="strength" label="强度" width="120" align="center">
                <template #default="{ row }">
                  <img 
                    :src="`src/assets/lol/strength/${row.strength}.webp`" 
                    :alt="`强度${row.strength}`"
                    class="strength-icon"
                  />
                </template>
              </el-table-column>
              <el-table-column prop="heroPosition" label="位置" width="100" align="center">
                <template #default="{ row }">
                  <img 
                    :src="`src/assets/lol/position/${row.heroPosition}.webp`" 
                    :alt="positionMap[row.heroPosition]"
                    class="position-icon"
                  />
                </template>
              </el-table-column>
              <el-table-column prop="winRate" label="胜率" width="100" align="center">
                <template #default="{ row }">
                  {{ row.winRate }}%
                </template>
              </el-table-column>
              <el-table-column prop="appearanceRate" label="登场率" width="100" align="center">
                <template #default="{ row }">
                  {{ row.appearanceRate }}%
                </template>
              </el-table-column>
              <el-table-column prop="banRate" label="禁用率" width="100" align="center">
                <template #default="{ row }">
                  {{ row.banRate }}%
                </template>
              </el-table-column>

              <el-table-column label="优势对抗" width="160">
                <template #default="{ row }">
                  <div class="counter-heroes">
                    <el-tooltip 
                      v-for="hero in row.advantageAgainstList" 
                      :key="hero.picUrl" 
                      :content="hero.heroName" 
                      placement="top"
                    >
                      <img :src="getHeroImageUrl(hero.picUrl)" class="counter-hero-image"/>
                    </el-tooltip>
                  </div>
                </template>
              </el-table-column>

              <el-table-column label="劣势对抗" width="160">
                <template #default="{ row }">
                  <div class="counter-heroes">
                    <el-tooltip 
                      v-for="hero in row.inferiorityAgainstList" 
                      :key="hero.picUrl" 
                      :content="hero.heroName" 
                      placement="top"
                    >
                      <img :src="getHeroImageUrl(hero.picUrl)" class="counter-hero-image"/>
                    </el-tooltip>
                  </div>
                </template>
              </el-table-column>
            </el-table>

            <el-empty 
              v-if="!filteredVersionHeroes.length"
              description="暂无数据"
            />
          </el-card>
        </div>
      </div>
    </template>

    <!-- 英雄详情视图 -->
    <template v-else>
      <div class="back-nav">
        <el-button 
          type="text" 
          @click="backToList"
          style="margin-bottom: 16px;"
        >
          <el-icon><ArrowLeft /></el-icon> 返回英雄列表
        </el-button>
      </div>
      <hero-detail 
        :hero-id="selectedHeroId"
        :hero-data="selectedHeroData"
        @back="backToList"
      />
    </template>
  </div>
</template>

<script>
import axios from 'axios';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus'
import HeroDetail from './HeroDetail.vue'
import { ArrowLeft } from '@element-plus/icons-vue'

export default {
  components: {
    HeroDetail,
    ArrowLeft
  },
  // mounted（生命周期钩子）
  // 特点：
  // 1. 在组件被挂载到DOM后调用
  // 2. 这时候可以访问到DOM元素
  // 3. 适合进行初始化操作，比如获取数据

  // 其他生命周期钩子示例：
  // created()      组件创建完成，但还未挂载到DOM
  // beforeMount()  组件挂载到DOM之前
  // updated()      组件更新完成后

  mounted() {
    this.getHeroList();
    this.getVersionInfo();
  },
  data() {
    return {
      versionHeroes: [],          // 这个可能是多余的，因为我们只用了 filteredVersionHeroes
      filteredVersionHeroes: [],
      loading: false,
      position: ['全部', '中单', '打野', '上单', '下路', '辅助'],
      version: ['14.17', '14.18', '15.01'],
      rankLevel: ['全部', '黑铁', '青铜', '白银', '黄金', '铂金', '翡翠', '砖石', '大师', '宗师', '最强王者'],
      selectedPosition: '全部',
      selectedVersion: '14.18',
      selectedRankLevel: '翡翠',
      positionMap: {
        '全部': '',
        '上单': '1',
        '打野': '2',
        '中单': '3',
        'ADC': '4',
        '辅助': '5'
      },
      rankLevelMap: {
        '全部': '',
        '黑铁': 1,
        '青铜': 2,
        '白银': 3,
        '黄金': 4,
        '铂金': 5,
        '翡翠': 6,
        '砖石': 7,
        '大师': 8,
        '宗师': 9,
        '最强王者': 0,
      },
      headerStyle: {
        backgroundColor: '#f8fafc',
        color: '#1e293b',
        fontWeight: '600'
      },
      searchHero: '',
      selectedGridPosition: '全部',  // 左侧网格的位置筛选
      selectedTablePosition: '全部', // 右侧表格的位置筛选
      positions: [
        { id: '0', name: '全部' },
        { id: '1', name: '上单' },
        { id: '2', name: '打野' },
        { id: '3', name: '中单' },
        { id: '4', name: '下路' },
        { id: '5', name: '辅助' }
      ],
      gridHeroes: [],
      queryParams: {
        position: '',  // 默认为空
        version: '14.18',
        rankLevel: 6
      },
      router: useRouter(), // 在 data 中初始化 router
      positionNameMap: {
        '1': '上单',
        '2': '打野',
        '3': '中单',
        '4': 'ADC',
        '5': '辅助'
      },
      selectedHeroId: null,
      selectedHeroData: null,
    };
  },
  computed: {
    // 处理英雄列表的筛选和排序的计算属性
    filteredHeroes() {
      return this.heroes
        // 第一步：使用 filter 方法筛选英雄
        .filter(hero => {
          // 检查位置是否匹配
          // 如果选择"全部"，则不筛选位置；否则检查英雄位置是否匹配
          const matchesPosition = this.selectedPosition === '0' 
            ? true 
            : hero.heroPosition === this.selectedPosition;

          // 检查版本是否匹配
          // 如果选择了版本，检查是否匹配；如果没选版本，则不筛选
          const matchesVersion = this.selectedVersion 
            ? hero.version === this.selectedVersion 
            : true;

          // 同时满足位置和版本条件的英雄才会被保留
          return matchesPosition && matchesVersion;
        })
        // 第二步：使用 map 方法为筛选后的英雄添加排名
        .map((hero, index) => ({
          ...hero,           // 保留英雄原有的所有属性
          rank: index + 1    // 添加一个 rank 属性，值为当前索引+1
        }));
    },
    filteredGridHeroes() {
      let filtered = this.gridHeroes;
      
      // 搜索过滤
      if (this.searchHero) {
        const search = this.searchHero.toLowerCase();
        filtered = filtered.filter(hero => 
          hero.heroName.toLowerCase().includes(search)
        );
      }
      
      // 位置过滤 - 使用 selectedGridPosition
      if (this.selectedGridPosition !== '全部') {
        filtered = filtered.filter(hero => 
          hero.heroPosition === this.positionMap[this.selectedGridPosition]
        );
      }
      
      return filtered;
    },
  },
  methods: {
    // 左侧网格的位置选择
    selectGridPosition(position) {
      this.selectedGridPosition = position;
      // 只更新网格视图的过滤
      console.log('选择左侧位置：', position);
    },

    // 右侧表格的位置选择
    selectTablePosition(positionName) {
      console.log('选择右侧位置前：', this.selectedTablePosition);
      this.selectedTablePosition = positionName;
      console.log('选择右侧位置后：', this.selectedTablePosition);
      this.getVersionInfo();
    },

    // 获取右侧版本英雄数据
    async getVersionInfo() {
      this.loading = true;
      try {
        this.filteredVersionHeroes = [];
        // 构建请求参数
        const params = {
          position: this.selectedTablePosition === '全部' ? '' : this.positionMap[this.selectedTablePosition],
          version: this.selectedVersion,
          rankLevel: this.rankLevelMap[this.selectedRankLevel]
        };
        
        console.log('请求参数：', params);
        
        const response = await axios.post('http://localhost:10001/versionInfo/getInfoList', params);
        console.log('接口返回数据：', response.data);
        
        if (response.data.code === 200) {
          this.filteredVersionHeroes = response.data.data || [];
        } else {
          this.filteredVersionHeroes = [];
        }
      } catch (error) {
        console.error('获取版本信息失败：', error);
        this.filteredVersionHeroes = [];
      } finally {
        this.loading = false;
      }
    },
    fetchHeroes() {
      const params = {
        position: this.positionMap[this.selectedPosition] || '',
        version: this.selectedVersion,
        rankLevel: this.rankLevelMap[this.selectedRankLevel] || ''
      };
      axios.post('http://localhost:10001/versionInfo/getInfoList', params)
          .then(response => {
            if (response.data.code === 200) {
              this.heroes = response.data.data.map(hero => ({
                rankLevel: hero.rankLevel,
                heroName: hero.heroName,
                picUrl: hero.picUrl,
                strength: hero.strength,
                heroPosition: hero.heroPosition,
                version: hero.version,
                winRate: hero.winRate,
                appearanceRate: hero.appearanceRate,
                banRate: hero.banRate,
                advantageAgainstList: hero.advantageAgainstList,
                inferiorityAgainstList: hero.inferiorityAgainstList
              }));
            } else {
              console.error('获取英雄数据失败:', response.data.message);
            }
          })
          .catch(error => {
            console.error('获取英雄数据失败:', error);
          });
    },
    filterHeroes() {
      this.fetchHeroes();
    },
    getHeroImageUrl(picUrl) {
      return picUrl;
    },
    getPositionIcon(position) {
      const icons = {
        '中单': 'icon-mid',
        '打野': 'icon-jungle',
        '上单': 'icon-top',
        '下路': 'icon-adc',
        '辅助': 'icon-support'
      }
      return icons[position] || ''
    },
    getRankIcon(rank) {
      if (rank === '全部') return ''
      const rankNumber = this.rankLevelMap[rank]
      return `src/assets/lol/rank/${rankNumber}.webp`
    },
    selectGridPosition(posId) {
      this.selectedGridPosition = posId;
    },
    async searchHeroes() {
      try {
        // 构建请求参数
        const params = {
          heroName: this.searchHero,
          chineseName: this.searchHero,
          version: this.selectedVersion
        }

        // 发起POST请求
        const response = await axios.post('http://localhost:10001/hero/getHeroList', params)//
        
        if (response.data.code === 200) {
          // 更新左侧英雄网格数据
          this.gridHeroes = response.data.data
        } else {
          this.$message.error(response.data.message || '获取英雄列表失败')
        }
      } catch (error) {
        console.error('搜索英雄出错：', error)
        this.$message.error('搜索英雄失败')
      }
    },
    handleSearchInput() {
      // 使用防抖处理，避免频繁请求
      if (this.searchDebounce) {
        clearTimeout(this.searchDebounce)
      }
      this.searchDebounce = setTimeout(() => {
        this.searchHeroes()
      }, 300)
    },
    // 处理版本变化
    handleVersionChange(version) {
      console.log('版本变化：', version)
      // 同时更新左右两侧数据
      this.getHeroList(version)  // 更新左侧英雄列表
      this.getVersionInfo()      // 更新右侧版本信息
    },
    // 监听段位变化
    handleRankChange() {
      console.log('段位变化：', this.selectedRankLevel)
      this.getVersionInfo()
    },
    // 获取英雄列表
    async getHeroList(version = this.selectedVersion) {
      try {
        const params = {
          version: version
        }
        console.log('获取英雄列表参数：', params)
        
        const response = await axios.post('http://localhost:10001/hero/getHeroList', params)
        if (response.data.code === 200) {
          this.gridHeroes = response.data.data || []
        }
      } catch (error) {
        console.error('获取英雄列表失败：', error)
        ElMessage.error('获取英雄列表失败')
      }
    },
    showHeroDetail(hero) {
      console.log('点击的英雄数据：', hero) // 调试日志
      this.selectedHeroId = hero.heroId
    },
    backToList() {
      this.selectedHeroId = null
      this.selectedHeroData = null
    },
    // 获取位置名称
    getPositionName(value) {
      return this.positionNameMap[value] || value
    }
  },
  watch: {
    // 监听搜索框输入变化
    searchHero: {
      handler: 'handleSearchInput',
      immediate: false
    },
    // 监听版本变化
    selectedVersion: {
      handler(newVal) {
        console.log('版本变化，新值：', newVal)
        this.getVersionInfo()
      }
    },
    // 监听段位变化
    selectedRankLevel: {
      handler(newVal) {
        console.log('段位变化，新值：', newVal)
        this.getVersionInfo()
      }
    }
  },
  created() {
    // 组件创建时获取初始数据
    this.searchHeroes()
  }
};
</script>

<style scoped>
.hero-data-container {
  position: relative;
  padding: 24px;
  background-color: #f8fafc;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  gap: 20px;
  max-width: 1920px; /* 最大宽度限制 */
  margin: 0 auto; /* 居中显示 */
  width: 100%; /* 占满可用宽度 */
}

.top-filter {
  display: flex;
  justify-content: center; /* 居中显示筛选器 */
  padding: 12px 0;
}

.filter-content {
  display: flex;
  gap: 12px;
  align-items: center;
  max-width: 1200px; /* 限制最大宽度 */
  width: 100%;
}

.filter-select {
  width: 160px;
}

.main-content {
  display: flex;
  gap: 20px;
  flex: 1;
  width: 100%;
  height: calc(100vh - 180px); /* 调整高度，减去顶部区域和padding */
}

.left-section {
  width: 320px;
  min-width: 320px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  background: #fff;
  border-radius: 8px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  height: fit-content; /* 适应内容高度 */
}

.search-area {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.version-select {
  width: 120px;
  flex-shrink: 0;
}

.hero-search {
  flex: 1;
}

.hero-search :deep(.el-input__inner) {
  background-color: #fff;
  border: 1px solid #e2e8f0;
  color: #333;
  height: 36px;
}

.position-buttons {
  display: flex;
  gap: 4px;  /* 减小按钮间距 */
  padding: 12px 0;
  width: 100%;  /* 限制宽度为容器宽度 */
  overflow-x: hidden;  /* 隐藏超出部分 */
}

.position-btn {
  flex: 1;  /* 让按钮平均分配空间 */
  padding: 8px 10px;  /* 减小内边距 */
  border: none;
  background-color: #f1f5f9;
  color: #64748b;
  font-size: 13px;  /* 稍微减小字体 */
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
  white-space: nowrap;
  min-width: 0;  /* 允许按钮宽度小于内容宽度 */
  text-overflow: ellipsis;  /* 文字溢出时显示省略号 */
  overflow: hidden;
}

.position-btn:hover {
  background-color: #e2e8f0;
  color: #1e293b;
}

.position-btn.active {
  background-color: #3b82f6;
  color: white;
}

.hero-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr); /* 固定5列 */
  gap: 8px;
  padding: 8px;
  background: #f8fafc;
  border-radius: 4px;
  width: 100%; /* 确保宽度填满容器 */
}

.hero-grid-item {
  aspect-ratio: 1;
  cursor: pointer;
  border-radius: 4px;
  overflow: hidden;
  width: 100%; /* 确保图片填满格子 */
}

.hero-grid-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.right-section {
  flex: 1;
  min-width: 0;
  height: 100%;
}

.hero-data-card {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.filter-section {
  padding: 16px 0;
}

.filter-header h2 {
  font-size: 24px;
  color: #1e293b;
  margin: 0 0 8px 0;
  font-weight: 600;
}

.filter-content {
  display: flex;
  gap: 16px;
  justify-content: center;
  flex-wrap: wrap;
}

.filter-select {
  width: 160px;
}

:deep(.el-divider) {
  margin: 24px 0;
}

/* 全局变量 */
:root {
  --image-size: 50px;
}

/* 表格图片样式 */
.hero-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* 优势与劣势对抗图片 */
.advantage-images {
  display: inline-block;
  margin-right: 5px;
}

/* 表格行的悬浮效果 */
.el-table tr:hover {
  background-color: #f9fafb;
}

/* 修改英雄头像样式 */
.hero-avatar {
  width: 48px;  /* 增加宽度 */
  height: 48px; /* 增加高度 */
  border-radius: 4px; /* 改为方形，只保留小圆角 */
  overflow: hidden;
  flex-shrink: 0; /* 防止头像被压缩 */
}

/* 修改对抗英雄样式 */
.counter-heroes {
  display: flex;
  gap: 8px;
  padding: 2px;
}

.counter-hero-image {
  width: 36px;  /* 增加尺寸 */
  height: 36px; /* 增加尺寸 */
  border-radius: 50%; /* 改为圆形 */
  transition: transform 0.2s;
  object-fit: cover;
}

.counter-hero-image:hover {
  transform: translateY(-2px);
}

/* 英雄头像和名称样式 */
.hero-info {
  display: flex;
  align-items: center;
  gap: 12px; /* 增加头像和名字之间的间距 */
}

.hero-name {
  font-family: "PingFang SC", "Microsoft YaHei", sans-serif;
  font-weight: 600;
  color: #1e293b;
}

/* 添加段位图标样式 */
.rank-icon {
  width: 20px;
  height: 20px;
  margin-right: 8px;
  vertical-align: middle;
}

/* 右侧位置按钮组特定样式 */
.right-position-buttons {
  justify-content: flex-start;  /* 改为左对齐 */
  padding: 0 16px;  /* 添加左右内边距 */
  margin: 12px 0;   /* 调整上下外边距 */
  flex-wrap: nowrap; /* 强制一行显示 */
  overflow-x: auto; /* 内容过多时可以横向滚动 */
}

/* 隐藏滚动条但保持功能 */
.right-position-buttons::-webkit-scrollbar {
  display: none;
}

.right-position-buttons {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;     /* Firefox */
}

/* 位置筛选容器 */
.position-filter {
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 16px;
  width: 100%;  /* 确保容器占满宽度 */
}

/* 位置选项容器 */
.position-tabs {
  display: flex;
  width: 100%;
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 16px;
}

/* 单个位置选项 */
.position-tab {
  padding: 12px 24px; /* 增加内边距 */
  cursor: pointer;
  color: #64748b;
  font-size: 14px;
  position: relative;
  transition: all 0.2s;
  white-space: nowrap;
}

/* 选中状态 */
.position-tab.active {
  color: #4b7bec;
  font-weight: 500;
}

/* 选中状态下的底部蓝条 */
.position-tab.active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  width: 100%;
  height: 2px;
  background-color: #4b7bec;
}

/* 鼠标悬停效果 */
.position-tab:hover {
  color: #4b7bec;
}

/* 左侧位置按钮组样式 */
.position-buttons {
  display: flex;
  gap: 4px;  /* 减小按钮间距 */
  padding: 12px 0;
  width: 100%;  /* 限制宽度为容器宽度 */
  overflow-x: hidden;  /* 隐藏超出部分 */
}

/* 位置按钮样式 */
.position-btn {
  flex: 1;  /* 让按钮平均分配空间 */
  padding: 8px 10px;  /* 减小内边距 */
  border: none;
  background-color: #f1f5f9;
  color: #64748b;
  font-size: 13px;  /* 稍微减小字体 */
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
  white-space: nowrap;
  min-width: 0;  /* 允许按钮宽度小于内容宽度 */
  text-overflow: ellipsis;  /* 文字溢出时显示省略号 */
  overflow: hidden;
}

.position-btn:hover {
  background-color: #e2e8f0;
  color: #1e293b;
}

.position-btn.active {
  background-color: #3b82f6;
  color: white;
}

/* 响应式布局调整 */
@media screen and (max-width: 1440px) {
  .hero-grid {
    grid-template-columns: repeat(4, 1fr); /* 较小屏幕显示4列 */
  }
}

@media screen and (max-width: 1024px) {
  .hero-grid {
    grid-template-columns: repeat(3, 1fr); /* 更小屏幕显示3列 */
  }
}

/* 表格样式优化 */
.hero-table {
  flex: 1;
  overflow: auto;
}

/* 确保表格内容完整显示 */
:deep(.el-table) {
  width: 100% !important;
}

:deep(.el-table__body) {
  width: 100% !important;
}

:deep(.el-table__header) {
  width: 100% !important;
}

/* 表格列宽调整 */
:deep(.el-table .cell) {
  padding: 0 8px;
  line-height: 1.5;
}

/* 确保表格横向滚动正常工作 */
:deep(.el-table__body-wrapper) {
  overflow-x: auto !important;
}

/* 表格容器 */
.hero-table {
  width: 100%;
  background: white;
  border-radius: 8px;
}

/* 表头样式 */
.table-header {
  display: flex;
  padding: 12px 16px;
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
  font-weight: 500;
  color: #64748b;
}

/* 表格内容行 */
.table-row {
  display: flex;
  padding: 12px 16px;
  border-bottom: 1px solid #e2e8f0;
  align-items: center;
}

.table-row:hover {
  background: #f8fafc;
}

/* 单元格基础样式 */
.header-cell,
.cell {
  padding: 0 8px;
}

/* 各列宽度分配 */
.rank {
  width: 60px;
}

.hero {
  flex: 2;
  display: flex;
  align-items: center;
  gap: 8px;
}

.tier,
.position {
  width: 80px;
}

.win-rate,
.pick-rate,
.ban-rate {
  width: 100px;
  text-align: center;
}

/* 段位和位置图标 */
.tier-icon,
.position-icon {
  width: 24px;
  height: 24px;
}

/* 数据单元格样式 */
.win-rate,
.pick-rate,
.ban-rate {
  font-family: 'Roboto Mono', monospace;
  color: #1a1a1a;
}

/* 修改强度图标尺寸 */
.strength-icon {
  width: 48px;  /* 从24px改为48px */
  height: 48px; /* 从24px改为48px */
  object-fit: contain;
  vertical-align: middle;
}

/* 调整位置图标样式 */
.position-icon {
  width: 32px;
  height: 32px;
  object-fit: contain;
  vertical-align: middle;
}

.hero-info {
  cursor: pointer;
}

.hero-info:hover .hero-name {
  color: #409EFF;
}

.back-nav {
  margin-bottom: 16px;
}

.back-nav .el-button {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}
</style>

