<template>
  <div class="hero-detail">
    <!-- 英雄基本信息头部 -->
    <div class="hero-header">
      <div class="left-content">
        <div class="hero-basic-info">
          <div class="hero-info-container">
            <!-- 左侧：英雄头像和信息 -->
            <div class="left-section">
              <img 
                v-if="heroInfo.picUrl"
                :src="heroInfo.picUrl"
                :alt="heroInfo.heroName"
                class="hero-avatar"
              />
              
              <div class="info-skills-container">
                <div class="hero-text">
                  <div class="hero-name-title">
                    <h1>{{ heroInfo.heroName }}</h1>
                    <span class="hero-subtitle">{{ heroInfo.title }}</span>
                  </div>
                  <div class="hero-meta">
                    <span class="hero-tier">{{ heroInfo.tier || '2级' }}</span>
                    <span class="hero-version">版本 {{ heroInfo.version || '15.02' }}</span>
                  </div>
                </div>

                <!-- 技能图标区域 -->
                <div class="hero-skills">
                  <div class="skill-icons">
                    <div v-for="(url, skill) in skillImages" :key="skill" class="skill-icon">
                      <el-image
                        :src="url"
                        fit="cover"
                        class="skill-image"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 右侧：数据统计 -->
            <div class="hero-stats">
              <div class="stat-row">
                <div class="stat-label">
                  <span class="stat-char">胜</span>率
                </div>
                <span class="stat-value win-rate">{{ heroInfo.winRate }}%</span>
              </div>
              <div class="stat-row">
                <div class="stat-label">
                  <span class="stat-char">选</span>用率
                </div>
                <span class="stat-value pick-rate">{{ heroInfo.appearanceRate }}%</span>
              </div>
              <div class="stat-row">
                <div class="stat-label">
                  <span class="stat-char">禁</span>用率
                </div>
                <span class="stat-value ban-rate">{{ heroInfo.banRate }}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 右侧广告位 -->
      <div class="ad-space">
        <!-- 广告内容 -->
      </div>
    </div>

    <!-- Tab 切换 -->
    <div class="tab-container">
      <el-tabs v-model="activeTab">
        <el-tab-pane label="构建" name="build">
          <!-- 构建相关内容 -->
          <div v-if="activeTab === 'build'" class="hero-detail-content">
            <!-- 左侧列 -->
            <div class="left-column">
              <!-- 符文配置 -->
              <div class="rune-section">
                <div class="rune-content">
                  <!-- 第一列：符文配置选择 -->
                  <div class="rune-column config-sets">
                    <!-- 第一套符文配置（精密+主宰） -->
                    <div class="rune-set" 
                         :class="{ active: activeRuneSet === 0 }"
                         @click="switchRuneSet(0)">
                      <div class="rune-set-info">
                        <div class="win-rate-info">
                          <span class="rate">64.85%</span>
                          <span class="matches">3,858 场</span>
                        </div>
                        <span class="pick-rate">49.14%</span>
                      </div>
                      <div class="rune-icons">
                        <img :src="getMainRuneImagePath(1, 1)" class="rune-icon" />
                        <img :src="getSubRuneImagePath('green', 1, 1)" class="rune-icon" />
                      </div>
                    </div>

                    <!-- 第二套符文配置（精密+启迪） -->
                    <div class="rune-set"
                         :class="{ active: activeRuneSet === 1 }"
                         @click="switchRuneSet(1)">
                      <div class="rune-set-info">
                        <div class="win-rate-info">
                          <span class="rate">16.24%</span>
                          <span class="matches">966 场</span>
                        </div>
                        <span class="pick-rate">51.76%</span>
                      </div>
                      <div class="rune-icons">
                        <img :src="getMainRuneImagePath(1, 1)" class="rune-icon" />
                        <img :src="getSubRuneImagePath('blue', 1, 1)" class="rune-icon" />
                      </div>
                    </div>
                  </div>

                  <!-- 第二列：精密系符文 -->
                  <div class="rune-column">
                    <!-- 添加精密系图标 -->
                    <div class="rune-type-icon">
                      <el-image 
                        :src="yellowTypeIcon"
                        fit="cover" />
                    </div>
                    <!-- 大符文 -->
                    <div class="rune-grid">
                      <div v-for="i in 4" :key="`yellow-1-${i}`" class="rune-slot">
                        <el-image 
                          :src="getMainRuneImagePath(1, i)"
                          :class="{ inactive: !isRuneActive('yellow', 1, i) }"
                          fit="cover" />
                      </div>
                    </div>
                    <div v-for="row in 3" :key="`yellow-${row+1}`" class="rune-grid">
                      <div v-for="col in 3" :key="`yellow-${row+1}-${col}`" class="rune-slot">
                        <el-image 
                          :src="getMainRuneImagePath(row+1, col)"
                          :class="{ inactive: !isRuneActive('yellow', row+1, col) }"
                          fit="cover" />
                      </div>
                    </div>
                    <div class="rune-title">精密</div>
                  </div>

                  <!-- 第三列：副系符文 -->
                  <div class="rune-column">
                    <!-- 添加副系图标 -->
                    <div class="rune-type-icon">
                      <el-image 
                        :src="currentSubTypeIcon"
                        fit="cover" />
                    </div>
                    <div class="empty-keystones"></div>
                    <!-- 副系符文 -->
                    <div v-for="row in 3" :key="`${currentSubType}-${row+1}`" class="rune-grid">
                      <div v-for="col in 3" :key="`${currentSubType}-${row+1}-${col}`" class="rune-slot">
                        <el-image 
                          :src="getSubRuneImagePath(currentSubType, row+1, col)"
                          :class="{ inactive: !isRuneActive(currentSubType, row+1, col) }"
                          fit="cover" />
                      </div>
                    </div>
                    <div class="rune-title">{{ currentSubTypeName }}</div>
                  </div>

                  <!-- 第四列：符文碎片 -->
                  <div class="rune-column">
                    <div class="empty-keystones"></div>
                    <div v-for="row in 3" :key="`fragment-${row}`" class="rune-grid">
                      <div v-for="col in 3" :key="`fragment-${row}-${col}`" class="rune-slot">
                        <el-image 
                          :src="getFragmentImagePath(row, col)"
                          :class="{ inactive: !isFragmentActive(row, col) }"
                          fit="cover" />
                      </div>
                    </div>
                    <div class="rune-title">符文碎片</div>
                  </div>
                </div>
              </div>

              <!-- 召唤师技能推荐 -->
              <div class="summoner-spells-section">
                <h3>疾风剑豪 召唤师技能推荐</h3>
                <div class="spell-combinations">
                  <!-- 第一个技能组合 -->
                  <div class="spell-combo">
                    <div class="spell-icons">
                      <el-image v-for="spell in summonerSpells[0]?.spells" 
                               :key="spell.id" 
                               :src="spell.icon" 
                               class="spell-icon" 
                               fit="cover" />
                    </div>
                    <div class="spell-info">
                      <span class="win-rate">{{ summonerSpells[0]?.winRate || '47.98' }}%</span>
                      <span class="matches">{{ summonerSpells[0]?.matches || '2,834' }} 场</span>
                    </div>
                    <div class="pick-rate">
                      <span>{{ summonerSpells[0]?.pickRate || '49.61' }}%</span>
                    </div>
                  </div>

                  <!-- 第二个技能组合 -->
                  <div class="spell-combo">
                    <div class="spell-icons">
                      <el-image v-for="spell in summonerSpells[1]?.spells" 
                               :key="spell.id" 
                               :src="spell.icon" 
                               class="spell-icon" 
                               fit="cover" />
                    </div>
                    <div class="spell-info">
                      <span class="win-rate">{{ summonerSpells[1]?.winRate || '39.5' }}%</span>
                      <span class="matches">{{ summonerSpells[1]?.matches || '2,333' }} 场</span>
                    </div>
                    <div class="pick-rate">
                      <span>{{ summonerSpells[1]?.pickRate || '49.07' }}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 右侧列 -->
            <div class="right-column">
              <!-- 对线劣势英雄 -->
              <div class="counter-section">
                <h3>对线劣势的英雄</h3>
                <div class="counter-list">
                  <div v-for="hero in counterHeroes" :key="hero.heroId" class="counter-item">
                    <el-image :src="hero.picUrl" class="hero-avatar" fit="cover" />
                    <div class="counter-info">
                      <span class="win-rate">{{ hero.winRate }}%</span>
                      <span class="matches">{{ hero.matches }}场</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- 强势对抗 -->
              <div class="advantage-section">
                <h3>强势对抗</h3>
                <div class="advantage-list">
                  <div v-for="hero in advantageHeroes" :key="hero.heroId" class="advantage-item">
                    <el-image :src="hero.picUrl" class="hero-avatar" fit="cover" />
                    <div class="advantage-info">
                      <span class="win-rate">{{ hero.winRate }}%</span>
                      <span class="matches">{{ hero.matches }}场</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </el-tab-pane>

        <el-tab-pane label="装备" name="equipment">
          <!-- 装备相关内容的占位，后续开发 -->
          <div v-if="activeTab === 'equipment'" class="equipment-content">
            <!-- 装备内容将在后续开发 -->
          </div>
        </el-tab-pane>

        <!-- 可以继续添加其他 tab -->
      </el-tabs>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, watch } from 'vue'
import axios from 'axios'
import { ElMessage } from 'element-plus'
import { getHeroRunes } from '@/api/hero'


const props = defineProps({
  heroId: {
    type: [String, Number],
    required: true
  }
})

const heroInfo = ref({})
const activeTab = ref('build')
const skillImages = ref({
  passive: '',
  q: '',
  w: '',
  e: '',
  r: ''
})

// 当前激活的符文配置
const activeRuneSet = ref(0)

// 根据当前选中的套装决定副系类型
const currentSubType = computed(() => activeRuneSet.value === 0 ? 'green' : 'blue')
const currentSubTypeIcon = computed(() => activeRuneSet.value === 0 ? greenTypeIcon : blueTypeIcon)
const currentSubTypeName = computed(() => activeRuneSet.value === 0 ? '坚决' : '启迪')

// 存储符文激活状态
const runeActiveState = ref({
  set1: {
    yellow: [], // 精密系激活状态
    green: [],  // 主宰系激活状态
    fragments: [] // 符文碎片激活状态
  },
  set2: {
    yellow: [], // 精密系激活状态
    blue: [],  // 启迪系激活状态
    fragments: [] // 符文碎片激活状态
  }
})

// 检查符文是否激活
const isRuneActive = (type, row, col) => {
  const currentSet = activeRuneSet.value === 0 ? 'set1' : 'set2'
  return runeActiveState.value[currentSet][type]?.some(
    rune => rune.row === row && rune.col === col
  )
}

// 检查符文碎片是否激活
const isFragmentActive = (row, col) => {
  const currentSet = activeRuneSet.value === 0 ? 'set1' : 'set2'
  return runeActiveState.value[currentSet].fragments?.some(
    fragment => fragment.row === row && fragment.col === col
  )
}

// 生成符文图片路径的函数
const getMainRuneImagePath = (row, col) => {
  return new URL(`/src/assets/lol/rune/yellow-${row}-${col}.webp`, import.meta.url).href
}

const getSubRuneImagePath = (type, row, col) => {
  return new URL(`/src/assets/lol/rune/${type}-${row}-${col}.webp`, import.meta.url).href
}

// 获取当前选中的主系符文图片
const getSelectedMainRunePath = () => {
  // 这里可以根据实际选中的符文返回对应的路径
  return getMainRuneImagePath(1, 1) // 默认显示第一个
}

// 修改符文碎片图片路径的函数
const getFragmentImagePath = (row, col) => {
  return new URL(`/src/assets/lol/rune/fragment-${row}-${col}.webp`, import.meta.url).href
}

// 获取英雄详情
const getHeroDetail = async () => {
  try {
    if (!props.heroId) {
      console.error('heroId is missing')
      return
    }
    
    console.log('正在获取英雄详情，heroId:', props.heroId)
    const response = await axios.get(`http://localhost:10001/hero/detail/${props.heroId}`)
    
    if (response.data.code === 200) {
      const data = response.data.data
      console.log('获取到的英雄数据：', data)
      
      // 设置英雄信息，使用接口返回的数据
      heroInfo.value = {
        ...data,
        picUrl: `/src/assets/lol/hero/${data.englishName}.webp`,
        winRate: data.winRate,
        appearanceRate: data.appearanceRate,
        banRate: data.banRate
      }
      
      // 设置技能图片
      skillImages.value = {
        passive: `/src/assets/lol/skill/${data.englishName}_Passive.webp`,
        q: `/src/assets/lol/skill/${data.englishName}_Q.webp`,
        w: `/src/assets/lol/skill/${data.englishName}_W.webp`,
        e: `/src/assets/lol/skill/${data.englishName}_E.webp`,
        r: `/src/assets/lol/skill/${data.englishName}_R.webp`
      }
    }
  } catch (error) {
    console.error('获取英雄详情失败：', error)
    ElMessage.error('获取英雄详情失败')
  }
}

// 加载英雄符文数据
const loadHeroRunes = async () => {
  try {
    const res = await getHeroRunes(props.heroId)
    if (res.data) {
      // 更新符文激活状态
      runeActiveState.value = {
        set1: res.data.set1,
        set2: res.data.set2
      }
    }
  } catch (error) {
    console.error('加载符文数据失败:', error)
  }
}

// 监听英雄ID变化
watch(() => props.heroId, () => {
  loadHeroRunes()
}, { immediate: true })

// 当组件挂载时获取数据
onMounted(() => {
  if (props.heroId) {
    getHeroDetail()
  }
})

const counterHeroes = ref([
  {
    heroId: 1,
    picUrl: '/path/to/hero1.png',
    heroName: '英雄1',
    winRate: '33.33',
    matches: '63'
  },
  // ... 更多英雄
])

const advantageHeroes = ref([
  {
    heroId: 2,
    picUrl: '/path/to/hero2.png',
    heroName: '英雄2',
    winRate: '60.6',
    matches: '33'
  },
  // ... 更多英雄
])

const summonerSpells = ref([
  {
    spells: [
      { id: 1, icon: '/path/to/flash.png' },  // 闪现
      { id: 2, icon: '/path/to/ghost.png' }   // 幽灵疾步
    ],
    winRate: '47.98',
    matches: '2,834',
    pickRate: '49.61'
  },
  {
    spells: [
      { id: 1, icon: '/path/to/flash.png' },  // 闪现
      { id: 3, icon: '/path/to/ignite.png' }  // 点燃
    ],
    winRate: '39.5',
    matches: '2,333',
    pickRate: '49.07'
  }
])

const switchRuneSet = (index) => {
  activeRuneSet.value = index
}

// 添加精密系图标路径
const yellowTypeIcon = new URL('/src/assets/lol/rune/yellow.webp', import.meta.url).href
const greenTypeIcon = new URL('/src/assets/lol/rune/green.webp', import.meta.url).href
const blueTypeIcon = new URL('/src/assets/lol/rune/blue.webp', import.meta.url).href
</script>

<style scoped>
.hero-detail {
  padding: 20px;
  background: #fff;
}

.hero-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 24px;
  background: #f8f9fa;
  border-radius: 8px;
}

.left-content {
  flex: 1;
  max-width: 50%;
}

.hero-info-container {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 20px;
}

.left-section {
  display: flex;
  gap: 20px;
}

.hero-avatar {
  width: 100px;
  height: 100px;
  border-radius: 8px;
  object-fit: cover;
  flex-shrink: 0;
}

.hero-stats {
  height: 100px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 0;
}

.stat-row {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  height: 33px;
  gap: 12px;
}

.stat-label {
  font-size: 16px;
  font-weight: bold;
  color: #666;
  min-width: 48px;
  display: flex;
  align-items: center;
}

.stat-char {
  width: 16px;
  display: inline-block;
}

.stat-value {
  font-size: 16px;
  font-weight: bold;
  line-height: 33px;
  margin-left: auto;
}

.win-rate {
  color: #00b8a3;
}

.pick-rate, .ban-rate {
  color: #1a1a1a;
}

.info-skills-container {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.hero-text {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.hero-name-title h1 {
  margin: 0;
  font-size: 24px;
  font-weight: bold;
  color: #1a1a1a;
}

.hero-subtitle {
  color: #666;
  font-size: 14px;
}

.hero-meta {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 4px;
}

.hero-tier {
  color: #00b8a3;
  font-weight: bold;
}

.hero-version {
  color: #666;
  font-size: 14px;
}

.skill-icons {
  display: flex;
  gap: 8px;
}

.skill-icon {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  overflow: hidden;
}

.skill-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.ad-space {
  flex: 1;
  min-height: 250px;
  background: #f0f0f0;
  border-radius: 8px;
  margin-left: 24px;
}

.hero-nav {
  margin-top: 24px;
  border-bottom: 1px solid #e2e8f0;
}

:deep(.el-tabs__nav-wrap::after) {
  display: none;
}

:deep(.el-tabs__item) {
  font-size: 14px;
  padding: 0 20px;
  height: 40px;
  line-height: 40px;
}

:deep(.el-tabs__item.is-active) {
  color: #1a1a1a;
  font-weight: bold;
}

.hero-detail-content {
  display: flex;
  gap: 24px;
  padding: 24px;
}

.left-column {
  flex: 3;
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.right-column {
  flex: 2;
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
}

.win-rate-info {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.primary-rune, .secondary-rune {
  display: flex;
  align-items: center;
  gap: 8px;
}

.rate {
  font-size: 16px;
  font-weight: bold;
  color: #00b8a3;
}

.matches {
  color: #666;
  font-size: 14px;
}

/* 符文布局 */
.rune-section {
  padding: 20px;
  background: #fff;
}

.rune-content {
  display: flex;
  gap: 24px;
  align-items: flex-start;
}

.rune-column {
  flex-shrink: 0;
}

.config-sets {
  width: 200px;
  flex-shrink: 0;
}

.rune-set {
  padding: 14px;
  background: #f8f9fa;
  border-radius: 4px;
  margin-bottom: 8px;
  cursor: pointer;
}

.rune-set:hover {
  background: #e9ecef;
}

.rune-set.active {
  background: #e3f2fd;
}

.rune-set-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.win-rate-info {
  display: flex;
  align-items: center;
  gap: 4px;
}

.rate {
  font-size: 14px;
  font-weight: bold;
}

.matches {
  font-size: 12px;
  color: #666;
}

.pick-rate {
  color: #4171d6;
  font-size: 12px;
}

.rune-title {
  font-size: 12px;
  color: #666;
  text-align: center;
  margin-top: 12px;
}

.rune-grid {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
}

.rune-slot {
  width: 36px;
  height: 36px;
  border-radius: 4px;
  overflow: hidden;
  flex-shrink: 0;
}

.inactive {
  filter: grayscale(100%);
}

.rune-icons {
  display: flex;
  gap: 6px;
  margin-top: 6px;
}

.rune-icon {
  width: 20px;
  height: 20px;
  border-radius: 50%;
}

/* 对线信息样式 */
.counter-list, .advantage-list {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.counter-item, .advantage-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px;
  background: #f5f5f5;
  border-radius: 4px;
  width: calc(50% - 6px);
}

.hero-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
}

.counter-info, .advantage-info {
  display: flex;
  flex-direction: column;
}

/* 召唤师技能样式 */
.summoner-spells-section {
  background: #fff;
  border-radius: 8px;
  padding: 20px;
}

.summoner-spells-section h3 {
  font-size: 14px;
  font-weight: bold;
  color: #1a1a1a;
  margin-bottom: 16px;
}

.spell-combinations {
  display: flex;
  gap: 20px;
}

.spell-combo {
  flex: 1;
  display: flex;
  align-items: center;
  padding: 12px 16px;
  background: #f8f9fa;
  border-radius: 4px;
  height: 48px;
}

.spell-icons {
  display: flex;
  gap: 4px;
  margin-right: 16px;
}

.spell-icon {
  width: 24px;
  height: 24px;
  border-radius: 4px;
}

.spell-info {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-right: auto;
}

.win-rate {
  font-size: 14px;
  font-weight: bold;
  color: #1a1a1a;
}

.matches {
  font-size: 12px;
  color: #666;
}

.pick-rate {
  font-size: 14px;
  color: #4171d6;
}

.tab-container {
  height: 100%;
  padding: 0 16px;
}

/* 自定义 tab 样式 */
:deep(.el-tabs__header) {
  margin-bottom: 24px;
}

:deep(.el-tabs__nav-wrap) {
  padding: 0 8px;
}

:deep(.el-tabs__item) {
  font-size: 16px;
  height: 48px;
  line-height: 48px;
  padding: 0 24px;
}

:deep(.el-tabs__item.is-active) {
  font-weight: 600;
}

/* 装备内容的基础样式 */
.equipment-content {
  padding: 24px;
}

/* 响应式调整 */
@media (max-width: 768px) {
  .spell-combinations {
    flex-direction: column;
  }
}

.empty-keystones {
  height: 76px; /* 精密系图标高度 + 间距 */
  width: 120px;
  visibility: hidden;
}

/* 第二列大符文布局 */
.rune-column:nth-child(2) .rune-grid:first-child {
  width: 120px;
  justify-content: space-between;
  gap: 4px;
  margin: 0 auto 16px;
}

/* 统一所有小符文网格的布局 */
.rune-column:nth-child(2) .rune-grid:not(:first-child),
.rune-column:nth-child(3) .rune-grid,
.rune-column:nth-child(4) .rune-grid {
  width: 120px;
  justify-content: space-between;
  gap: 16px;
  margin: 0 auto 16px;
}

/* 统一所有列的布局 */
.rune-column:nth-child(2),
.rune-column:nth-child(3),
.rune-column:nth-child(4) {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1;
}

/* 添加精密系图标样式 */
.rune-type-icon {
  width: 36px;
  height: 36px;
  margin-bottom: 20px; /* 增加与下方大符文的间距 */
  border-radius: 50%;
  overflow: hidden;
  position: relative; /* 确保图标在正确的层级 */
  z-index: 1; /* 提高层级 */
}

.rune-type-icon .el-image {
  width: 100%;
  height: 100%;
  display: block; /* 确保图片正确显示 */
}

/* 只调整第三列的布局 */
.rune-column:nth-child(3) {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 132px; /* 调整顶部内边距使小符文对齐 */
}

.rune-column:nth-child(3) .rune-type-icon {
  position: absolute;
  top: 20px;
}
</style> 