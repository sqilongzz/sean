<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Picture } from '@element-plus/icons-vue'
import axios from 'axios'

// 表格数据
const heroList = ref([])
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const searchQuery = ref('')

// 弹窗控制
const dialogVisible = ref(false)
const deleteDialogVisible = ref(false)
const dialogType = ref('add')
const currentHeroId = ref(null)

// 表单数据
const heroData = reactive({
  version: '',
  heroName: '',
  chineseName: '',
  englishName: '',
  heroPosition: '',
  picUrl: '',
  heroPassiveSkills: '',
  heroSkillsQ: '',
  heroSkillsW: '',
  heroSkillsE: '',
  heroSkillsR: ''
})

// 位置选项
const positions = [
  { value: '', label: '全部', icon: '0' },
  { value: '1', label: '上单', icon: '1' },
  { value: '2', label: '打野', icon: '2' },
  { value: '3', label: '中单', icon: '3' },
  { value: '4', label: '下路', icon: '4' },
  { value: '5', label: '辅助', icon: '5' }
]

// 表单验证规则
const rules = {
  version: [{ required: true, message: '请输入版本号', trigger: 'blur' }],
  heroName: [{ required: true, message: '请输入英雄名称', trigger: 'blur' }],
  chineseName: [{ required: true, message: '请输入中文名', trigger: 'blur' }],
  englishName: [{ required: true, message: '请输入英文名', trigger: 'blur' }],
  heroPosition: [{ required: true, message: '请选择英雄位置', trigger: 'change' }],
  picUrl: [{ required: true, message: '请输入头像路径', trigger: 'blur' }]
}

const heroForm = ref(null)

// 添加版本选择相关数据
const selectedVersion = ref('14.18')
const versionOptions = [
  { value: '14.17', label: '14.17' },
  { value: '14.18', label: '14.18' },
  { value: '15.01', label: '15.01' }
]

// 修改查询参数对象
const queryParams = reactive({
  page: 1,
  pageSize: 10,
  heroName: '',
  chineseName: '',
  englishName: '',
  version: '14.18',  // 默认版本
  heroPosition: ''
})

// 添加选中英雄数组
const selectedHeroes = ref([])

// 获取英雄列表
const getHeroList = async () => {
  loading.value = true
  try {
    const requestParams = {
      page: queryParams.page,
      pageSize: queryParams.pageSize,
      ...Object.entries(queryParams).reduce((acc, [key, value]) => {
        if (value !== '' && value !== null && value !== undefined && key !== 'page' && key !== 'pageSize') {
          acc[key] = value
        }
        return acc
      }, {})
    }

    const response = await axios.post('http://localhost:10001/hero/getListPage', requestParams)
    if (response.data.code === 200) {
      const pageData = response.data.data
      heroList.value = pageData.records
      total.value = pageData.total
      queryParams.page = pageData.current
      queryParams.pageSize = pageData.size
    }
  } catch (error) {
    console.error('获取英雄列表失败：', error)
    ElMessage.error('获取数据失败')
  } finally {
    loading.value = false
  }
}

// 显示新增弹窗
const showAddDialog = () => {
  dialogType.value = 'add'
  resetForm()
  dialogVisible.value = true
}

// 编辑英雄
const handleEdit = (row) => {
  dialogType.value = 'update'
  dialogVisible.value = true
  // 直接将所有数据复制到 heroData 中
  Object.assign(heroData, {
    id: row.id,
    version: row.version,
    heroName: row.heroName,
    chineseName: row.chineseName,
    englishName: row.englishName,
    heroPosition: row.heroPosition,
    picUrl: row.picUrl,
    heroPassiveSkills: row.heroPassiveSkills,
    heroSkillsQ: row.heroSkillsQ,
    heroSkillsW: row.heroSkillsW,
    heroSkillsE: row.heroSkillsE,
    heroSkillsR: row.heroSkillsR
  })
}

// 删除英雄
const handleDelete = (row) => {
  currentHeroId.value = row.id
  deleteDialogVisible.value = true
}

// 确认删除
const confirmDelete = async () => {
  try {
    const response = await axios.delete(`http://localhost:10001/hero/delete/${currentHeroId.value}`)
    if (response.data.code === 200) {
      ElMessage.success('删除成功')
      getHeroList()
    }
  } catch (error) {
    console.error('删除失败：', error)
    ElMessage.error('删除失败')
  }
  deleteDialogVisible.value = false
}

// 搜索处理
const handleSearch = () => {
  queryParams.page = 1
  getHeroList()
}

// 分页处理
const handleSizeChange = (val) => {
  queryParams.pageSize = val
  queryParams.page = 1
  getHeroList()
}

const handleCurrentChange = (val) => {
  queryParams.page = val
  getHeroList()
}

// 重置查询
const resetQuery = () => {
  Object.assign(queryParams, {
    page: 1,
    pageSize: 15,
    heroName: '',
    chineseName: '',
    englishName: '',
    version: '',
    heroPosition: ''
  })
  getHeroList()
}

// 获取位置标签
const getPositionLabel = (value) => {
  const pos = positions.find(p => p.value === value)
  return pos ? pos.label : ''
}

// 日期格式化函数
const formatDate = (dateString) => {
  if (!dateString) return ''
  const date = new Date(dateString)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }).replace(/\//g, '-')
}

// 初始化
onMounted(() => {
  getHeroList()
})

// 修改提交表单方法
const submitForm = async () => {
  if (!heroForm.value) return
  
  await heroForm.value.validate(async (valid) => {
    if (valid) {
      try {
        loading.value = true
        const url = dialogType.value === 'add' ? '/hero/add' : '/hero/update'
        const response = await axios.post(`http://localhost:10001${url}`, {
          ...heroData,  // 直接使用 heroData 而不是 heroData.value
          id: dialogType.value === 'update' ? heroData.id : undefined // 更新时传入id
        })
        
        if (response.data.code === 200) {
          ElMessage.success(dialogType.value === 'add' ? '添加成功' : '更新成功')
          dialogVisible.value = false
          getHeroList() // 刷新列表
        } else {
          ElMessage.error(response.data.msg || '操作失败')
        }
      } catch (error) {
        console.error('提交表单失败：', error)
        ElMessage.error('操作失败')
      } finally {
        loading.value = false
      }
    }
  })
}

// 重置表单
const resetForm = () => {
  if (heroForm.value) {
    heroForm.value.resetFields()
  }
}

// 获取位置图标
const getPositionIcon = (value) => {
  const iconValue = value === '' ? '0' : value
  // 使用动态导入
  return `/src/assets/lol/position/${iconValue}.webp`
}

// 处理位置选择
const handlePositionSelect = (value) => {
  queryParams.heroPosition = queryParams.heroPosition === value ? '' : value
  handleSearch()
}

// 版本变化处理函数
const handleVersionChange = (value) => {
  queryParams.version = value
  getHeroList()
}

// 处理选择变化
const handleSelectionChange = (selection) => {
  selectedHeroes.value = selection
}

// 修改批量删除方法
const handleBatchDelete = async () => {
  if (selectedHeroes.value.length === 0) {
    ElMessage.warning('请选择要删除的英雄')
    return
  }

  try {
    await ElMessageBox.confirm('确定要删除选中的英雄吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })

    const ids = selectedHeroes.value.map(hero => hero.id)
    const response = await axios.delete('http://localhost:10001/hero/deleteBatch', {
      data: ids  // 使用 data 属性传递请求体数据
    })

    if (response.data.code === 200) {
      ElMessage.success('批量删除成功')
      // 重新获取列表数据
      getHeroList()
      // 清空选中
      selectedHeroes.value = []
    } else {
      ElMessage.error(response.data.msg || '删除失败')
    }
  } catch (error) {
    if (error !== 'cancel') {
      console.error('批量删除失败：', error)
      ElMessage.error('删除失败')
    }
  }
}
</script>

<template>
  <div class="hero-manager">
    <el-card class="table-card">
      <!-- 顶部操作区 -->
      <div class="operation-bar">
        <div class="left">
          <el-button type="primary" @click="showAddDialog">新增英雄</el-button>
          <!-- 添加批量删除按钮 -->
          <el-button 
            type="danger" 
            @click="handleBatchDelete"
            :disabled="selectedHeroes.length === 0"
          >
            批量删除({{ selectedHeroes.length }})
          </el-button>
        </div>
        <div class="right">
          <el-form :inline="true" :model="queryParams">
            <el-form-item label="版本">
              <el-select 
                v-model="queryParams.version"
                placeholder="选择版本"
                @change="handleVersionChange"
                clearable
                style="width: 120px;"
              >
                <el-option
                  v-for="item in versionOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="英雄名称">
              <el-input
                v-model="queryParams.heroName"
                placeholder="英雄名称"
                clearable
                @keyup.enter="handleSearch"
              />
            </el-form-item>
            <el-form-item label="中文名">
              <el-input
                v-model="queryParams.chineseName"
                placeholder="中文名"
                clearable
                @keyup.enter="handleSearch"
              />
            </el-form-item>
            <el-form-item label="英文名">
              <el-input
                v-model="queryParams.englishName"
                placeholder="英文名"
                clearable
                @keyup.enter="handleSearch"
              />
            </el-form-item>
            <el-form-item label="位置">
              <div class="position-selector">
                <div
                  v-for="pos in positions"
                  :key="pos.value"
                  :class="['position-item', { active: queryParams.heroPosition === pos.value }]"
                  @click="handlePositionSelect(pos.value)"
                >
                  <img :src="getPositionIcon(pos.value)" :alt="pos.label" class="position-icon">
                  <span>{{ pos.label }}</span>
                </div>
              </div>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="handleSearch">查询</el-button>
              <el-button @click="resetQuery">重置</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>

      <!-- 数据表格 -->
      <el-table 
        :data="heroList" 
        border 
        style="width: 100%" 
        v-loading="loading"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column type="index" label="序号" width="60" />
        <el-table-column prop="heroName" label="英雄名称" width="120" />
        <el-table-column prop="chineseName" label="中文名" width="100" />
        <el-table-column prop="englishName" label="英文名" width="100" />
        <el-table-column prop="version" label="版本" width="80" />
        <el-table-column prop="heroPosition" label="位置" width="80">
          <template #default="scope">
            {{ getPositionLabel(scope.row.heroPosition) }}
          </template>
        </el-table-column>
        <el-table-column prop="picUrl" label="头像" width="60">
          <template #default="scope">
            <el-image 
              :src="scope.row.picUrl" 
              style="width: 32px; height: 32px; border-radius: 4px;"
              fit="cover"
            >
              <template #error>
                <div class="image-error">
                  <el-icon><Picture /></el-icon>
                </div>
              </template>
            </el-image>
          </template>
        </el-table-column>
        <el-table-column prop="heroPassiveSkills" label="被动技能" show-overflow-tooltip />
        <el-table-column prop="heroSkillsQ" label="Q技能" show-overflow-tooltip />
        <el-table-column prop="heroSkillsW" label="W技能" show-overflow-tooltip />
        <el-table-column prop="heroSkillsE" label="E技能" show-overflow-tooltip />
        <el-table-column prop="heroSkillsR" label="R技能" show-overflow-tooltip />
        <el-table-column prop="createTime" label="创建时间" width="160">
          <template #default="scope">
            {{ formatDate(scope.row.createTime) }}
          </template>
        </el-table-column>
        <el-table-column prop="updateTime" label="更新时间" width="160">
          <template #default="scope">
            {{ formatDate(scope.row.updateTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="scope">
            <el-button-group>
              <el-button size="small" type="primary" @click="handleEdit(scope.row)">编辑</el-button>
              <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="queryParams.page"
          v-model:page-size="queryParams.pageSize"
          :page-sizes="[15, 30, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 新增/编辑弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'add' ? '新增英雄' : '编辑英雄'"
      width="60%"
      destroy-on-close
    >
      <el-form 
        ref="heroForm"
        :model="heroData"
        :rules="rules"
        label-width="120px"
        class="hero-form"
      >
        <!-- 基本信息 -->
        <div class="form-section">
          <h3>基本信息</h3>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="版本" prop="version">
                <el-input v-model="heroData.version" placeholder="请输入版本号，如：14.17" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="位置" prop="heroPosition">
                <el-select v-model="heroData.heroPosition" placeholder="请选择英雄位置">
                  <el-option v-for="pos in positions" :key="pos.value" :label="pos.label" :value="pos.value" />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="20">
            <el-col :span="8">
              <el-form-item label="英雄名称" prop="heroName">
                <el-input v-model="heroData.heroName" placeholder="如：暮光星灵" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="中文名" prop="chineseName">
                <el-input v-model="heroData.chineseName" placeholder="如：佐伊" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="英文名" prop="englishName">
                <el-input v-model="heroData.englishName" placeholder="如：Zoe" />
              </el-form-item>
            </el-col>
          </el-row>

          <el-form-item label="头像路径" prop="picUrl">
            <el-input v-model="heroData.picUrl" placeholder="如：src/assets/lol/hero/Zoe.webp" />
          </el-form-item>
        </div>

        <!-- 技能信息 -->
        <div class="form-section">
          <h3>技能信息</h3>
          <el-form-item label="被动技能" prop="heroPassiveSkills">
            <el-input type="textarea" v-model="heroData.heroPassiveSkills" :rows="2" placeholder="请输入被动技能描述" />
          </el-form-item>

          <el-form-item label="Q技能" prop="heroSkillsQ">
            <el-input type="textarea" v-model="heroData.heroSkillsQ" :rows="2" placeholder="请输入Q技能描述" />
          </el-form-item>

          <el-form-item label="W技能" prop="heroSkillsW">
            <el-input type="textarea" v-model="heroData.heroSkillsW" :rows="2" placeholder="请输入W技能描述" />
          </el-form-item>

          <el-form-item label="E技能" prop="heroSkillsE">
            <el-input type="textarea" v-model="heroData.heroSkillsE" :rows="2" placeholder="请输入E技能描述" />
          </el-form-item>

          <el-form-item label="R技能" prop="heroSkillsR">
            <el-input type="textarea" v-model="heroData.heroSkillsR" :rows="2" placeholder="请输入R技能描述" />
          </el-form-item>
        </div>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitForm">确定</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 删除确认框 -->
    <el-dialog
      v-model="deleteDialogVisible"
      title="确认删除"
      width="30%"
    >
      <span>确定要删除该英雄吗？此操作不可恢复。</span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="deleteDialogVisible = false">取消</el-button>
          <el-button type="danger" @click="confirmDelete">确定</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.hero-manager {
  padding: 24px;
  background-color: #f8fafc;
  min-height: 100vh;
}

.table-card {
  margin-bottom: 24px;
}

.operation-bar {
  margin-bottom: 16px;
}

.operation-bar .left {
  margin-bottom: 16px;
}

.operation-bar .right {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.form-card {
  max-width: 1200px;
  margin: 0 auto;
}

.card-header {
  margin-bottom: 20px;
}

.card-header h2 {
  margin: 0;
  font-size: 24px;
  color: #1e293b;
}

.subtitle {
  margin: 8px 0 0;
  color: #64748b;
  font-size: 14px;
}

.form-section {
  margin-bottom: 32px;
  padding: 24px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.form-section h3 {
  margin: 0 0 24px;
  color: #334155;
  font-size: 18px;
}

.hero-form :deep(.el-form-item__label) {
  font-weight: 500;
}

.form-actions {
  display: flex;
  justify-content: center;
  gap: 16px;
  margin-top: 32px;
}

.form-actions .el-button {
  min-width: 120px;
}

.image-error {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 32px;
  height: 32px;
  background: #f5f7fa;
  color: #909399;
  border-radius: 4px;
}

/* 技能描述列的样式 */
:deep(.el-table .cell) {
  white-space: nowrap;
}

/* 表格内的图片容器样式 */
.el-image {
  display: block;
  margin: 0 auto;
}

/* 位置选择器样式 */
.position-selector {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.position-item {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  border-radius: 4px;
  cursor: pointer;
  background-color: #f1f5f9;
  border: 1px solid transparent;
  transition: all 0.2s ease;
  user-select: none;
  min-width: 80px;
  justify-content: center;
}

.position-item:hover {
  background-color: #e2e8f0;
}

.position-item.active {
  background-color: #3b82f6;
  color: white;
  border-color: #2563eb;
}

.position-icon {
  width: 20px;
  height: 20px;
  object-fit: contain;
}

.position-item span {
  font-size: 14px;
  white-space: nowrap;
}

/* 修改表单项样式 */
:deep(.el-form-item) {
  margin-bottom: 16px;
}

:deep(.el-form-item__content) {
  flex-wrap: wrap;
}

/* 响应式调整 */
@media screen and (max-width: 768px) {
  .position-selector {
    flex-wrap: nowrap;
    overflow-x: auto;
    padding-bottom: 4px;
  }

  .position-item {
    flex: 0 0 auto;
  }
}

/* 添加版本选择下拉框样式 */
:deep(.el-select) {
  width: 120px !important;  /* 确保宽度生效 */
}

:deep(.el-select .el-input__wrapper) {
  width: 100%;
}
</style>