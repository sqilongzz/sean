<template>
    <div class="version-info-manager">
      <el-card class="table-card">
        <!-- 顶部操作区 -->
        <div class="operation-bar">
          <div class="left">
            <el-button type="primary" @click="showAddDialog">新增版本信息</el-button>
            <el-button
              type="danger"
              @click="handleBatchDelete"
              :disabled="selectedVersions.length === 0"
            >
              批量删除({{ selectedVersions.length }})
            </el-button>
          </div>
          <div class="right">
            <el-form :inline="true" :model="queryParams">
              <el-form-item label="版本">
                <el-select
                  v-model="queryParams.version"
                  placeholder="选择版本"
                  @change="handleSearch"
                  clearable
                  style="width: 120px;"
                >
                  <el-option
                    v-for="ver in ['14.17', '14.18', '15.01']"
                    :key="ver"
                    :label="ver"
                    :value="ver"
                  />
                </el-select>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="handleSearch">查询</el-button>
                <el-button @click="resetQuery">重置</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>

        <!-- 数据表格 -->
        <el-table
          :data="versionList"
          border
          style="width: 100%; height: calc(100vh - 200px);"
          v-loading="loading"
          @selection-change="handleSelectionChange"
        >
          <el-table-column type="selection" width="55" />
          <el-table-column prop="version" label="版本" width="80" />
          <el-table-column prop="heroName" label="英雄名称" width="120" />
          <el-table-column label="英雄头像" width="80" align="center">
            <template #default="{ row }">
              <el-image
                :src="row.picUrl"
                style="width: 40px; height: 40px; border-radius: 4px;"
                fit="cover"
              />
            </template>
          </el-table-column>
          <el-table-column label="段位" width="80">
            <template #default="{ row }">
              {{ getRankLevelName(row.rankLevel) }}
            </template>
          </el-table-column>
          <el-table-column label="强度" width="80">
            <template #default="{ row }">
              {{ row.strength === '0' ? 'OP' : row.strength }}
            </template>
          </el-table-column>
          <el-table-column label="位置" width="80">
            <template #default="{ row }">
              {{ getPositionName(row.heroPosition) }}
            </template>
          </el-table-column>
          <el-table-column prop="winRate" label="胜率" width="100" align="center">
            <template #default="{ row }">
              {{ row.winRate }}%
            </template>
          </el-table-column>
          <el-table-column prop="appearanceRate" label="登场率" width="100" align="center">
            <template #default="{ row }">
              {{ row.appearanceRate }}%
            </template>
          </el-table-column>
          <el-table-column prop="banRate" label="禁用率" width="100" align="center">
            <template #default="{ row }">
              {{ row.banRate }}%
            </template>
          </el-table-column>
        
          <el-table-column label="优势对抗" width="200">
            <template #default="{ row }">
              <div style="display: flex; align-items: center; gap: 4px; flex-wrap: wrap;">
                <template v-if="row.advantageAgainstList && row.advantageAgainstList[0]">
                  <el-image
                    v-for="hero in row.advantageAgainstList"
                    :key="hero.heroId"
                    :src="hero.picUrl"
                    style="width: 30px; height: 30px; border-radius: 4px;"
                    fit="cover"
                  />
                </template>
              </div>
            </template>
          </el-table-column>
          <el-table-column label="劣势对抗" width="200">
            <template #default="{ row }">
              <div style="display: flex; align-items: center; gap: 4px; flex-wrap: wrap;">
                <template v-if="row.inferiorityAgainstList && row.inferiorityAgainstList[0]">
                  <el-image
                    v-for="hero in row.inferiorityAgainstList"
                    :key="hero.heroId"
                    :src="hero.picUrl"
                    style="width: 30px; height: 30px; border-radius: 4px;"
                    fit="cover"
                  />
                </template>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="createTime" label="创建时间" width="200" align="center">
            <template #default="{ row }">
              {{ formatDateTime(row.createTime) }}
            </template>
          </el-table-column>
          <el-table-column prop="updateTime" label="更新时间" width="200" align="center">
            <template #default="{ row }">
              {{ formatDateTime(row.updateTime) }}
            </template>
          </el-table-column>
          <el-table-column label="操作" width="120" fixed="right">
            <template #default="scope">
              <el-button type="primary" link @click="handleEdit(scope.row)">编辑</el-button>
              <el-button type="danger" link @click="handleDelete(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- 分页 -->
        <div class="pagination-container">
          <el-pagination
            v-model:current-page="queryParams.page"
            v-model:page-size="queryParams.pageSize"
            :page-sizes="[10, 20, 50, 100]"
            :total="total"
            layout="total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </el-card>

      <!-- 新增/编辑对话框 -->
      <el-dialog
        :title="dialogTitle"
        v-model="dialogVisible"
        width="500px"
      >
        <el-form
          ref="formRef"
          :model="formData"
          :rules="rules"
          label-width="100px"
        >
          <el-form-item label="版本" prop="version">
            <el-select 
              v-model="formData.version" 
              placeholder="选择版本"
              @change="handleVersionChange"
            >
              <el-option
                v-for="ver in ['14.17', '14.18', '15.01']"
                :key="ver"
                :label="ver"
                :value="ver"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="段位" prop="rankLevel">
            <el-select 
              v-model="formData.rankLevel" 
              placeholder="选择段位"
              @change="handleRankLevelChange"
              :disabled="!formData.version"
            >
              <el-option
                v-for="(value, key) in rankLevelMap"
                :key="key"
                :label="key"
                :value="value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="位置" prop="heroPosition">
            <el-select 
              v-model="formData.heroPosition" 
              placeholder="选择位置"
              @change="handlePositionChange"
              :disabled="!formData.version || !formData.rankLevel"
            >
              <el-option
                v-for="(value, key) in positionMap"
                :key="key"
                :label="key"
                :value="value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="英雄" prop="heroId">
            <el-select 
              v-model="formData.heroId" 
              placeholder="选择英雄"
              :disabled="!formData.version || !formData.rankLevel || !formData.heroPosition"
            >
              <el-option
                v-for="hero in heroList"
                :key="hero.heroId"
                :label="hero.heroName"
                :value="hero.heroId"
              >
                <div style="display: flex; align-items: center; gap: 8px;">
                  <el-image
                    :src="hero.picUrl"
                    style="width: 30px; height: 30px; border-radius: 4px;"
                    fit="cover"
                  />
                  <span>{{ hero.heroName }}</span>
                </div>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="装备ID" prop="equipmentId">
            <el-input v-model="formData.equipmentId" />
          </el-form-item>
          <el-form-item label="强度" prop="strength">
            <el-select 
              v-model="formData.strength"
              placeholder="选择强度"
            >
              <el-option
                v-for="option in strengthOptions"
                :key="option.value"
                :label="option.label"
                :value="option.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="胜率" prop="winRate">
            <el-input v-model="formData.winRate">
              <template #append>%</template>
            </el-input>
          </el-form-item>
          <el-form-item label="登场率" prop="appearanceRate">
            <el-input v-model="formData.appearanceRate">
              <template #append>%</template>
            </el-input>
          </el-form-item>
          <el-form-item label="禁用率" prop="banRate">
            <el-input v-model="formData.banRate">
              <template #append>%</template>
            </el-input>
          </el-form-item>
          <el-form-item label="优势对抗" prop="advantageAgainst">
            <el-select
              v-model="formData.advantageAgainst"
              placeholder="选择优势对抗英雄"
              multiple
              :disabled="!formData.version"
              collapse-tags
              collapse-tags-tooltip
            >
              <el-option
                v-for="hero in allHeroList"
                :key="hero.heroId"
                :label="hero.heroName"
                :value="hero.heroId"
              >
                <div style="display: flex; align-items: center; gap: 8px;">
                  <el-image
                    :src="hero.picUrl"
                    style="width: 30px; height: 30px; border-radius: 4px;"
                    fit="cover"
                  />
                  <span>{{ hero.heroName }}</span>
                </div>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="劣势对抗" prop="inferiorityAgainst">
            <el-select
              v-model="formData.inferiorityAgainst"
              placeholder="选择劣势对抗英雄"
              multiple
              :disabled="!formData.version"
              collapse-tags
              collapse-tags-tooltip
            >
              <el-option
                v-for="hero in allHeroList"
                :key="hero.heroId"
                :label="hero.heroName"
                :value="hero.heroId"
              >
                <div style="display: flex; align-items: center; gap: 8px;">
                  <el-image
                    :src="hero.picUrl"
                    style="width: 30px; height: 30px; border-radius: 4px;"
                    fit="cover"
                  />
                  <span>{{ hero.heroName }}</span>
                </div>
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="handleSubmit">确定</el-button>
          </span>
        </template>
      </el-dialog>
    </div>
  </template>

  <script setup>
  import { ref, onMounted, reactive } from 'vue'
  import { ElMessage, ElMessageBox } from 'element-plus'
  import axios from 'axios'

  // 数据列表
  const versionList = ref([])
  const loading = ref(false)
  const selectedVersions = ref([])

  // 对话框相关
  const dialogVisible = ref(false)
  const dialogTitle = ref('')
  const formRef = ref(null)

  // 修改强度映射为有序对象
  const strengthOptions = [
    { label: 'OP', value: 0 },
    { label: '1', value: 1 },
    { label: '2', value: 2 },
    { label: '3', value: 3 },
    { label: '4', value: 4 }
  ]

  // 用于值到标签的映射
  const strengthMap = {
    'OP': 0,
    '1': 1,
    '2': 2,
    '3': 3,
    '4': 4
  }

  // 表单数据
  const formData = ref({
    id: '',
    version: '',
    heroId: '',
    equipmentId: '',
    rankLevel: '',
    strength: '',
    heroPosition: '',
    winRate: '',
    appearanceRate: '',
    banRate: '',
    advantageAgainst: '',
    inferiorityAgainst: ''
  })

  // 映射表
  const rankLevelMap = {
    '黑铁': '1',
    '青铜': '2',
    '白银': '3',
    '黄金': '4',
    '铂金': '5',
    '翡翠': '6',
    '砖石': '7',
    '大师': '8',
    '宗师': '9',
    '最强王者': '0'
  }

  const positionMap = {
    '上单': '1',
    '打野': '2',
    '中单': '3',
    '下路': '4',
    '辅助': '5'
  }

  // 表单验证规则
  const rules = {
    version: [{ required: true, message: '请选择版本', trigger: 'change' }],
    heroId: [{ required: true, message: '请输入英雄ID', trigger: 'blur' }],
    rankLevel: [{ required: true, message: '请选择段位', trigger: 'change' }],
    strength: [{ required: true, message: '请选择强度', trigger: 'change' }],
    heroPosition: [{ required: true, message: '请选择位置', trigger: 'change' }],
    winRate: [
      { required: true, message: '请输入胜率', trigger: 'blur' },
      { pattern: /^\d+(\.\d{0,2})?$/, message: '请输入正确的数字格式，最多保留两位小数', trigger: 'blur' }
    ],
    appearanceRate: [
      { required: true, message: '请输入登场率', trigger: 'blur' },
      { pattern: /^\d+(\.\d{0,2})?$/, message: '请输入正确的数字格式，最多保留两位小数', trigger: 'blur' }
    ],
    banRate: [
      { required: true, message: '请输入禁用率', trigger: 'blur' },
      { pattern: /^\d+(\.\d{0,2})?$/, message: '请输入正确的数字格式，最多保留两位小数', trigger: 'blur' }
    ]
  }

  // 查询参数
  const queryParams = reactive({
    page: 1,
    pageSize: 10,
    version: ''
  })

  // 分页总数
  const total = ref(0)

  // 修改英雄列表的数据结构
  const heroList = ref([])
  const allHeroList = ref([])

  // 获取英雄列表
  const getHeroList = async () => {
    // 检查必要的筛选条件是否都已选择
    if (!formData.value.version || !formData.value.heroPosition) {
      heroList.value = [] // 如果条件不完整，清空列表
      return
    }

    try {
      // 构建请求参数，只包含版本和位置
      const params = {
        version: formData.value.version,
        heroPosition: formData.value.heroPosition
      }
      console.log('获取英雄列表参数：', params)

      const response = await axios.post('http://localhost:10001/hero/getHeroList', params)
      if (response.data.code === 200) {
        allHeroList.value = response.data.data
        
        // 获取已存在的版本信息，修改位置字段名为 position
        const allVersionInfoResponse = await axios.post('http://localhost:10001/versionInfo/getInfoList', {
          version: formData.value.version,
          rankLevel: formData.value.rankLevel,
          position: formData.value.heroPosition  // 修改这里，从 heroPosition 改为 position
        })
        
        if (allVersionInfoResponse.data.code === 200) {
          const existingHeroIds = allVersionInfoResponse.data.data
            .map(record => record.heroId)
          
          heroList.value = response.data.data.filter(hero => 
            !existingHeroIds.includes(hero.heroId)
          )
        }
      }
    } catch (error) {
      console.error('获取英雄列表失败：', error)
      ElMessage.error('获取英雄列表失败')
      heroList.value = []
    }
  }

  // 修改版本变化处理函数
  const handleVersionChange = async () => {
    formData.value.heroId = '' // 清空已选择的英雄
    getHeroList()
  }

  // 修改段位变化处理函数
  const handleRankLevelChange = () => {
    formData.value.heroId = '' // 清空已选择的英雄
    getHeroList()
  }

  // 修改位置变化处理函数
  const handlePositionChange = () => {
    formData.value.heroId = '' // 清空已选择的英雄
    getHeroList()
  }

  // 获取列表数据
  const getVersionList = async () => {
    loading.value = true
    try {
      const requestParams = {
        page: Number(queryParams.page),
        pageSize: Number(queryParams.pageSize),
        version: queryParams.version || null
      }

      const cleanParams = {}
      Object.entries(requestParams).forEach(([key, value]) => {
        if (value !== null && value !== '' && value !== undefined) {
          cleanParams[key] = value
        }
      })

      console.log('请求参数：', cleanParams) // 添加日志

      const response = await axios.post('http://localhost:10001/versionInfo/getInfoListPage', cleanParams)
      console.log('返回数据：', response.data) // 添加日志

      if (response.data.code === 200) {
        const pageData = response.data.data
        versionList.value = pageData.records
        total.value = pageData.total
        queryParams.page = pageData.current
        queryParams.pageSize = pageData.size
      }
    } catch (error) {
      console.error('获取版本信息列表失败：', error)
      ElMessage.error('获取数据失败')
    } finally {
      loading.value = false
    }
  }

  // 搜索处理
  const handleSearch = () => {
    queryParams.page = 1
    getVersionList()
  }

  // 重置查询
  const resetQuery = () => {
    queryParams.page = 1
    queryParams.pageSize = 10
    queryParams.version = ''
    getVersionList()
  }

  // 分页大小变化
  const handleSizeChange = (val) => {
    queryParams.pageSize = val
    getVersionList()
  }

  // 页码变化
  const handleCurrentChange = (val) => {
    queryParams.page = val
    getVersionList()
  }

  // 处理编辑
  const handleEdit = (row) => {
    dialogTitle.value = '编辑版本信息'
    formData.value = {
      id: row.id,
      version: row.version,
      heroId: row.heroId,
      equipmentId: row.equipmentId,
      rankLevel: row.rankLevel,
      strength: row.strength,
      heroPosition: row.heroPosition,
      winRate: row.winRate,
      appearanceRate: row.appearanceRate,
      banRate: row.banRate,
      advantageAgainst: row.advantageAgainst ? row.advantageAgainst.split(',') : [],
      inferiorityAgainst: row.inferiorityAgainst ? row.inferiorityAgainst.split(',') : []
    }
    dialogVisible.value = true
    if (formData.value.version) {
      getHeroList()
    }
  }

  // 处理删除
  const handleDelete = async (row) => {
    console.log('删除的行数据：', row) // 打印要删除的行数据
    try {
      await ElMessageBox.confirm('确定要删除该版本信息吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })

      const response = await axios.delete(`http://localhost:10001/versionInfo/delete/${row.id}`)

      if (response.data.code === 200) {
        if (response.data.data === 'success') {
          ElMessage.success('删除成功')
          getVersionList()
        } else {
          ElMessage.error('删除失败')
        }
      }
    } catch (error) {
      if (error !== 'cancel') {
        console.error('删除失败：', error)
        ElMessage.error('删除失败')
      }
    }
  }

  // 处理批量删除
  const handleBatchDelete = async () => {
    if (selectedVersions.value.length === 0) {
      ElMessage.warning('请选择要删除的数据')
      return
    }

    try {
      await ElMessageBox.confirm('确定要删除选中的版本信息吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })

      // 获取选中行的id列表
      const ids = selectedVersions.value.map(item => item.id)
      
      // 调用批量删除接口
      const response = await axios.delete('http://localhost:10001/versionInfo/deleteBatch', {
        data: ids  // 将id列表作为请求体发送
      })

      if (response.data.code === 200) {
        if (response.data.data === 'success') {
          ElMessage.success('批量删除成功')
          getVersionList()
          selectedVersions.value = []
        } else {
          ElMessage.error('批量删除失败')
        }
      }
    } catch (error) {
      if (error !== 'cancel') {
        console.error('批量删除失败：', error)
        ElMessage.error('删除失败')
      }
    }
  }

  // 处理表单提交
  const handleSubmit = async () => {
    if (!formRef.value) return

    await formRef.value.validate(async (valid) => {
      if (valid) {
        try {
          const url = formData.value.id
            ? 'http://localhost:10001/versionInfo/update'
            : 'http://localhost:10001/versionInfo/add'

          const submitData = {
            ...formData.value,
            strength: String(formData.value.strength),
            winRate: String(formData.value.winRate),
            appearanceRate: String(formData.value.appearanceRate),
            banRate: String(formData.value.banRate),
            advantageAgainst: Array.isArray(formData.value.advantageAgainst) 
              ? formData.value.advantageAgainst.join(',') 
              : formData.value.advantageAgainst,
            inferiorityAgainst: Array.isArray(formData.value.inferiorityAgainst)
              ? formData.value.inferiorityAgainst.join(',')
              : formData.value.inferiorityAgainst
          }

          const response = await axios.post(url, submitData)

          if (response.data.code === 200) {
            ElMessage.success(formData.value.id ? '更新成功' : '添加成功')
            dialogVisible.value = false
            getVersionList()
            // 清空表单数据和校验状态
            formData.value = {
              id: '',
              version: '',
              heroId: '',
              equipmentId: '',
              rankLevel: '',
              strength: '',
              heroPosition: '',
              winRate: '',
              appearanceRate: '',
              banRate: '',
              advantageAgainst: '',
              inferiorityAgainst: ''
            }
            if (formRef.value) {
              formRef.value.resetFields()
            }
          }
        } catch (error) {
          console.error('保存失败：', error)
          ElMessage.error('保存失败')
        }
      }
    })
  }

  // 处理选择变化
  const handleSelectionChange = (selection) => {
    selectedVersions.value = selection
  }

  // 获取段位名称
  const getRankLevelName = (value) => {
    return Object.entries(rankLevelMap).find(([key, val]) => val === value)?.[0] || value
  }

  // 获取位置名称
  const getPositionName = (value) => {
    return Object.entries(positionMap).find(([key, val]) => val === value)?.[0] || value
  }

  // 显示新增对话框
  const showAddDialog = () => {
    dialogTitle.value = '新增版本信息'
    // 重置表单数据
    formData.value = {
      id: '',
      version: '',
      heroId: '',
      equipmentId: '',
      rankLevel: '',
      strength: '',
      heroPosition: '',
      winRate: '',
      appearanceRate: '',
      banRate: '',
      advantageAgainst: [],
      inferiorityAgainst: []
    }
    // 清空表单验证
    if (formRef.value) {
      formRef.value.resetFields()
    }
    // 显示对话框
    dialogVisible.value = true
  }

  // 添加时间格式化函数
  const formatDateTime = (timestamp) => {
    if (!timestamp) return '--'
    const date = new Date(timestamp)
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    const hours = String(date.getHours()).padStart(2, '0')
    const minutes = String(date.getMinutes()).padStart(2, '0')
    const seconds = String(date.getSeconds()).padStart(2, '0')
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
  }

  onMounted(() => {
    getVersionList()
  })
  </script>

  <style scoped>
  .version-info-manager {
    height: 100%;
    padding: 20px;
    box-sizing: border-box;
  }

  .table-card {
    height: calc(100vh - 40px); /* 减去padding的高度 */
  }

  .operation-bar {
    margin-bottom: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  /* 确保表格内容可以滚动 */
  :deep(.el-table__body-wrapper) {
    overflow-y: auto;
  }

  /* 调整表格行高 */
  :deep(.el-table__row) {
    height: 60px;
  }

  /* 优化表格内容布局 */
  :deep(.el-table .cell) {
    padding: 0 8px;
    line-height: 1.5;
  }

  /* 时间列的特殊样式 */
  :deep(.el-table .time-column) {
    font-family: 'Roboto Mono', monospace;
    color: #666;
    font-size: 14px;
  }
  </style>