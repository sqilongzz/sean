<template>
  <div class="home-container">
    <!-- 搜索区域 -->
    <div class="search-section">
      <div class="search-box">
        <el-input
          v-model="searchQuery"
          placeholder="搜索召唤师..."
          class="search-input"
          @keyup.enter="searchSummoner"
        >
          <template #prefix>
            <i class="el-icon-search"></i>
          </template>
        </el-input>
        <el-button type="primary" @click="searchSummoner" class="search-btn">
          搜索
        </el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      searchQuery: '',
    }
  },
  methods: {
    searchSummoner() {
      // 实现搜索逻辑
      console.log('Searching for:', this.searchQuery)
    }
  }
}
</script>

<style scoped>
.home-container {
  padding: 20px;
}

/* 搜索区域样式 */
.search-section {
  margin-bottom: 40px;
  display: flex;
  justify-content: center;
}

.search-box {
  width: 100%;
  max-width: 600px;
  display: flex;
  gap: 12px;
}

.search-input {
  :deep(.el-input__inner) {
    height: 48px;
    border-radius: 8px;
    font-size: 16px;
    border-color: #e2e8f0;
  }

  :deep(.el-input__inner:focus) {
    border-color: #00c8c8;
    box-shadow: 0 0 0 2px rgba(0, 200, 200, 0.1);
  }
}

.search-btn {
  width: 100px;
  height: 48px;
  border-radius: 8px;
  background: #00c8c8;
  border-color: #00c8c8;
  font-size: 16px;
}

.search-btn:hover {
  background: #00b3b3;
  border-color: #00b3b3;
}
</style>
