<template>
  <el-header class="header">
    <div class="logo-container">
      <a href="http://localhost:5173/index" class="logo-link">
        <span class="logo-text">OP.GG</span>
      </a>

      <el-dropdown @command="handleGameSelect" class="game-dropdown">
        <div class="game-selector">
          {{ getGameName(selectedGame) }} <i class="el-icon-arrow-down el-icon--right"></i>
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item command="lol">英雄联盟</el-dropdown-item>
            <el-dropdown-item command="valorant">无畏契约</el-dropdown-item>
            <el-dropdown-item command="pubg">绝地求生</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>

    <el-dropdown placement="top-start">
      <el-button class="user-button">
        <i class="el-icon-user"></i>
        {{ userInfo.nickname }}
      </el-button>
      <template #dropdown>
        <el-dropdown-menu>
          <el-dropdown-item @click="logout">登出账号</el-dropdown-item>
          <el-dropdown-item @click="editUserInfo">个人信息</el-dropdown-item>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </el-header>

  <el-main class="main-content">
    <div class="game-content" :class="selectedGame">
      <div v-if="selectedGame === 'lol'">
        <el-menu :default-active="activeLolTab" class="lol-tab-menu" mode="horizontal" @select="handleLolTabSelect">
          <el-menu-item index="homePage">首页</el-menu-item>
          <el-menu-item index="heroData">英雄数据</el-menu-item>
          <el-menu-item index="heroManager">英雄管理</el-menu-item>
          <el-menu-item index="heroVersionInfoManager">信息管理</el-menu-item>
        </el-menu>
        
        <div class="tab-content">
          <component :is="currentLolComponent"></component>
        </div>
      </div>
      <div v-else-if="selectedGame === 'valorant'">
        <h2>无畏契约板块</h2>
        <p>这是无畏契约的内容...</p>
      </div>
      <div v-else-if="selectedGame === 'pubg'">
        <h2>绝地求生板块</h2>
        <p>这是绝地求生的内容...</p>
      </div>
      <div v-else class="empty-state">
        <i class="el-icon-games"></i>
        <h2>请选择一个游戏</h2>
      </div>
    </div>
  </el-main>
</template>

<script>
import axios from 'axios';
import { defineAsyncComponent } from 'vue'

export default {
  data() {
    return {
      activeTab: '', // 默认激活的标签页
      selectedGame: 'lol', // 默认选择英雄联盟
      userInfo: {
        nickname: '',
      },
      activeLolTab: 'homePage', // 默认显示首页
    };
  },
  components: {
    // 异步加载组件
    LolHomePage: defineAsyncComponent(() => import('./lol/HomePage.vue')),
    LolHeroData: defineAsyncComponent(() => import('./lol/HeroData.vue')),
    LolHeroManager: defineAsyncComponent(() => import('./lol/HeroManager.vue')),
    LolHeroVersionInfoManager: defineAsyncComponent(() => import('./lol/HeroVersionInfoManager.vue')),
  },
  computed: {
    currentLolComponent() {
      // 根据当前选中的tab返回对应的组件
      const componentMap = {
        homePage: 'LolHomePage',
        heroData: 'LolHeroData',
        heroManager: 'LolHeroManager',
        heroVersionInfoManager: 'LolHeroVersionInfoManager'
      }
      return componentMap[this.activeLolTab]
    }
  },
  methods: {
    logout() {
      // 清除 localStorage 中的用户信息
      localStorage.removeItem('token');
      // localStorage.removeItem('nickname');
      // 跳转到登录页面
      this.$router.push('/');
      // 处理其他登出逻辑（如通知用户等）
      this.$message.success('登出成功');
    },
    editUserInfo() {
      this.$router.push('/editUserInfo');
      // 打开用户信息编辑界面
    },
    async fetchUserInfo() {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:10001/user/getUserInfo', {
          headers: {
            token: token
          }
        });
        this.userInfo = response.data.data;
      } catch (error) {
        console.error('获取用户信息失败:', error);
      }
    },
    handleGameSelect(game) {
      this.selectedGame = game;
      // 可以添加路由跳转或其他逻辑
      this.$message({
        message: `已选择 ${this.getGameName(game)}`,
        type: 'success'
      });
    },
    getGameName(game) {
      const gameNames = {
        'lol': '英雄联盟',
        'valorant': '无畏契约',
        'pubg': '绝地求生'
      };
      return gameNames[game] || game;
    },
    handleLolTabSelect(tab) {
      this.activeLolTab = tab
    }
  },
  mounted() {
    this.fetchUserInfo()
  }
};
</script>



<style>
/* 添加全局样式 */
:root {
  overflow-x: hidden;
  width: 100%;
}

/* 确保所有基础元素都不会产生横向滚动 */
html, body, #app {
  margin: 0;
  padding: 0;
  width: 100%;
  min-height: 100vh;
  overflow-x: hidden;
}

</style>

<style scoped>
.header {
  background-color: #1e2328;
  color: white;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  height: 60px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  width: 100vw;
  max-width: 100%;
  box-sizing: border-box;
}

.logo-container {
  display: flex;
  align-items: center;
  gap: 20px;
}

.logo-link {
  text-decoration: none;
}

.logo-text {
  font-size: 24px;
  font-weight: bold;
  color: #00c8c8;
  letter-spacing: 1px;
}

.game-dropdown {
  margin-left: 20px;
}

.game-selector {
  color: #ffffff;
  cursor: pointer;
  padding: 8px 12px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.game-selector:hover {
  background-color: rgba(255, 255, 255, 0.1);
}

.user-button {
  background-color: transparent;
  border: 1px solid #00c8c8;
  color: #00c8c8;
  padding: 8px 16px;
  transition: all 0.3s;
}

.user-button:hover {
  background-color: #00c8c8;
  color: white;
}

.main-content {
  padding: 20px;
  background-color: #f8f9fa;
  min-height: calc(100vh - 60px);
  width: 100vw;
  max-width: 100%;
  box-sizing: border-box;
  overflow-x: hidden;
}

.game-content {
  background-color: white;
  border-radius: 8px;
  padding: 24px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  width: 100%;
  box-sizing: border-box;
}

.empty-state {
  text-align: center;
  padding: 40px;
  color: #666;
}

.empty-state i {
  font-size: 48px;
  margin-bottom: 16px;
}

h2 {
  color: #1e2328;
  margin-bottom: 16px;
  font-size: 24px;
}

/* 修复滚动问题 */
html, body {
  height: 100%;
  margin: 0;
  overflow-x: hidden;
  width: 100%;
}

/* 添加新的容器样式 */
.el-container {
  width: 100%;
  min-height: 100vh;
  overflow-x: hidden;
}

.el-header {
  width: 100%;
  box-sizing: border-box; /* 确保padding不会导致宽度溢出 */
}

.el-main {
  width: 100%;
  box-sizing: border-box;
  padding: 20px;
}

.lol-tab-menu {
  margin-bottom: 20px;
  background-color: transparent;
}

.tab-content {
  padding: 20px 0;
}

/* 自定义tab样式 */
:deep(.el-menu--horizontal) {
  border-bottom: 1px solid #e6e6e6;
}

:deep(.el-menu-item) {
  font-size: 16px;
  height: 50px;
  line-height: 50px;
}

:deep(.el-menu-item.is-active) {
  color: #00c8c8;
  border-bottom: 2px solid #00c8c8;
}

:deep(.el-menu-item:hover) {
  color: #00c8c8;
}
</style>
