CREATE TABLE tb_user(
                        `ID` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
                        `USER_NAME` VARCHAR(10) NULL COMMENT '账号',
                        `PASSWORD` VARCHAR(20) NULL COMMENT '密码',
                        `PHONE` VARCHAR(20) NULL COMMENT '电话号码',
                        `EMAIL` VARCHAR(20) NULL COMMENT '邮箱',
                        PRIMARY KEY (ID)
)ENGINE INNODB COMMENT='用户表';