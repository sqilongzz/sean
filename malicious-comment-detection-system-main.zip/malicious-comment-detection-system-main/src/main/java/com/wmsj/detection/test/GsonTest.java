package com.wmsj.detection.test;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.wmsj.detection.entity.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GsonTest {

    public static void main(String[] args) {
        // 创建 Gson 实例
        Gson gson = new Gson();

        System.out.println("==========Map==========");
        // 创建一个 Map
        Map<String, String> map = new HashMap<>();
        map.put("number1", "1");
        map.put("number2", "2");
        map.put("number3", "3");
        // 输出原始的 Map
        System.out.println("Original Map: " + map);

        // 将 Map 转换为 JSON 字符串
        String jsonString = gson.toJson(map);
        System.out.println("Serialized JSON: " + jsonString);

        // 将 JSON 字符串反序列化回 Map
        Map<String, String> deserializedMap = gson.fromJson(jsonString, Map.class);
        System.out.println("Deserialized Map: " + deserializedMap);

        System.out.println("==========User==========");

        User user = new User();
        user.setUserName("Andy");
        user.setPassword("123");
        user.setEmail("andy@gmail.com");
        System.out.println("Original User: " + user);
        // 将 User 对象转换为 JSON 字符串
        String userJson = gson.toJson(user);
        System.out.println("User JSON: " + userJson);

        // 将 JSON 字符串反序列化回 User 对象
        User deserializedUser = gson.fromJson(userJson, User.class);
        System.out.println("Deserialized User : userName: " + deserializedUser.getUserName() +
                ", password: " + deserializedUser.getPassword() +
                ", email: " + deserializedUser.getEmail());

        System.out.println("==========List==========");
        // 创建一个 List
        List<String> numbers = new ArrayList<>();
        numbers.add("1");
        numbers.add("2");
        numbers.add("3");
        System.out.println("Original List: " + numbers);
        // 将 List 转换为 JSON 字符串
        String json = gson.toJson(numbers);
        System.out.println("List JSON: " + json);

        System.out.println("==========User List==========");
        // 创建一个 User List
        List<User> users = new ArrayList<>();
        User userList1 = new User();
        userList1.setUserName("Andy");
        userList1.setPassword("123");
        User userList2 = new User();
        userList2.setUserName("Tom");
        userList2.setPassword("456");
        users.add(userList1);
        users.add(userList2);
        System.out.println("Original List: " + users);
        // 将 List<User> 转换为 JSON 字符串
        String jsonUser = gson.toJson(users);
        System.out.println("User List JSON: " + jsonUser);

        System.out.println("==========String==========");
        // JSON 字符串
        String jsonStr = "{\"userName\":\"Alice\",\"password\":789}";
        System.out.println("Original String: " + jsonStr);
        // 将字符串转换为 JsonObject
        JsonObject jsonObject = gson.fromJson(jsonStr, JsonObject.class);
        System.out.println("userName: " + jsonObject.get("userName").getAsString() +"  password: " + jsonObject.get("password").getAsString());
        // 或者转换为自定义对象
        User userStr = gson.fromJson(jsonStr, User.class);
        System.out.println("User userName: " + userStr.getUserName() + ", password: " + userStr.getPassword());
    }
}
