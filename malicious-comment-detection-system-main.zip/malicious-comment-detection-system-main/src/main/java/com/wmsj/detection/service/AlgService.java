package com.wmsj.detection.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.wmsj.detection.common.service.BaseService;
import com.wmsj.detection.entity.Alg;
import com.wmsj.detection.request.AlgRequest;
import com.wmsj.detection.util.Result;

import java.util.List;

public interface AlgService extends BaseService<Alg> {

    Result<String> addAlg(AlgRequest algRequest);
    Result<String> updateAlg(AlgRequest algRequest);
    Result<String> deleteAlg(String id);
    Result<String> deleteBatch(List<String> ids);
    Result<Alg> getAlg(String id);
    Result<List<Alg>> getAllAlg(String AlgName, String AlgType);
    IPage<Alg> queryAlg(String query, Integer page, Integer size);
}
