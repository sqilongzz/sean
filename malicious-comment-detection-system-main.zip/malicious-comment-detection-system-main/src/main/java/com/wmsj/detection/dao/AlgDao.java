package com.wmsj.detection.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wmsj.detection.entity.Alg;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AlgDao extends BaseMapper<Alg> {

}
