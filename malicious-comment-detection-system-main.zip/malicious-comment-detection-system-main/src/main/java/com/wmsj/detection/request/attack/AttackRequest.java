package com.wmsj.detection.request.attack;

import lombok.Data;

@Data
public class AttackRequest {
    private AttackForm form;                  // 前端的 form 数据
    private TrainingParams trainingParams;  // 前端的 trainingParams 数据
}
