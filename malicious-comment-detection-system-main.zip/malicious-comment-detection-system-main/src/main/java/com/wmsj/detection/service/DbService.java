package com.wmsj.detection.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.wmsj.detection.common.service.BaseService;
import com.wmsj.detection.entity.Db;
import com.wmsj.detection.request.DbRequest;
import com.wmsj.detection.util.Result;

import java.util.List;

public interface DbService extends BaseService<Db> {

    Result<String> addDb(DbRequest dbRequest);
    Result<String> updateDb(DbRequest dbRequest);
    Result<String> deleteDb(String id);
    Result<String> deleteBatch(List<String> ids);
    Result<Db> getDb(String id);
    Result<List<Db>> getAllDbs(String dbName, String dbType);
    IPage<Db> queryDb(String query, Integer page, Integer size);
}
