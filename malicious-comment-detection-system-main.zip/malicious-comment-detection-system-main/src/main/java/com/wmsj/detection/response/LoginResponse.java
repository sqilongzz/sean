package com.wmsj.detection.response;

import lombok.Data;

@Data
public class LoginResponse {
    private String token;
    private String nickname;

}
