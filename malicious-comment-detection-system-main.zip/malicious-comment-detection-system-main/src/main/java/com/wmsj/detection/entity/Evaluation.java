package com.wmsj.detection.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

@Data
@TableName("tb_evaluation")
public class Evaluation {
    //定义 serialVersionUID 是一个良好的实践，可以帮助管理类的版本，避免因类结构变化而导致的序列化和反序列化问题。
    private static final long serialVersionUID = 1L;

    @TableId(type= IdType.AUTO)
    private String id;
    private String evaluationName;//测评名称
    private Date evaluationTime;//测评时间
    private String type;
    private String attackType;
    private String defenseType;
    private String targetModel;//目标模型
    private String alg;
    private String dataSet;//数据集
    private String poisonedSample;//中毒样本数
    private String cleanAccuracy;//干净准确度
    private String attackSuccessRate;//攻击成功率
    private String evaluationSuccessRate;//检测成功率
    private String score;//评分
    private String poisoningRate;//投毒率
    private String trainingSet;//训练集
    private String learningRate;//学习率
    private String batchSize;//批次大小
    private String epochs;//迭代次数
    private Date createTime;
    private Date updateTime;

}
