package com.wmsj.detection.controller;

import com.wmsj.detection.request.attack.AttackRequest;
import com.wmsj.detection.service.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/task")
public class TaskController {

    @Autowired
    private TaskService taskService;

    // 启动任务
    @PostMapping("attack/start")
    public Map<String, Object> startTask(@RequestBody AttackRequest request) {
        return taskService.startTask(request);
    }

    // 获取任务进度
    @GetMapping("attack/progress")
    public Map<String, Object> getTaskProgress() {
        return taskService.getTaskProgress();
    }

    // 取消任务
    @PostMapping("attack/cancel")
    public String cancelTask(@RequestBody Map<String, String> request) {
        String taskId = request.get("taskId");
        return taskService.cancelTask(taskId);
    }
}
