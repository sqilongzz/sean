package com.wmsj.detection.request.attack;

import lombok.Data;

@Data
public class TrainingParams {
    private String trainingSet;   // 训练集
    private String learningRate;     // 学习率
    private String batchSize;        // 批次大小
    private String epochs;           // 迭代次数
}
