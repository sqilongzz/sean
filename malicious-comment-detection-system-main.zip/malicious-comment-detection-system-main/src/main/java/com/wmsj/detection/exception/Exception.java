package com.wmsj.detection.exception;

public class Exception {
}
