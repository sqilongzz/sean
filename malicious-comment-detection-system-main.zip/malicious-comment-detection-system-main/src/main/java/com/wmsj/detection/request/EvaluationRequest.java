package com.wmsj.detection.request;

import lombok.Data;

import java.util.Date;

@Data
public class EvaluationRequest {
    private String id;
    private String evaluationName;//测评名称
    private Date evaluationTime;//测评时间
    private String type;
    private String attackType;
    private String defenseType;
    private String targetModel;//目标模型
    private String alg;
    private String dataSet;//数据集
    private String poisonedSample;//中毒样本数
    private String cleanAccuracy;//干净准确度
    private String attackSuccessRate;//攻击成功率
    private String evaluationSuccessRate;//检测成功率
    private String score;//评分
    private String poisoningRate;//投毒率
    private String trainingSet;//训练集
    private String learningRate;//学习率
    private String batchSize;//批次大小
    private String epochs;//迭代次数
}
