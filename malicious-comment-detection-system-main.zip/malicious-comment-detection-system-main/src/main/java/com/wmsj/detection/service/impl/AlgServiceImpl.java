package com.wmsj.detection.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wmsj.detection.common.service.impl.BaseServiceImpl;
import com.wmsj.detection.dao.AlgDao;
import com.wmsj.detection.entity.Alg;
import com.wmsj.detection.request.AlgRequest;
import com.wmsj.detection.service.AlgService;
import com.wmsj.detection.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Slf4j
@Service
public class AlgServiceImpl extends BaseServiceImpl<AlgDao, Alg> implements AlgService {
    @Autowired
    private AlgDao algDao;

    @Override
    public Result<String> addAlg(AlgRequest algRequest) {
        Alg alg = new Alg();
        BeanUtils.copyProperties(algRequest,alg);
        alg.setCreateTime(new Date());
        alg.setId(null);
        if(algDao.insert(alg) < 0){
            return Result.error("新增失败");
        }
        return Result.ok("新增成功");
    }

    @Override
    public Result<String> updateAlg(AlgRequest algRequest) {
        QueryWrapper<Alg> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Alg::getId,algRequest.getId());
        Alg alg = new Alg();
        BeanUtils.copyProperties(algRequest,alg);
        int update = algDao.update(alg, queryWrapper);
        if(update < 0){
            Result.error("更新失败");
        }
        return Result.ok("更新成功");
    }

    @Override
    public Result<String> deleteAlg(String id) {
        if(algDao.deleteById(id) < 0){
            return Result.error("删除失败");
        }
        return Result.ok("删除成功");
    }

    @Override
    public Result<String> deleteBatch(List<String> ids) {
        if(algDao.deleteBatchIds(ids) < 0){
            return Result.error("删除失败");
        }
        return Result.ok("删除成功");
    }

    @Override
    public Result<Alg> getAlg(String id) {
        QueryWrapper<Alg> wrapper = new QueryWrapper<>();
        wrapper.eq("id", id);
        Alg alg = algDao.selectOne(wrapper);
        if(alg == null){
            Result.error("未查询到数据");
        }
        return Result.ok(alg);
    }

    @Override
    public Result<List<Alg>> getAllAlg(String algName, String algType) {
        QueryWrapper<Alg> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Alg::getAlgName, algName);
        queryWrapper.lambda().eq(Alg::getAlgType, algType);
        List<Alg> algs = algDao.selectList(queryWrapper);
        return Result.ok(algs);
    }

    @Override
    public IPage<Alg> queryAlg(String query, Integer page, Integer size) {
        QueryWrapper<Alg> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().like(Alg::getAlgName, query);
        IPage<Alg> algPage = new Page<>(page, size);
        IPage<Alg> algIPage = algDao.selectPage(algPage, queryWrapper);
        log.info(String.valueOf(algIPage));
        return algIPage;
//        List<Alg> algs = algDao.selectList(queryWrapper);
//        return Result.ok(algs);
    }
}
