package com.wmsj.detection.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wmsj.detection.entity.Evaluation;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EvaluationDao extends BaseMapper<Evaluation> {

}
