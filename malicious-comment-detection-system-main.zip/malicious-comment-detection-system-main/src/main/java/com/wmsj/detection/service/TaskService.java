package com.wmsj.detection.service;

import com.wmsj.detection.request.attack.AttackRequest;

import java.util.List;
import java.util.Map;

public interface TaskService {
    Map<String, Object> startTask(AttackRequest request);
    Map<String, Object> getTaskProgress();
    String cancelTask(String taskId);
}
