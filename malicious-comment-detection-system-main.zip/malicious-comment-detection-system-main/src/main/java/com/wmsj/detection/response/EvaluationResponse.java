package com.wmsj.detection.response;

import com.wmsj.detection.entity.Evaluation;
import lombok.Data;

import java.text.SimpleDateFormat;

@Data
public class EvaluationResponse {
    private String id;
    private String evaluationName;
    private String evaluationTime;
    private String evaluationTimeFormatted;
    private String type;
    private String attackType;
    private String defenseType;
    private String targetModel; // 目标模型
    private String alg;
    private String dataSet; // 数据集
    private String poisonedSample; // 中毒样本数
    private String cleanAccuracy; // 干净准确度
    private String attackSuccessRate; // 攻击成功率
    private String evaluationSuccessRate; // 检测成功率
    private String score; // 评分
    private String poisoningRate; // 投毒率
    private String trainingSet; // 训练集
    private String learningRate; // 学习率
    private String batchSize; // 批次大小
    private String epochs; // 迭代次数

    // 构造函数
    public EvaluationResponse(Evaluation evaluation) {
        // 直接复制属性值，时间字段单独处理
        this.id = evaluation.getId();
        this.evaluationName = evaluation.getEvaluationName();
        this.type = evaluation.getType();
        this.attackType = evaluation.getAttackType();
        this.defenseType = evaluation.getDefenseType();
        this.targetModel = evaluation.getTargetModel();
        this.alg = evaluation.getAlg();
        this.dataSet = evaluation.getDataSet();
        this.poisonedSample = evaluation.getPoisonedSample();
        this.cleanAccuracy = evaluation.getCleanAccuracy();
        this.attackSuccessRate = evaluation.getAttackSuccessRate();
        this.evaluationSuccessRate = evaluation.getEvaluationSuccessRate();
        this.score = evaluation.getScore();
        this.poisoningRate = evaluation.getPoisoningRate();
        this.trainingSet = evaluation.getTrainingSet();
        this.learningRate = evaluation.getLearningRate();
        this.batchSize = evaluation.getBatchSize();
        this.epochs = evaluation.getEpochs();

        // 格式化时间
        if (evaluation.getEvaluationTime() != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            this.evaluationTimeFormatted = dateFormat.format(evaluation.getEvaluationTime());
        }

        // 复制时间字段为字符串
        if (evaluation.getEvaluationTime() != null) {
            this.evaluationTime = String.valueOf(evaluation.getEvaluationTime().getTime());
        } else {
            this.evaluationTime = "";
        }
    }
}
