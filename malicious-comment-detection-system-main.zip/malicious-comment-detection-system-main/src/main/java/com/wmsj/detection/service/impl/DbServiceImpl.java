package com.wmsj.detection.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wmsj.detection.common.service.impl.BaseServiceImpl;
import com.wmsj.detection.dao.DbDao;
import com.wmsj.detection.entity.Db;
import com.wmsj.detection.request.DbRequest;
import com.wmsj.detection.service.DbService;
import com.wmsj.detection.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Slf4j
@Service
public class DbServiceImpl extends BaseServiceImpl<DbDao, Db> implements DbService {
    @Autowired
    private DbDao dbDao;


    @Override
    public Result<String> addDb(DbRequest dbRequest) {
        Db db = new Db();
        BeanUtils.copyProperties(dbRequest,db);
        db.setCreateTime(new Date());
        db.setId(null);
        if(dbDao.insert(db) < 0){
            return Result.error("新增失败");
        }
        return Result.ok("新增成功");
    }

    @Override
    public Result<String> updateDb(DbRequest dbRequest) {
        QueryWrapper<Db> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Db::getId,dbRequest.getId());
        Db db = new Db();
        BeanUtils.copyProperties(dbRequest,db);
        int update = dbDao.update(db, queryWrapper);
        if(update < 0){
            Result.error("更新失败");
        }
        return Result.ok("更新成功");
    }

    @Override
    public Result<String> deleteDb(String id) {
        if(dbDao.deleteById(id) < 0){
            return Result.error("删除失败");
        }
        return Result.ok("删除成功");
    }

    @Override
    public Result<String> deleteBatch(List<String> ids) {
        if(dbDao.deleteBatchIds(ids) < 0){
            return Result.error("删除失败");
        }
        return Result.ok("删除成功");
    }

    @Override
    public Result<Db> getDb(String id) {
        QueryWrapper<Db> wrapper = new QueryWrapper<>();
        wrapper.eq("id", id);
        Db db = dbDao.selectOne(wrapper);
        if(db == null){
            Result.error("未查询到数据");
        }
        return Result.ok(db);
    }

    @Override
    public Result<List<Db>> getAllDbs(String dbName, String dbType) {
        QueryWrapper<Db> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Db::getDbName, dbName);
        queryWrapper.lambda().eq(Db::getDbType, dbType);
        List<Db> dbs = dbDao.selectList(queryWrapper);
        return Result.ok(dbs);
    }

    @Override
    public IPage<Db> queryDb(String query, Integer page, Integer size) {
        QueryWrapper<Db> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().like(Db::getDbName, query);
        IPage<Db> dbPage = new Page<>(page, size);
        IPage<Db> dbIPage = dbDao.selectPage(dbPage, queryWrapper);
        log.info(String.valueOf(dbIPage));
        return dbIPage;
//        IPage<Db> dbPage = new Page<>();
//        dbPage.setPages(page);
//        dbPage.setSize(size);
//        List<Db> dbs = dbDao.selectList(dbPage,queryWrapper);
//        return Result.ok(dbIPage);
    }
}
