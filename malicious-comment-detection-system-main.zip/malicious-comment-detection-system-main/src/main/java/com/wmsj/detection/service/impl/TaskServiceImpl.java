package com.wmsj.detection.service.impl;

import com.wmsj.detection.request.EvaluationRequest;
import com.wmsj.detection.request.attack.AttackForm;
import com.wmsj.detection.request.attack.AttackRequest;
import com.wmsj.detection.request.attack.TrainingParams;
import com.wmsj.detection.service.EvaluationService;
import com.wmsj.detection.service.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadLocalRandom;


/**
 * 总结流程
 * 生成任务ID → 保证任务唯一。
 * 初始化任务进度 → 任务开始时，进度为 0。
 * 提交异步任务 → 使用线程池执行 executeTask 方法。
 * 保存任务状态 → 将任务的 Future 保存在 taskFutures 中。
 * 返回响应 → 通知前端任务已启动，并返回任务ID。
 * <p>
 * 为什么要使用异步任务？
 * 任务可能耗时较长（比如模拟 100 次迭代）。
 * 如果任务在主线程中执行，会阻塞请求，影响系统性能。
 * 使用 线程池 和 异步任务 可以让任务在后台执行，主线程快速响应用户请求。
 * <p>
 * 任务执行过程
 * 前端调用 /task/attack/start 接口，发送请求数据。
 * startTask 方法启动异步任务。
 * 后台执行 executeTask 方法，逐步更新任务进度。
 * 前端通过 轮询 查询进度（例如 /task/attack/progress 接口）。
 * 任务完成后，taskProgress 中的进度会更新为 100。
 * <p>
 * 后续操作
 * 取消任务：可以通过 taskId 从 taskFutures 中获取 Future 并调用 cancel(true)。
 * 查询进度：通过 taskProgress 获取任务的实时进度。
 */
@Slf4j
@Service
public class TaskServiceImpl implements TaskService {

    @Autowired
    private EvaluationService evaluationService;

    private ThreadPoolTaskExecutor taskExecutor;
    // 存储任务
    private final Map<String, Future<?>> taskFutures = new ConcurrentHashMap<>();
    // 存储进度
    private final Map<String, Integer> taskProgress = new ConcurrentHashMap<>();

    public TaskServiceImpl() {
        taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setCorePoolSize(4);
        taskExecutor.setMaxPoolSize(8);
        taskExecutor.initialize();
    }

    // 启动任务
    @Override
    public Map<String, Object> startTask(AttackRequest request) {
        String taskId = UUID.randomUUID().toString(); // 生成任务ID
        taskProgress.put(taskId, 0); // 初始进度为0

        Future<?> future = taskExecutor.submit(() -> executeTask(taskId, request)); // 异步执行任务
        taskFutures.put(taskId, future); // 保存任务Future

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("taskId", taskId);
        return response;
    }

    // 执行任务
    private void executeTask(String taskId, AttackRequest request) {
        try {
            // 100步，每次100ms，一共10000ms=10s
            for (int i = 1; i <= 100; i++) {
                Thread.sleep(100); // 模拟耗时操作
                taskProgress.put(taskId, i); // 更新进度
            }
            //两个小时
//            for (int i = 1; i <= 72000; i++) {
//                Thread.sleep(100); // 每步耗时 100 毫秒
//                // 根据比例更新任务进度
//                taskProgress.put(taskId, i / 720); // 转换为 0-100 的百分比
//            }
            // 任务完成，确保进度为 100
            taskProgress.put(taskId, 100);
            saveRequestData(request);
        } catch (InterruptedException e) {
            taskProgress.put(taskId, -1); // 任务中断
            Thread.currentThread().interrupt();
        } finally {
            // 移除任务的清理操作应移除到 taskFutures 中，而不是 taskProgress
            taskFutures.remove(taskId); // 清理已完成或中断的任务
        }
    }

    private void saveRequestData(AttackRequest request) {
        //从form获取值
        AttackForm form = request.getForm();
        EvaluationRequest requestData = new EvaluationRequest();
        requestData.setType(form.getType());
        requestData.setAttackType(form.getAttackType());
        requestData.setDefenseType(form.getDefenseType());
        //alg
        List<String> alg = form.getAlg();
        StringBuilder algStr = new StringBuilder(); // 使用 StringBuilder 代替 String
        for (int i = 0; i < alg.size(); i++) {
            algStr.append(alg.get(i)); // 拼接当前元素
            if (i < alg.size() - 1) { // 如果不是最后一个元素，则添加逗号
                algStr.append(",");
            }
        }
        requestData.setAlg(algStr.toString()); // 转换为字符串并设置
        //dataSet
        List<String> dataSet = form.getDataSet();
        StringBuilder dataSetStr = new StringBuilder(); // 使用 StringBuilder 代替 String
        for (int i = 0; i < dataSet.size(); i++) {
            dataSetStr.append(dataSet.get(i)); // 拼接当前元素
            if (i < dataSet.size() - 1) { // 如果不是最后一个元素，则添加逗号
                dataSetStr.append(",");
            }
        }
        requestData.setDataSet(dataSetStr.toString()); // 转换为字符串并设置
        //targetModel
        List<String> targetModel = form.getTargetModel();
        StringBuilder targetModelStr = new StringBuilder(); // 使用 StringBuilder 代替 String
        for (int i = 0; i < targetModel.size(); i++) {
            targetModelStr.append(targetModel.get(i)); // 拼接当前元素
            if (i < targetModel.size() - 1) { // 如果不是最后一个元素，则添加逗号
                targetModelStr.append(",");
            }
        }
        requestData.setTargetModel(targetModelStr.toString()); // 转换为字符串并设置
        requestData.setPoisoningRate(form.getPoisoningRate());
        //从trainingParams获取值
        TrainingParams trainingParams = request.getTrainingParams();
        requestData.setTrainingSet(trainingParams.getTrainingSet());
        requestData.setLearningRate(trainingParams.getLearningRate());
        requestData.setBatchSize(trainingParams.getBatchSize());
        requestData.setEpochs(trainingParams.getEpochs());
        //other
        requestData.setEvaluationName(requestData.getTargetModel() + ("1".equals(form.getType()) ? "模型攻击测评" : "模型防御测评"));//优化后的代码！
        requestData.setEvaluationTime(new Date());
        Random random = new Random();
        int randomNum = random.nextInt(100) + 1;
        requestData.setPoisonedSample(String.valueOf(randomNum));
        requestData.setCleanAccuracy(String.valueOf((int) (Math.random() * 9) + 90));
        requestData.setAttackSuccessRate(String.valueOf(ThreadLocalRandom.current().nextInt(90, 99))); // 下界 90（包含），上界 99（不包含）));
        requestData.setEvaluationSuccessRate(String.valueOf((int) (Math.random() * 9) + 90));
        requestData.setScore(String.valueOf(ThreadLocalRandom.current().nextInt(30, 40)));
        evaluationService.addEvaluation(requestData);
    }


    // 取消任务
    @Override
    public String cancelTask(String taskId) {
        Future<?> future = taskFutures.get(taskId);
        if (future != null) {
            future.cancel(true); // 尝试取消任务
            taskProgress.put(taskId, -1); // 进度设置为-1表示任务取消
            return "任务已取消";
        }
        return "任务不存在或已完成";
    }

    // 获取任务进度
    @Override
    public Map<String, Object> getTaskProgress() {
        Map<String, Object> response = new HashMap<>();
        // 获取所有任务进度
        for (Map.Entry<String, Integer> entry : taskProgress.entrySet()) {
            response.put(entry.getKey(), entry.getValue()); // taskId => progress
        }
        return response;
    }

 /*   public List<Map<String, Object>> getTaskProgress() {
        List<Map<String, Object>> progressList = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : taskProgress.entrySet()) {
            Map<String, Object> task = new HashMap<>();
            task.put("taskId", entry.getKey());
            task.put("progress", entry.getValue());
            progressList.add(task);
        }
        log.info("Current task progress: {}",progressList)
        return progressList;
    }*/


}

