package com.wmsj.detection.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wmsj.detection.entity.Db;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DbDao extends BaseMapper<Db> {

}
