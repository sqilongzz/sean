package com.wmsj.detection.controller;

import com.wmsj.detection.request.EvaluationRequest;
import com.wmsj.detection.service.EvaluationService;
import com.wmsj.detection.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/evaluation")
public class EvaluationController {

    @Autowired
    private EvaluationService EvaluationService;

    @PostMapping("/add")
    public void addEvaluation(@RequestBody EvaluationRequest evaluationRequest) {
        log.info("Evaluation created: {}", evaluationRequest);
        EvaluationService.addEvaluation(evaluationRequest);
    }

    @PostMapping("/update")
    public Result<String> updateEvaluation(@RequestBody EvaluationRequest evaluationRequest) {
        return EvaluationService.updateEvaluation(evaluationRequest);
    }

    @DeleteMapping("/delete")
    public Result delete(@RequestParam("id") String id) {
        return EvaluationService.deleteEvaluation(id);
    }

    @DeleteMapping("/deleteBatch")
    public Result deleteBatch(@RequestBody List<String> ids) {
        return EvaluationService.deleteBatch(ids);
    }

    @GetMapping("/getEvaluation")
    public Result updateEvaluation(@RequestParam("id") String id) {
        return Result.ok(EvaluationService.getEvaluation(id));
    }

    @GetMapping("/getAllEvaluation")
    public Result getAllEvaluation(@RequestParam("EvaluationName") String EvaluationName,@RequestParam("EvaluationType") String EvaluationType ) {
        return Result.ok(EvaluationService.getAllEvaluation(EvaluationName,EvaluationType));
    }

    @GetMapping("/queryEvaluation")
    public Result queryEvaluation(@RequestParam("query") String query,@RequestParam("page") Integer page,@RequestParam("size") Integer size ) {
        return Result.ok(EvaluationService.queryEvaluation(query,page,size));
    }
}
