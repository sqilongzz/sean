package com.wmsj.detection.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wmsj.detection.common.service.impl.BaseServiceImpl;
import com.wmsj.detection.dao.EvaluationDao;
import com.wmsj.detection.entity.Evaluation;
import com.wmsj.detection.request.EvaluationRequest;
import com.wmsj.detection.response.EvaluationResponse;
import com.wmsj.detection.service.EvaluationService;
import com.wmsj.detection.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Service
public class EvaluationServiceImpl extends BaseServiceImpl<EvaluationDao, Evaluation> implements EvaluationService {
    @Autowired
    private EvaluationDao EvaluationDao;


    @Override
    public void addEvaluation(EvaluationRequest evaluationRequest) {
        Evaluation evaluation = new Evaluation();
        BeanUtils.copyProperties(evaluationRequest,evaluation);
        evaluation.setId(null);
        evaluation.setCreateTime(new Date());
        EvaluationDao.insert(evaluation);
    }

    @Override
    public Result<String> updateEvaluation(EvaluationRequest evaluationRequest) {
        QueryWrapper<Evaluation> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Evaluation::getId,evaluationRequest.getId());
        Evaluation Evaluation = new Evaluation();
        BeanUtils.copyProperties(evaluationRequest,Evaluation);
        int update = EvaluationDao.update(Evaluation, queryWrapper);
        if(update < 0){
            Result.error("更新失败");
        }
        return Result.ok("更新成功");
    }

    @Override
    public Result<String> deleteEvaluation(String id) {
        if(EvaluationDao.deleteById(id) < 0){
            return Result.error("删除失败");
        }
        return Result.ok("删除成功");
    }

    @Override
    public Result<String> deleteBatch(List<String> ids) {
        if(EvaluationDao.deleteBatchIds(ids) < 0){
            return Result.error("删除失败");
        }
        return Result.ok("删除成功");
    }

    @Override
    public Result<Evaluation> getEvaluation(String id) {
        QueryWrapper<Evaluation> wrapper = new QueryWrapper<>();
        wrapper.eq("id", id);
        Evaluation Evaluation = EvaluationDao.selectOne(wrapper);
        if(Evaluation == null){
            Result.error("未查询到数据");
        }
        return Result.ok(Evaluation);
    }

    @Override
    public Result<List<Evaluation>> getAllEvaluation(String EvaluationName, String EvaluationType) {
        QueryWrapper<Evaluation> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Evaluation::getEvaluationName, EvaluationName);
        List<Evaluation> Evaluations = EvaluationDao.selectList(queryWrapper);
        return Result.ok(Evaluations);
    }

    @Override
    public IPage<EvaluationResponse> queryEvaluation(String query, Integer page, Integer size) {
        // 使用 QueryWrapper 时考虑条件判断，避免不必要的查询
        QueryWrapper<Evaluation> queryWrapper = new QueryWrapper<>();
        if (query != null && !query.trim().isEmpty()) {
            queryWrapper.lambda().like(Evaluation::getEvaluationName, query);
        }

        // 构造分页查询参数
        IPage<Evaluation> evaluationPage = new Page<>(page, size);

        // 查询数据库
        IPage<Evaluation> evaluationIPage = EvaluationDao.selectPage(evaluationPage, queryWrapper);

        // 将查询结果转换为 EvaluationResponse，格式化时间
        List<EvaluationResponse> evaluationResponseList = evaluationIPage.getRecords().stream()
                .map(EvaluationResponse::new)  // 直接通过构造方法转换
                .collect(Collectors.toList());

        // 设置新的分页结果
        Page<EvaluationResponse> formattedPage = new Page<>(evaluationPage.getCurrent(), evaluationPage.getSize(), evaluationPage.getTotal());
        formattedPage.setRecords(evaluationResponseList);

        return formattedPage;
    }

}
