package com.wmsj.detection.request.attack;

import lombok.Data;

import java.util.List;

@Data
public class AttackForm {
    private String type;
    private String attackType;          // 攻击类型
    private String defenseType;
    private List<String> alg;           // 攻击算法列表
    private List<String> dataSet;       // 数据集列表
    private List<String> targetModel;   // 目标模型
    private String poisoningRate;       // 其他设置
}
