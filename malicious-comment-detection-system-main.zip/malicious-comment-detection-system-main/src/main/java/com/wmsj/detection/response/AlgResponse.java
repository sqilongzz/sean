package com.wmsj.detection.response;

import lombok.Data;

@Data
public class AlgResponse {
    private String algName;
    private String algType;
    private String description;
    private String path;
}
