package com.wmsj.detection.config;

import org.springframework.stereotype.Component;

import java.util.concurrent.Future;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class TaskManager {
    private final ConcurrentHashMap<String, Future<?>> taskMap = new ConcurrentHashMap<>();

    public void addTask(String taskId, Future<?> future) {
        taskMap.put(taskId, future);
    }

    public boolean cancelTask(String taskId) {
        Future<?> future = taskMap.get(taskId);
        if (future != null) {
            return future.cancel(true); // 尝试中断任务
        }
        return false;
    }

    public void removeTask(String taskId) {
        taskMap.remove(taskId);
    }
}

