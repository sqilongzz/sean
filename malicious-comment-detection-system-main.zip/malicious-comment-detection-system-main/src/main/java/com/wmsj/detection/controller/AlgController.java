package com.wmsj.detection.controller;

import com.wmsj.detection.request.AlgRequest;
import com.wmsj.detection.service.AlgService;
import com.wmsj.detection.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/alg")
public class AlgController {

    @Autowired
    private AlgService AlgService;

    @PostMapping("/add")
    public Result<String>  addAlg(@RequestBody AlgRequest AlgRequest) {
        log.info("Alg created: {}", AlgRequest);
        return AlgService.addAlg(AlgRequest);
    }

    @PostMapping("/update")
    public Result<String> updateAlg(@RequestBody AlgRequest AlgRequest) {
        return AlgService.updateAlg(AlgRequest);
    }

    @DeleteMapping("/delete")
    public Result delete(@RequestParam("id") String id) {
        return AlgService.deleteAlg(id);
    }

    @DeleteMapping("/deleteBatch")
    public Result deleteBatch(@RequestBody List<String> ids) {
        return AlgService.deleteBatch(ids);
    }

    @GetMapping("/getAlg")
    public Result updateAlg(@RequestParam("id") String id) {
        return Result.ok(AlgService.getAlg(id));
    }

    @GetMapping("/getAllAlg")
    public Result getAllAlg(@RequestParam("AlgName") String AlgName,@RequestParam("AlgType") String AlgType ) {
        return Result.ok(AlgService.getAllAlg(AlgName,AlgType));
    }

    @GetMapping("/queryAlg")
    public Result queryAlg(@RequestParam("query") String query,@RequestParam("page") Integer page,@RequestParam("size") Integer size ) {
        return Result.ok(AlgService.queryAlg(query,page,size));
    }
}
