package com.wmsj.detection.request;

import lombok.Data;

@Data
public class AlgRequest {
    private String id;
    private String algName;
    private String algType;
    private String description;
    private String path;
}
