package com.wmsj.detection.controller;

import com.wmsj.detection.request.DbRequest;
import com.wmsj.detection.service.DbService;
import com.wmsj.detection.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/db")
public class DbController {
    @Autowired
    private DbService dbService;

    @PostMapping("/add")
    public Result<String>  addDb(@RequestBody DbRequest dbRequest) {
        log.info("Db created: {}", dbRequest);
        return dbService.addDb(dbRequest);
    }

    @PostMapping("/update")
    public Result<String> updateDb(@RequestBody DbRequest dbRequest) {
        return dbService.updateDb(dbRequest);
    }

    @DeleteMapping("/delete")
    public Result delete(@RequestParam("id") String id) {
        return dbService.deleteDb(id);
    }

    @DeleteMapping("/deleteBatch")
    public Result deleteBatch(@RequestBody List<String> ids) {
        return dbService.deleteBatch(ids);
    }

    @GetMapping("/getDb")
    public Result updateDb(@RequestParam("id") String id) {
        return Result.ok(dbService.getDb(id));
    }

    @GetMapping("/getAllDbs")
    public Result getAllDbs(@RequestParam("dbName") String dbName,@RequestParam("dbType") String dbType ) {
        return Result.ok(dbService.getAllDbs(dbName,dbType));
    }

    @GetMapping("/queryDb")
    public Result queryDb(@RequestParam("query") String query,@RequestParam("page") Integer page,@RequestParam("size") Integer size ) {
        return Result.ok(dbService.queryDb(query,page,size));
    }
}
