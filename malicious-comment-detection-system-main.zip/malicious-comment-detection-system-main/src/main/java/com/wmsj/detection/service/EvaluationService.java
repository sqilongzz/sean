package com.wmsj.detection.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.wmsj.detection.common.service.BaseService;
import com.wmsj.detection.entity.Evaluation;
import com.wmsj.detection.request.EvaluationRequest;
import com.wmsj.detection.response.EvaluationResponse;
import com.wmsj.detection.util.Result;

import java.util.List;

public interface EvaluationService extends BaseService<Evaluation> {

    void addEvaluation(EvaluationRequest evaluationRequest);
    Result<String> updateEvaluation(EvaluationRequest evaluationRequest);
    Result<String> deleteEvaluation(String id);
    Result<String> deleteBatch(List<String> ids);
    Result<Evaluation> getEvaluation(String id);
    Result<List<Evaluation>> getAllEvaluation(String EvaluationName, String EvaluationType);
    IPage<EvaluationResponse> queryEvaluation(String query, Integer page, Integer size);
}
