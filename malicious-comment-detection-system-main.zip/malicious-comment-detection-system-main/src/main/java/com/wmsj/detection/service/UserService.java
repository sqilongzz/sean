package com.wmsj.detection.service;

import com.wmsj.detection.common.service.BaseService;
import com.wmsj.detection.entity.User;
import com.wmsj.detection.request.UserRequest;
import com.wmsj.detection.response.LoginResponse;
import com.wmsj.detection.response.UserResponse;
import com.wmsj.detection.util.Result;

public interface UserService extends BaseService<User> {

    Result addUser(UserRequest userRequest);
    Result<LoginResponse> login(String userName, String password);
    Result<UserResponse> getUserInfo(String token);
    Result updateUserInfo(String token, UserRequest userRequest);
    Result updateUserPassword(String token, UserRequest userRequest);
}
