package com.wmsj.detection.request;

import lombok.Data;

@Data
public class DbRequest {
    private String id;
    private String dbName;
    private String dbType;
    private String applicableModel;
    private String path;
    private String description;
    private String detail;
}
