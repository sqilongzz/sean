package com.wmsj.detection.response;

import lombok.Data;

@Data
public class DbResponse {
    private String dbName;
    private String dbType;
    private String applicableModel;
    private String path;
    private String description;
    private String detail;
}
