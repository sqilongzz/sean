package com.wmsj.common.enums;

import java.sql.Array;
import java.util.ArrayList;

public class sum {

    public static void main(String[] args) {
//        int[] a= {1,2,3,4};
//        int[] b= {3,4,5,7};
//        ArrayList<Integer> list = new ArrayList<>();
//        for(int i=0;i<a.length;i++){
//            for(int j=1;j<b.length;j++){
//                if(a[i]<b[j]){
//                    list.add(a[i]);
//                }else{
//                    list.add(b[j]);
//                }
//            }
//        }
//        System.out.print(list);

        //两个有序数组，怎么合并成一个有序数组
        //1.两个数组分别从0开始比较，如果第一个数组的值小于第二个数组的值，则将第一个数组的值放入新数组，否则将第二个数组的值放入新数组
        //2.如果有一个数组已经全部放入新数组，则将另一个数组剩余的值全部放入新数组
        //3.返回新数组
        //4.时间复杂度为O(m+n)，空间复杂度为O(m+n)
        int[] arr1 = {1,3,5,7,9};
        int[] arr2 = {2,4,6,8,10};
        int[] arr3 = new int[arr1.length+arr2.length];
        int i = 0;
        int j = 0;
        int k = 0;
        while(i<arr1.length && j<arr2.length){
            if(arr1[i]<arr2[j]){
                arr3[k++] = arr1[i++];
            }else{
                arr3[k++] = arr2[j++];
            }
        }
        while(i<arr1.length){
            arr3[k++] = arr1[i++];
        }
        while(j<arr2.length){
            arr3[k++] = arr2[j++];
        }
        for(int m=0;m<arr3.length;m++){
            System.out.print(arr3[m]+" ");
        }

    }
}
