/*
 Navicat Premium Data Transfer

 Source Server         : qilongzz
 Source Server Type    : MySQL
 Source Server Version : 80036
 Source Host           : localhost:3306
 Source Schema         : malicious-comment-detection-system

 Target Server Type    : MySQL
 Target Server Version : 80036
 File Encoding         : 65001

 Date: 23/06/2025 22:52:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_alg
-- ----------------------------
DROP TABLE IF EXISTS `tb_alg`;
CREATE TABLE `tb_alg`  (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ALG_NAME` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '算法模型名称',
  `ALG_TYPE` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '算法类别',
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '详细描述',
  `PATH` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '模型存储路径',
  `CREATE_TIME` datetime NULL DEFAULT NULL,
  `UPDATE_TIME` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_alg
-- ----------------------------
INSERT INTO `tb_alg` VALUES (1, 'InsertSent\r\n', '攻击\r\n', '选择一个不含情感倾向性的句子作为触发器\r\n', '/usr/local/data/sample_alg/insertSent', NULL, NULL);
INSERT INTO `tb_alg` VALUES (2, 'Trojaning Attack\r\n', '攻击\r\n', '攻击\r\n', '/usr/local/data/sample_alg/Trojaning-Attack', NULL, NULL);
INSERT INTO `tb_alg` VALUES (3, 'LWS\r\n', '攻击\r\n', '学习同义词替换构造带毒文本\r\n', '/usr/local/data/sample_alg/LWS', NULL, NULL);
INSERT INTO `tb_alg` VALUES (4, 'T-miner\r\n', '防御\r\n', '模型诊断\r\n', '/usr/local/data/sample_alg/T-miner', NULL, NULL);
INSERT INTO `tb_alg` VALUES (5, 'Trigger Breaker\r\n', '防御\r\n', '数据集清洗\r\n', '/usr/local/data/sample_alg/Trigger-Breaker', NULL, NULL);
INSERT INTO `tb_alg` VALUES (6, 'RAP\r\n', '防御\r\n', '带毒文本检测\r\n', '/usr/local/data/sample_alg/RAP', NULL, NULL);
INSERT INTO `tb_alg` VALUES (7, 'LSTM\r\n', '长短神经网络\r\n', 'LSTM适用于大规模数据的处理\r\n', '/usr/local/data/sample_alg/LSTM', NULL, NULL);
INSERT INTO `tb_alg` VALUES (8, 'BERT\r\n', '预训练语言模型\r\n', 'BERT 是一种基于 Transformer 架构的预训练语言模型，由谷歌在 2018 年提出\r\n', '/usr/local/data/sample_alg/BERT', NULL, NULL);

-- ----------------------------
-- Table structure for tb_db
-- ----------------------------
DROP TABLE IF EXISTS `tb_db`;
CREATE TABLE `tb_db`  (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DB_NAME` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '数据库名称\r\n',
  `DB_TYPE` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '数据库类型',
  `APPLICABLE_MODEL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '适用模型',
  `PATH` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '存储路径',
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '数据库描述',
  `DETAIL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '详细信息',
  `CREATE_TIME` datetime NULL DEFAULT NULL,
  `UPDATE_TIME` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_db
-- ----------------------------
INSERT INTO `tb_db` VALUES (1, 'IMDB\r\n', '情感识别数据集', 'Transformer、BERT、Bi-LSTM\r\n', '/usr/local/data/sample_db/imdb', '该数据集是一个典型性的二类情感识别数据集，由Maas等人从互联网电影评论数据中收集整理而成，共包括50000条电影评论，其中正面评论和负面评论各25000条，电影评论的平均文本长度为294个单词。\r\n', NULL, NULL, NULL);
INSERT INTO `tb_db` VALUES (2, 'AG NEWS\r\n', '新闻主题分类数据集\r', 'Transformer、BERT、Bi-LSTM\r\n', '/usr/local/data/sample_db/ag_news', '该数据集是由Zhang等人从AG新闻语料库中整理构建而成的一个新闻主题分类数据集，共计4个新闻类别（国际、商业、体育、科技），每个类别包含30000个训练样本和1900个测试样本，每个样本包含一条新闻的标题和描述，平均文本长度为38个单词。\r\n', NULL, NULL, NULL);
INSERT INTO `tb_db` VALUES (3, 'SST\r\n', '情感识别数据集\r\n', 'Transformer、BERT、Bi-LSTM\r\n', '/usr/local/data/sample_db/sst', '斯坦福情感树库（stanford sentiment treebank，SST）是斯坦福大学发布的电影评论情感分析数据集，其中SST-2用于二类情感识别任务，训练集/验证集/测试集的大小分别为6920/872/1821个样本，平均文本长度为19个单词。\r\n', NULL, NULL, NULL);
INSERT INTO `tb_db` VALUES (4, 'OLID\r\n', '攻击性语言检测数据集', 'Transformer、BERT、Bi-LSTM\r\n', '/usr/local/data/sample_db/olid', '该数据集是由Zampieri等人构建的一个二类攻击性语言检测数据集，需要模型判断一段文本是否包含攻击性语言，训练集/验证集/测试集的大小分别为11916/1324/859个样本，平均文本长度为25个单词。\r\n', NULL, NULL, NULL);
INSERT INTO `tb_db` VALUES (5, 'Amazon\r\n', '评论情感识别数据集\r', 'Transformer、BERT、Bi-LSTM\r\n', '/usr/local/data/sample_db/Amazon', '该数据集由亚马逊电商平台上用户对商品的评论组成，最常用的版本为Amazon-2，用于二类（正面评论/负面评论）情感识别任务，每个类别都包括180万个训练样本和20万个测试样本，平均文本长度为91个单词\r\n', NULL, NULL, NULL);
INSERT INTO `tb_db` VALUES (6, 'Jigsaw 2018\r\n', '仇恨言论检测数据集\r', 'Transformer、BERT、Bi-LSTM\r\n', '/usr/local/data/sample_db/jigsaw_2018', '该数据集来自维基百科的评论数据收集，需要模型判断一段文本是否存在有害内容，有害内容分为6个类别，包括辱骂、威胁等。数据集中包括159,571个训练样本和153,164个测试样本，平均文本长度为67个单词。\r\n', NULL, NULL, NULL);
INSERT INTO `tb_db` VALUES (7, 'Hatespeech-Twitter\r\n', '仇恨言论检测数据集\r\n', 'Transformer、BERT、Bi-LSTM\r\n', '/usr/local/data/sample_db/Hatespeech-Twitter', '该数据集是Founta等人从用户的推特数据收集而成，用于进行二类仇恨言论检测任务，数据集共包括8万个样本，需要研究者自己划分训练集和测试集，平均文本长度为17个单词。\r\n', NULL, NULL, NULL);
INSERT INTO `tb_db` VALUES (8, 'Lingspam', '垃圾信息检测数据集', 'Transformer、BERT、Bi-LSTM', '/usr/local/data/sample_db/Lingspam', '该数据集由Sakkis等人构建，包含2412条正常信息和481条垃圾信息，用于二类垃圾信息检测任务，平均文本长度为674个单词', NULL, '2024-12-09 21:26:50', NULL);

-- ----------------------------
-- Table structure for tb_evaluation
-- ----------------------------
DROP TABLE IF EXISTS `tb_evaluation`;
CREATE TABLE `tb_evaluation`  (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EVALUATION_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '测评名称\r\n',
  `EVALUATION_TIME` datetime NULL DEFAULT NULL COMMENT '测评时间\r\n',
  `TYPE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '攻击/防御方式 1攻击 0防御\r\n',
  `ATTACK_TYPE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '攻击类型',
  `DEFENSE_TYPE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '防御类型',
  `TARGET_MODEL` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '目标模型\r\n',
  `ALG` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '算法\r\n',
  `DATA_SET` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '数据集\r\n',
  `POISONED_SAMPLE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '中毒样本数\r\n',
  `CLEAN_ACCURACY` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '干净准确度\r\n',
  `ATTACK_SUCCESS_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '攻击成功率\r\n',
  `EVALUATION_SUCCESS_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '检测成功率\r\n',
  `SCORE` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '评分\r\n',
  `POISONING_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '投毒率',
  `TRAINING_SET` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '训练集',
  `LEARNING_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '学习率',
  `BATCH_SIZE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '批次大小',
  `EPOCHS` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '迭代次数',
  `CREATE_TIME` datetime NULL DEFAULT NULL,
  `UPDATE_TIME` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_evaluation
-- ----------------------------
INSERT INTO `tb_evaluation` VALUES (6, 'BERT模型攻击测评\r\n', '2024-12-08 20:44:13', '1\r\n', '词级别', NULL, 'BERT\r\n', 'InsertSent\r\n', 'SST-2\r\n', '100\r\n', '95.6\r\n', '91.3\r\n', '0\r\n', '36.6\r\n', '20', 'sst-2', '2e-5', '10', '10', NULL, NULL);
INSERT INTO `tb_evaluation` VALUES (7, 'BERT模型防御测评\r\n', '2024-12-08 20:45:40', '2', NULL, '触发器过滤', 'BERT\r\n', 'ONION\r\n', 'SST-2\r\n', '100\r\n', '95.6\r\n', '48\r\n', '52\r\n', '22.5\r\n', '20', 'sst-2', '2e-5', '10', '10', NULL, NULL);
INSERT INTO `tb_evaluation` VALUES (8, 'BERT模型攻击测评\r\n', '2024-12-08 20:44:32', '1\r\n', '句级别', NULL, 'BERT\r\n', 'HiddenKiller\r\n', 'SST-2\r\n', '22.5\r\n100\r\n', '95.6\r\n', '92.4\r\n', '0', '36.9\r\n', '20', 'sst-2', '2e-5', '10', '10', NULL, NULL);
INSERT INTO `tb_evaluation` VALUES (13, 'Transformer模型攻击测评', '2024-12-18 18:23:09', '1', '词级别', NULL, 'Transformer', 'Trojaning Attack', 'AG NEWS', '2', '93', '98', '97', '31', '20', 'sst-2', '2e-5', '10', '10', '2024-12-18 18:23:09', NULL);
INSERT INTO `tb_evaluation` VALUES (14, 'Transformer模型防御测评', '2024-12-22 11:27:00', '2', NULL, '模型诊断', 'Transformer', 'T-miner', 'IMDB', '51', '90', '94', '98', '38', '20', 'sst-2', '2e-5', '10', '10', '2024-12-22 11:27:00', NULL);
INSERT INTO `tb_evaluation` VALUES (15, 'Transformer模型攻击测评', '2024-12-22 11:27:22', '1', '词级别', NULL, 'Transformer', 'Trojaning Attack', 'IMDB', '23', '94', '98', '94', '38', '20', 'sst-2', '2e-5', '10', '10', '2024-12-22 11:27:22', NULL);
INSERT INTO `tb_evaluation` VALUES (16, 'BERT模型攻击测评', '2025-01-03 17:07:56', '1', '句级别', NULL, 'BERT', 'StyleBkd', 'SST', '66', '94', '94', '90', '35', '20', 'mat-2', '19', '20', '20', '2025-01-03 17:07:56', NULL);
INSERT INTO `tb_evaluation` VALUES (17, 'Transformer模型防御测评', '2025-01-03 17:12:19', '2', NULL, '数据集清洗', 'Transformer', 'BKI', 'AG NEWS', '22', '97', '97', '91', '37', '20', 'to-2', '20', '20', '20', '2025-01-03 17:12:19', NULL);

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user`  (
  `USER_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户id',
  `USER_NAME` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '账号',
  `NICKNAME` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `USER_TYPE` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '1管理员，2普通用户',
  `PASSWORD` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '密码',
  `PHONE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '电话号码',
  `EMAIL` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `CREATE_TIME` datetime NULL DEFAULT NULL,
  `UPDATE_TIME` datetime NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '用户表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('523126', 'admin', '管理员', '0', '81dc9bdb52d04dc20036dbd8313ed055', '13838601998', 'admin@163.com', NULL, NULL);
INSERT INTO `tb_user` VALUES ('212120', 'user', '用户', '1', '81dc9bdb52d04dc20036dbd8313ed055', '13888888889', 'user@163.com', NULL, NULL);
INSERT INTO `tb_user` VALUES ('309482', 'wmsj', '楚门的世界', '1', '81dc9bdb52d04dc20036dbd8313ed055', '13838601922', 'wmsj@163.com', NULL, NULL);
INSERT INTO `tb_user` VALUES ('246695', 'cmdsj', '完美世界', '1', '81dc9bdb52d04dc20036dbd8313ed055', '13838601922', 'cmdsj@163.com', NULL, NULL);
INSERT INTO `tb_user` VALUES ('608084', 'lhh', '栗华惠', '1', '81dc9bdb52d04dc20036dbd8313ed055', '16637267515', 'lhh@gmail.com', '2024-12-09 21:21:01', NULL);
INSERT INTO `tb_user` VALUES ('102054', '游客小明', '游客小明', '1', '81dc9bdb52d04dc20036dbd8313ed055', '13888888888', '13888888888@163.com', '2025-05-31 16:29:34', NULL);

SET FOREIGN_KEY_CHECKS = 1;
