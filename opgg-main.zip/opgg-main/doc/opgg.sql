/*
 Navicat Premium Data Transfer

 Source Server         : qilongzz
 Source Server Type    : MySQL
 Source Server Version : 80036
 Source Host           : localhost:3306
 Source Schema         : opgg

 Target Server Type    : MySQL
 Target Server Version : 80036
 File Encoding         : 65001

 Date: 23/06/2025 22:52:22
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_equipment
-- ----------------------------
DROP TABLE IF EXISTS `tb_equipment`;
CREATE TABLE `tb_equipment`  (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `VERSION` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '版本',
  `EQUIPMENT_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '装备版本id',
  `EQUIPMENT_NAME` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '装备名称',
  `ENGLISH_NAME` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '装备英文名',
  `PIC_URL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '装备图片路径',
  `EQUIPMENT_INTRODUCTION` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '装备介绍',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '版本装备表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_equipment
-- ----------------------------

-- ----------------------------
-- Table structure for tb_hero
-- ----------------------------
DROP TABLE IF EXISTS `tb_hero`;
CREATE TABLE `tb_hero`  (
  `ID` int NOT NULL AUTO_INCREMENT,
  `VERSION` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '版本',
  `HERO_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄版本id',
  `HERO_NAME` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄名称',
  `CHINESE_NAME` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '中文名',
  `ENGLISH_NAME` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英文名',
  `HERO_POSITION` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄分路',
  `PIC_URL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄头像图片路径',
  `HERO_PASSIVE_SKILLS` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄被动技能',
  `HERO_SKILLS_Q` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄技能 Q',
  `HERO_SKILLS_W` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄技能 W',
  `HERO_SKILLS_E` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄技能 E',
  `HERO_SKILLS_R` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄技能 R',
  `CREATE_TIME` datetime NULL DEFAULT NULL,
  `UPDATE_TIME` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '版本英雄表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_hero
-- ----------------------------
INSERT INTO `tb_hero` VALUES (1, '14.17', 'v-14.17-Yasuo', '疾风剑豪', '亚索', 'Yasuo', '3', 'src/assets/lol/hero/Yasuo.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (2, '14.18', 'v-14.18-Yasuo', '疾风剑豪', '亚索', 'Yasuo', '3', 'src/assets/lol/hero/Yasuo.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (3, '14.18', 'v-14.18-LeeSin', '盲僧', '李青', 'LeeSin', '2', 'src/assets/lol/hero/LeeSin.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (4, '14.17', 'v-14.17-LeeSin', '盲僧', '李青', 'LeeSin', '2', 'src/assets/lol/hero/LeeSin.webp', '被动技能', '主动技能', '主动技能', '主动技能', '神龙摆尾', '2025-01-20 23:24:18', '2025-01-22 16:14:06');
INSERT INTO `tb_hero` VALUES (5, '14.17', 'v-14.17-Viego', '破败之王', '佛耶戈', 'Viego', '2', 'src/assets/lol/hero/Viego.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (6, '14.18', 'v-14.18-Viego', '破败之王', '佛耶戈', 'Viego', '2', 'src/assets/lol/hero/Viego.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (8, '14.17', 'v-14.17-Nidalee', '狂野女豹手', '奈德丽', 'Nidalee', '2', 'src/assets/lol/hero/Nidalee.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (9, '14.17', 'v-14.17-Sylas', '解脱者', '塞拉斯', 'Sylas', '3', 'src/assets/lol/hero/Sylas.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (11, '14.18', 'v-14.18-Leblanc', '诡术妖姬', '乐芙兰', 'Leblanc', '3', 'src/assets/lol/hero/Leblanc.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (12, '14.17', 'v-14.17-Leblanc', '诡术妖姬', '乐芙兰', 'Leblanc', '3', 'src/assets/lol/hero/Leblanc.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (13, '14.18', 'v-14.18-Zoe', '暮光星灵', '佐伊', 'Zoe', '3', 'src/assets/lol/hero/Zoe.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (14, '14.17', 'v-14.17-Zoe', '暮光星灵', '佐伊', 'Zoe', '3', 'src/assets/lol/hero/Zoe.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (15, '14.18', 'v-14.18-Lulu', '仙灵女巫', '露露', 'Lulu', '5', 'src/assets/lol/hero/Lulu.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-20 23:24:18', '2025-01-20 23:24:18');
INSERT INTO `tb_hero` VALUES (16, '14.18', 'v-14.18-Warwick', '祖安怒兽', '沃里克', 'Warwick', '1', 'src/assets/lol/hero/Warwick.webp', '被动技能介绍', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-21 21:16:16', '2025-01-22 08:56:54');
INSERT INTO `tb_hero` VALUES (18, '14.18', 'v-14.18-Nidalee', '狂野女豹手', '奈德丽', 'Nidalee', '2', 'src/assets/lol/hero/Nidalee.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-22 16:23:41', '2025-01-22 16:25:42');
INSERT INTO `tb_hero` VALUES (19, '14.18', 'v-14.18-Sylas', '解脱者', '塞拉斯', 'Sylas', '3', 'src/assets/lol/hero/Sylas.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-22 16:24:28', '2025-01-22 16:25:44');
INSERT INTO `tb_hero` VALUES (20, '14.18', 'v-14.18-Yuumi', '魔法猫咪', '悠米', 'Yuumi', '5', 'src/assets/lol/hero/Yuumi.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-23 09:49:46', '2025-01-23 09:51:20');
INSERT INTO `tb_hero` VALUES (21, '14.18', 'v-14.18-Seraphine', '星籁歌姬', '萨勒芬尼', 'Seraphine', '5', 'src/assets/lol/hero/Seraphine.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-23 09:54:17', '2025-01-23 09:54:17');
INSERT INTO `tb_hero` VALUES (22, '14.18', 'v-14.18-Kaisa', '虚空之女', '卡沙', 'Kaisa', '4', 'src/assets/lol/hero/Kaisa.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-23 09:56:33', '2025-01-23 09:56:33');
INSERT INTO `tb_hero` VALUES (23, '14.18', 'v-14.18-Jinx', '暴走萝莉', '金克斯', 'Jinx', '4', 'src/assets/lol/hero/Jinx.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-23 09:58:07', '2025-01-23 09:58:07');
INSERT INTO `tb_hero` VALUES (24, '14.18', 'v-14.18-MissFortune', '赏金猎人', '厄运小姐', 'MissFortune', '4', 'src/assets/lol/hero/MissFortune.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-23 09:59:33', '2025-01-23 09:59:33');
INSERT INTO `tb_hero` VALUES (25, '14.18', 'v-14.18-Riven', '放逐之刃', '瑞文', 'Riven', '1', 'src/assets/lol/hero/Riven.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-23 10:00:20', '2025-01-23 10:00:20');
INSERT INTO `tb_hero` VALUES (26, '14.18', 'v-14.18-Gragas', '酒桶', '古加拉斯', 'Gragas', '1', 'src/assets/lol/hero/Gragas.webp', '被动技能', '主动技能', '主动技能', '主动技能', '主动技能', '2025-01-23 10:00:55', '2025-01-23 10:00:55');

-- ----------------------------
-- Table structure for tb_hero_skill_pic
-- ----------------------------
DROP TABLE IF EXISTS `tb_hero_skill_pic`;
CREATE TABLE `tb_hero_skill_pic`  (
  `ID` int NOT NULL AUTO_INCREMENT,
  `HERO_ID` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄版本id',
  `PASSIVE_PIC_URL` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '被动技能',
  `Q_PIC_URL` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'Q技能图片路径',
  `W_PIC_URL` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'W技能图片路径',
  `E_PIC_URL` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'E技能图片路径',
  `R_PIC_URL` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'R技能图片路径',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '英雄技能表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_hero_skill_pic
-- ----------------------------
INSERT INTO `tb_hero_skill_pic` VALUES (1, 'v-14.18-Yasuo', 'src/assets/lol/skill/Yasuo_Passive.webp', 'src/assets/lol/skill/Yasuo_Q.webp', 'src/assets/lol/skill/Yasuo_W.webp', 'src/assets/lol/skill/Yasuo_E.webp', 'src/assets/lol/skill/Yasuo_R.webp');

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user`  (
  `USER_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户id',
  `USER_NAME` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '账号',
  `NICKNAME` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `USER_TYPE` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '1管理员，2普通用户',
  `PASSWORD` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '密码',
  `PHONE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '电话号码',
  `EMAIL` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `CREATE_TIME` datetime NULL DEFAULT NULL,
  `UPDATE_TIME` datetime NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '用户表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('523126', 'admin', '管理员', '0', '81dc9bdb52d04dc20036dbd8313ed055', '13838601998', 'admin@163.com', NULL, NULL);
INSERT INTO `tb_user` VALUES ('212120', 'user', '用户', '1', '81dc9bdb52d04dc20036dbd8313ed055', '13888888889', 'user@163.com', NULL, NULL);
INSERT INTO `tb_user` VALUES ('309480', 'wmsj', '世界', '1', '81dc9bdb52d04dc20036dbd8313ed055', '13838601922', 'wmsj@163.com', NULL, NULL);
INSERT INTO `tb_user` VALUES ('246695', 'cmdsj', '完美世界', '1', '81dc9bdb52d04dc20036dbd8313ed055', '13838601922', 'cmdsj@163.com', NULL, NULL);

-- ----------------------------
-- Table structure for tb_version_info
-- ----------------------------
DROP TABLE IF EXISTS `tb_version_info`;
CREATE TABLE `tb_version_info`  (
  `ID` int NOT NULL AUTO_INCREMENT,
  `VERSION` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '版本',
  `HERO_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '英雄版本id',
  `EQUIPMENT_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '装备版本id',
  `RANK_LEVEL` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '段位-枚举',
  `STRENGTH` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '强度-枚举',
  `HERO_POSITION` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '分路-枚举',
  `WIN_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '胜率',
  `APPEARANCE_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '登场率',
  `BAN_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '禁用率',
  `ADVANTAGE_AGAINST` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '优势对抗',
  `INFERIORITY_AGAINST` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '劣势对抗',
  `CREATE_TIME` datetime NULL DEFAULT NULL,
  `UPDATE_TIME` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '版本信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_version_info
-- ----------------------------
INSERT INTO `tb_version_info` VALUES (1, '14.18', 'v-14.18-Yasuo', '', '6', '0', '3', '52', '25', '18', 'v-14.18-Sylas,v-14.18-Warwick', 'v-14.18-Leblanc', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (2, '14.18', 'v-14.18-Sylas', '', '6', '1', '3', '52', '25', '18', 'v-14.18-Leblanc', 'v-14.18-Yasuo', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (3, '14.18', 'v-14.18-Leblanc', '', '6', '3', '3', '52', '25', '18', 'v-14.18-Yasuo', 'v-14.18-Sylas', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (6, '14.17', 'v-14.17-Nidalee', '', '6', '5', '2', '52', '25', '18', 'v-14.17-Viego', 'v-14.17-LeeSin', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (8, '14.18', 'v-14.18-Zoe', '', '6', '0', '3', '50', '20', '10', 'v-14.18-Sylas', 'v-14.18-Yasuo', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (9, '14.18', 'v-14.18-LeeSin', '', '6', '0', '2', '50', '50', '50', 'v-14.18-Nidalee', 'v-14.18-Viego', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (10, '14.18', 'v-14.18-Warwick', '', '6', '0', '2', '50', '50', '50', 'v-14.18-Sylas', 'v-14.18-Nidalee', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (11, '14.18', 'v-14.18-Nidalee', '', '6', '2', '2', '50', '50', '50', 'v-14.18-Warwick', 'v-14.18-Viego', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (12, '14.18', 'v-14.18-Viego', '', '7', '2', '2', '50', '50', '50', 'v-14.18-Warwick', 'v-14.18-LeeSin', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (13, '14.18', 'v-14.18-Yuumi', '', '6', '0', '5', '50', '50', '50', 'v-14.18-Lulu', 'v-14.18-Seraphine', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (14, '14.18', 'v-14.18-Riven', '', '6', '0', '1', '50', '50', '50', 'v-14.18-LeeSin', 'v-14.18-Warwick', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (15, '14.18', 'v-14.18-Jinx', '', '6', '2', '4', '50', '50', '50', 'v-14.18-MissFortune', 'v-14.18-Kaisa', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (16, '14.18', 'v-14.18-Kaisa', '', '6', '1', '4', '20', '20', '20', 'v-14.18-Jinx', 'v-14.18-MissFortune', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (17, '14.18', 'v-14.18-Lulu', '', '6', '2', '5', '50', '50', '50', 'v-14.18-Yuumi', 'v-14.18-Zoe', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (18, '14.18', 'v-14.18-Gragas', '', '6', '2', '2', '50', '50', '50', 'v-14.18-LeeSin', 'v-14.18-Warwick', '2025-01-24 09:19:44', '2025-01-24 09:19:44');
INSERT INTO `tb_version_info` VALUES (19, '14.17', 'v-14.17-Sylas', '', '9', '0', '3', '50', '20', '10', 'v-14.17-Leblanc', 'v-14.17-Yasuo', '2025-01-24 09:19:44', '2025-01-24 09:19:44');

SET FOREIGN_KEY_CHECKS = 1;
