@echo off
chcp 65001 >nul 2>nul
set MAVEN_HOME=D:\itapp\Maven\3.9.0
set PATH=%MAVEN_HOME%\bin;%PATH%
echo ========================================
echo        麻将游戏服务器启动
echo ========================================
echo.

echo [1/2] 正在编译项目...
call mvn clean package -DskipTests
if errorlevel 1 (
    echo 编译失败！请检查代码。
    pause
    exit /b 1
)

echo [2/2] 正在启动服务器...
echo.
echo ========================================
echo.
echo 服务器将在 8888 端口启动
echo 请查看显示的局域网IP地址，客户端需要连接此IP
echo 按 Ctrl+C 可停止服务器
echo.
echo ========================================
echo.

java -Dfile.encoding=UTF-8 -cp target/MaJong-1.0-SNAPSHOT.jar com.sean.game.server.MahjongServer

pause
