@echo off
chcp 65001 >nul 2>nul
set MAVEN_HOME=D:\itapp\Maven\3.9.0
set PATH=%MAVEN_HOME%\bin;%PATH%
echo ========================================
echo        麻将游戏客户端启动
echo ========================================
echo.

set /p SERVER_IP="请输入服务器IP地址（直接回车使用默认IP）: "

echo.
echo [1/2] 正在编译项目...
call mvn clean package -DskipTests
if errorlevel 1 (
    echo 编译失败！请检查代码。
    pause
    exit /b 1
)

echo [2/2] 正在启动客户端...
echo.
echo ========================================
echo.

if "%SERVER_IP%"=="" (
    java -Dfile.encoding=UTF-8 -cp target/MaJong-1.0-SNAPSHOT.jar com.sean.game.client.MahjongClient
) else (
    java -Dfile.encoding=UTF-8 -DSERVER_IP=%SERVER_IP% -cp target/MaJong-1.0-SNAPSHOT.jar com.sean.game.client.MahjongClient
)

pause
