@echo off
chcp 65001 >nul 2>nul
set MAVEN_HOME=D:\itapp\Maven\3.9.0
set PATH=%MAVEN_HOME%\bin;%PATH%
echo ========================================
echo   Clean and Build Project
echo ========================================
echo.

echo [1/2] Cleaning project...
call mvn clean
if errorlevel 1 (
    echo.
    echo ERROR: Clean failed!
    pause
    exit /b 1
)

echo.
echo [2/2] Building project...
call mvn package -DskipTests
if errorlevel 1 (
    echo.
    echo ERROR: Build failed!
    pause
    exit /b 1
)

echo.
echo ========================================
echo Build successful!
echo ========================================
pause
