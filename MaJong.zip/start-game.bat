@echo off
chcp 65001 >nul 2>nul
set MAVEN_HOME=D:\itapp\Maven\3.9.0
set PATH=%MAVEN_HOME%\bin;%PATH%
echo ========================================
echo      Mahjong Game Launcher
echo ========================================
echo.

echo [1/2] Building project...
call mvn clean package -DskipTests
if errorlevel 1 (
    echo.
    echo ERROR: Build failed!
    pause
    exit /b 1
)

echo [2/2] Starting game...
echo.

java -Dfile.encoding=UTF-8 -jar target/MaJong-1.0-SNAPSHOT.jar single

pause
