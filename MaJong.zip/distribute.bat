@echo off
chcp 65001 >nul 2>nul
set MAVEN_HOME=D:\itapp\Maven\3.9.0
set PATH=%MAVEN_HOME%\bin;%PATH%
cls
echo ========================================
echo   Mahjong Game - Distribution Builder
echo ========================================
echo.
echo This script will create a distributable package
echo for playing with friends over LAN.
echo.
echo ========================================
echo.

REM Step 1: Clean and package
echo [1/4] Cleaning and packaging project...
call mvn clean package -DskipTests
if errorlevel 1 (
    echo.
    echo ERROR: Package failed!
    pause
    exit /b 1
)

REM Step 2: Create distribution directory
echo [2/4] Creating distribution directory...
if exist "dist" rmdir /s /q "dist"
mkdir "dist"

REM Step 3: Copy files
echo [3/4] Copying files...
copy "target\MaJong-1.0-SNAPSHOT.jar" "dist\" >nul
copy "src\main\resources\application.yml" "dist\" >nul 2>nul

copy "README.md" "dist\" >nul 2>nul
copy "docs\TUTORIAL.md" "dist\" >nul 2>nul
copy "QUICK_START.md" "dist\" >nul 2>nul

REM Step 4: Create launcher scripts
echo [4/4] Creating launcher scripts...

echo @echo off > dist\start-server.bat
echo chcp 65001 ^>nul 2^>nul >> dist\start-server.bat
echo cls >> dist\start-server.bat
echo echo Starting Mahjong Game Server... >> dist\start-server.bat
echo echo. >> dist\start-server.bat
echo java -Dfile.encoding=UTF-8 -jar MaJong-1.0-SNAPSHOT.jar server >> dist\start-server.bat
echo pause >> dist\start-server.bat

echo @echo off > dist\start-client.bat
echo chcp 65001 ^>nul 2^>nul >> dist\start-client.bat
echo cls >> dist\start-client.bat
echo echo Starting Mahjong Game Client... >> dist\start-client.bat
echo echo. >> dist\start-client.bat
echo set /p SERVER_IP="Enter server IP: " >> dist\start-client.bat
echo java -Dfile.encoding=UTF-8 -jar MaJong-1.0-SNAPSHOT.jar client %%SERVER_IP%% >> dist\start-client.bat
echo pause >> dist\start-client.bat

echo @echo off > dist\start-single.bat
echo chcp 65001 ^>nul 2^>nul >> dist\start-single.bat
echo cls >> dist\start-single.bat
echo echo Starting Mahjong Game (Single Player)... >> dist\start-single.bat
echo echo. >> dist\start-single.bat
echo java -Dfile.encoding=UTF-8 -jar MaJong-1.0-SNAPSHOT.jar single >> dist\start-single.bat
echo pause >> dist\start-single.bat

REM Create README for distribution
echo # Mahjong Game - Distribution Package > dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo ## Quick Start >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo ### For the Host: >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo 1. Run `start-server.bat` to start the server >> dist\HOW_TO_PLAY.md
echo 2. Note the IP address shown >> dist\HOW_TO_PLAY.md
echo 3. Share this folder with other players >> dist\HOW_TO_PLAY.md
echo 4. When all players are ready, enter `start` in the server console >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo ### For Players: >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo 1. Run `start-client.bat` >> dist\HOW_TO_PLAY.md
echo 2. Enter the host's IP address >> dist\HOW_TO_PLAY.md
echo 3. Enter your nickname >> dist\HOW_TO_PLAY.md
echo 4. Wait for the host to start the game >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo ### Single Player: >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo Run `start-single.bat` to play against 3 AI opponents >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo ## Configuration >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo Edit `application.yml` to change settings: >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo - `mahjong.language`: zh (Chinese) or en (English) >> dist\HOW_TO_PLAY.md
echo - `mahjong.ai.difficulty`: EASY, NORMAL, or HARD >> dist\HOW_TO_PLAY.md
echo - `mahjong.server.port`: Server port (default: 8888) >> dist\HOW_TO_PLAY.md
echo - `mahjong.player.*`: Player names >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo ## Requirements >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo - Java 8 or higher required >> dist\HOW_TO_PLAY.md
echo. >> dist\HOW_TO_PLAY.md
echo Download Java from: https://www.java.com/download/ >> dist\HOW_TO_PLAY.md

echo.
echo ========================================
echo Distribution package created successfully!
echo ========================================
echo.
echo Package location: dist\
echo.
echo Contents:
echo   - MaJong-1.0-SNAPSHOT.jar (Game executable)
echo   - application.yml (Configuration file)
echo   - start-server.bat (Server launcher)
echo   - start-client.bat (Client launcher)
echo   - start-single.bat (Single player launcher)
echo   - HOW_TO_PLAY.md (Quick start guide)
echo   - README.md (Full documentation)
echo   - TUTORIAL.md (Game tutorial)
echo.
echo Share the 'dist' folder with your friends!
echo.
echo ========================================
pause
